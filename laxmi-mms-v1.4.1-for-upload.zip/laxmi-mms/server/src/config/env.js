import 'dotenv/config';

export const env = {
  port: Number(process.env.PORT || 5000),
  mongoUri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/laxmi_mms',
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  smartReorder: process.env.SMART_REORDER_ENABLED !== 'false',
  // When both are set, the whole app asks for this username and password (until a login module exists).
  appUsername: process.env.APP_USERNAME || '',
  appPassword: process.env.APP_PASSWORD || '',
  // Load the LBSL 80 sample, its vendors and PO 0085 the first time the app starts on an empty database.
  seedSampleData: process.env.SEED_SAMPLE_DATA === 'true'
};
