import { z } from 'zod';

const str = (max = 300) => z.string().trim().max(max).default('');
const optionalNumber = (label, { integer = false } = {}) =>
  z.union([z.number(), z.string(), z.null()]).optional().transform((v, ctx) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0 || (integer && !Number.isInteger(n))) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${label} must be ${integer ? 'a whole number' : 'a number'}, 0 or more` });
      return z.NEVER;
    }
    return n;
  });

export const vendorMaterialBody = z.object({
  material: z.string({ required_error: 'Material name is required' }).trim().min(1, 'Material name is required').max(200),
  specification: str(300),
  unit: str(20),
  rate: optionalNumber('Rate'),
  rateDate: z.string().regex(/^(\d{4}-\d{2}-\d{2})?$/, 'Rate date must be a date').optional().default(''), // date the rate applies from
  gstPct: optionalNumber('GST %').refine((v) => v === null || v <= 100, 'GST % must be 100 or less'),
  moq: optionalNumber('MOQ'),
  leadTimeDays: optionalNumber('Lead time', { integer: true }),
  preferred: z.enum(['yes', 'no', '']).default(''),
  status: z.enum(['active', 'inactive'], { errorMap: () => ({ message: 'Choose a status: Active or Inactive' }) }),
  remarks: str(500)
});
