import { z } from 'zod';
import { resolveState } from '../../../shared/gstStates.js';

const str = (max = 300) => z.string().trim().max(max).default('');

export const vendorBody = z.object({
  code: z.string().trim().max(20).optional().default(''), // blank = next code
  name: z.string({ required_error: 'Vendor name is required' }).trim().min(1, 'Vendor name is required').max(200),
  contactPerson: str(120),
  email: z.union([z.literal(''), z.string().trim().email('Enter a valid email')]).default(''),
  mobile: z.string().trim().max(20).regex(/^[0-9+\-\s]*$/, 'Mobile can only have digits, spaces, + and -').default(''),
  address: str(500),
  state: str(60),
  stateCode: z.string().trim().max(2).default(''), // worked out from the state (or GSTIN), never typed
  gstin: z.string().trim().toUpperCase().regex(/^([0-9A-Z]{15})?$/, 'GSTIN has 15 letters and digits').default(''),
  category: str(100),
  materialsSupplied: str(500),
  preferred: z.enum(['yes', 'no', '']).default(''),
  leadTimeDays: z
    .union([z.number(), z.string(), z.null()])
    .optional()
    .transform((v, ctx) => {
      if (v === null || v === undefined || v === '') return null;
      const n = Number(v);
      if (!Number.isInteger(n) || n < 0) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Lead time is a whole number of days' });
        return z.NEVER;
      }
      return n;
    }),
  paymentTerms: str(200),
  status: z.enum(['active', 'inactive'], { errorMap: () => ({ message: 'Choose a status: Active or Inactive' }) }),
  remarks: str(1000)
}).transform((v, ctx) => {
  // State code comes from the state chosen, or from the first 2 digits of the GSTIN.
  const r = resolveState(v);
  if (r.gstinMismatch) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['gstin'], message: `GSTIN starts with ${r.gstinMismatch.code} (${r.gstinMismatch.name}) but the state chosen is ${r.state}` });
    return z.NEVER;
  }
  return { ...v, state: r.state, stateCode: r.stateCode };
});
