import { z } from 'zod';
import { resolveState } from '../../../shared/gstStates.js';

const str = (max = 300) => z.string().trim().max(max).default('');
const num = (min, max) => z.coerce.number().min(min).max(max);

// Required numbers must be typed in; nothing is assumed (no default GST, qty or rate).
const required = (label, min, max, { aboveMin = false } = {}) =>
  z.union([z.number(), z.string()], { required_error: `${label} is required` }).transform((v, ctx) => {
    if (v === '' || v === null) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${label} is required` });
      return z.NEVER;
    }
    const n = Number(v);
    if (!Number.isFinite(n) || n < min || n > max || (aboveMin && n <= min)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: aboveMin ? `${label} must be more than ${min}` : `${label} must be between ${min} and ${max}` });
      return z.NEVER;
    }
    return n;
  });

const line = z.object({
  uid: z.string().min(1),
  description: z.string().trim().min(1, 'Every row needs a description').max(300),
  hsn: str(20),
  qty: required('Quantity', 0, 1e9, { aboveMin: true }),
  uom: str(20),
  rate: required('Rate', 0, 1e12),
  discPct: z.union([z.number(), z.string(), z.null()]).optional().transform((v) => (v === '' || v === null || v === undefined ? null : Number(v)))
    .refine((v) => v === null || (Number.isFinite(v) && v >= 0 && v <= 100), 'Discount must be between 0 and 100'),
  gstPct: required('GST %', 0, 100),
  vendorMaterialId: z.string().trim().nullable().optional(),
  source: z.object({ itemUid: str(100), lineUid: str(100), label: str(200) }).partial().optional()
});

export const purchaseOrderBody = z.object({
  poNo: z.string().trim().max(30).optional().default(''), // blank = next number
  date: z.string({ required_error: 'PO date is required' }).regex(/^\d{4}-\d{2}-\d{2}$/, 'PO date is required'),
  refNo: str(100),
  refDate: str(20),
  kindAttn: str(100),
  vendorId: z.string().trim().nullable().optional(),
  vendor: z.object({
    name: z.string({ required_error: 'Vendor name is required' }).trim().min(1, 'Vendor name is required').max(200),
    address: str(500),
    state: str(60),
    stateCode: z.string().trim().max(2).default(''), // worked out from the state / GSTIN below
    gstin: z.string().trim().toUpperCase().max(15).default('')
  }).transform((v, ctx) => {
    // The vendor's state decides CGST + SGST (same state) or IGST, so it is needed. Its code is worked out here.
    const r = resolveState(v);
    if (!r.stateCode) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['state'], message: 'Choose the vendor’s state' });
      return z.NEVER;
    }
    return { ...v, state: r.state, stateCode: r.stateCode };
  }),
  productMaster: z.string().trim().nullable().optional(),
  modelNo: str(100),
  machines: z.union([z.number(), z.string(), z.null()]).optional()
    .transform((v) => (v === '' || v === null || v === undefined ? null : Number(v)))
    .refine((v) => v === null || (Number.isInteger(v) && v >= 1 && v <= 10000), 'Number of machines must be a whole number from 1'),
  lines: z.array(line).min(1, 'Add at least one row').max(300),
  paymentTerms: str(200),
  remark: str(500),
  terms: str(2000)
});
