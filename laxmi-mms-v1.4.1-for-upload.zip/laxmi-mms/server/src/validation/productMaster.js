import { z } from 'zod';
import {
  LINE_UOMS, NODE_UOMS, SOURCE_VALUES, NODE_KINDS, ITEM_MODES, STATUSES, PROJECT_ID_PATTERN
} from '../../../shared/constants.js';

const str = (max = 300) => z.string().trim().max(max).default('');
// Blank stays blank (null). Nothing is assumed for the user.
const optionalNumber = (label) => z
  .union([z.number(), z.string(), z.null()])
  .optional()
  .transform((v, ctx) => {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : Number(v);
    if (!Number.isFinite(n) || n < 0) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${label} must be 0 or more` });
      return z.NEVER;
    }
    return n;
  });
const qty = optionalNumber('Quantity');
const rate = z
  .union([z.number(), z.string(), z.null()])
  .optional()
  .transform((v, ctx) => {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : Number(v);
    if (!Number.isFinite(n) || n < 0) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Rate must be 0 or more' });
      return z.NEVER;
    }
    return n;
  });

const line = z.object({
  uid: z.string().min(1),
  material: str(),
  spec: str(),
  cutSize: str(),
  source: z.enum([...SOURCE_VALUES, '']).default(''),
  process: str(),
  vendor: str(),
  qty,
  uom: z.enum([...LINE_UOMS, '']).default(''),
  rate
});

const subAssembly = z.object({
  uid: z.string().min(1),
  code: str(100),
  name: str(),
  qty,
  uom: z.enum([...NODE_UOMS, '']).default(''),
  lines: z.array(line).max(500).default([])
});

const node = z.object({
  uid: z.string().min(1),
  // Older data may say 'assembly' or 'component'; everything is an item now.
  kind: z.string().optional().transform(() => NODE_KINDS[0]),
  mode: z.enum([...ITEM_MODES, '']).default(''),
  code: str(100),
  name: str(),
  qty,
  uom: z.enum([...NODE_UOMS, '']).default(''),
  spec: str(),
  vendor: str(),
  rate,
  lines: z.array(line).max(500).default([]),
  subAssemblies: z.array(subAssembly).max(100).default([])
});

export const productMasterBody = z.object({
  machineName: str(200),
  modelNo: z.string({ required_error: 'Model no is required' }).trim().min(1, 'Model no is required').max(100),
  projectId: z
    .union([z.string(), z.null()])
    .optional()
    .transform((v) => (v ? v.trim() : null))
    .refine((v) => v === null || PROJECT_ID_PATTERN.test(v), 'Project ID must look like PRJ-0000'),
  status: z.enum(STATUSES).default('draft'),
  nodes: z.array(node).max(500).default([])
});

export const listQuery = z.object({
  q: z.string().trim().max(100).optional(),
  status: z.enum(STATUSES).optional()
});
