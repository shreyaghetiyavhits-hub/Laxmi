import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import * as ctrl from '../controllers/purchaseOrderController.js';

const router = Router();
router.get('/', asyncHandler(ctrl.list));
router.get('/next-number', asyncHandler(ctrl.nextNumber));
router.post('/', asyncHandler(ctrl.create));
router.get('/:id', asyncHandler(ctrl.getOne));
router.put('/:id', asyncHandler(ctrl.update));
router.delete('/:id', asyncHandler(ctrl.remove));
export default router;
