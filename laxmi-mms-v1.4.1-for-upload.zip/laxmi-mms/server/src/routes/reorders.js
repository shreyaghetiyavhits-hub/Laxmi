import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import * as ctrl from '../controllers/reorderController.js';

export const reorders = Router();
reorders.get('/', asyncHandler(ctrl.list));
reorders.post('/', asyncHandler(ctrl.create));
reorders.get('/:id', asyncHandler(ctrl.getOne));
reorders.put('/:id', asyncHandler(ctrl.update));
reorders.post('/:id/discard', asyncHandler(ctrl.discard));
reorders.post('/:id/generate', asyncHandler(ctrl.generate));

export const orders = Router();
orders.get('/', asyncHandler(ctrl.listOrders));
orders.get('/:id', asyncHandler(ctrl.getOrder));
