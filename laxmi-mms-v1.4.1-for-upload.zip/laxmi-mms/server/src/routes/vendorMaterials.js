import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import * as mat from '../controllers/vendorMaterialController.js';

const router = Router();
router.get('/:mid/history', asyncHandler(mat.history));
router.put('/:mid', asyncHandler(mat.update));
router.delete('/:mid', asyncHandler(mat.remove));
export default router;
