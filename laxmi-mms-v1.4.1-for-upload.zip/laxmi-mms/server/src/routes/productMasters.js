import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import * as ctrl from '../controllers/productMasterController.js';

const router = Router();
router.get('/', asyncHandler(ctrl.list));
router.post('/', asyncHandler(ctrl.create));
router.get('/:id', asyncHandler(ctrl.getOne));
router.put('/:id', asyncHandler(ctrl.update));
router.delete('/:id', asyncHandler(ctrl.remove));
router.post('/:id/revisions', asyncHandler(ctrl.createRevision));
router.post('/:id/reorder', asyncHandler(ctrl.reorderCopy));
export default router;
