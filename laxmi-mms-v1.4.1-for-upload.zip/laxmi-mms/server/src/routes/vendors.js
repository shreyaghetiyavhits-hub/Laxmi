import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import * as ctrl from '../controllers/vendorController.js';
import * as mat from '../controllers/vendorMaterialController.js';

const router = Router();
router.get('/', asyncHandler(ctrl.list));
router.get('/next-code', asyncHandler(ctrl.nextVendorCode));
router.post('/', asyncHandler(ctrl.create));
router.get('/:id', asyncHandler(ctrl.getOne));
router.put('/:id', asyncHandler(ctrl.update));
router.delete('/:id', asyncHandler(ctrl.remove));
router.get('/:id/purchases', asyncHandler(ctrl.purchases));
router.get('/:id/materials', asyncHandler(mat.list));
router.post('/:id/materials', asyncHandler(mat.create));
export default router;
