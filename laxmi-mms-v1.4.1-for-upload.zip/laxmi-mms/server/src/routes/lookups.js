import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { getLookups } from '../controllers/lookupController.js';

const router = Router();
router.get('/', asyncHandler(getLookups));
export default router;
