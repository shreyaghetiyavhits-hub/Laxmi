import { ZodError } from 'zod';
import mongoose from 'mongoose';

export class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

export function notFound(req, res) {
  res.status(404).json({ message: `No route for ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ message: err.message, ...err.extra });
  }
  if (err instanceof ZodError) {
    return res.status(400).json({
      message: 'Some fields are not valid.',
      issues: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message }))
    });
  }
  if (err instanceof mongoose.Error.CastError) {
    return res.status(404).json({ message: 'Record not found.' });
  }
  if (err instanceof mongoose.Error.ValidationError) {
    return res.status(400).json({
      message: 'Some fields are not valid.',
      issues: Object.values(err.errors).map((e) => ({ path: e.path, message: e.message }))
    });
  }
  if (err && err.code === 11000) {
    return res.status(409).json({ message: 'This number is already used. Please use a different one.' });
  }
  console.error(err);
  return res.status(500).json({ message: 'Something went wrong on the server.' });
}
