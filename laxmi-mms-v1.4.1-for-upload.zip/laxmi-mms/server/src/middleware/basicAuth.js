import { timingSafeEqual } from 'node:crypto';

const same = (a, b) => {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
};

/**
 * Simple username/password for test servers (the browser shows its own sign-in box).
 * Not a replacement for the user login and roles module.
 */
export function basicAuth(username, password) {
  return (req, res, next) => {
    if (req.path === '/api/health') return next(); // hosting health checks
    const header = req.headers.authorization || '';
    const [scheme, encoded] = header.split(' ');
    if (scheme === 'Basic' && encoded) {
      const [u, ...rest] = Buffer.from(encoded, 'base64').toString('utf8').split(':');
      if (same(u, username) && same(rest.join(':'), password)) return next();
    }
    res.set('WWW-Authenticate', 'Basic realm="Laxmi MMS (test)", charset="UTF-8"');
    return res.status(401).send('Please sign in with the username and password you were given.');
  };
}
