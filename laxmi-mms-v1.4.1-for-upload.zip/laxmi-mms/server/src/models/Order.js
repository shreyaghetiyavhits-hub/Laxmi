import mongoose from 'mongoose';

const { Schema } = mongoose;
const text = { type: String, trim: true, default: '' };

// Procurement Order: one customer/project order for a machine, holding its POs.
// Created when a reorder is generated (and available for grouping POs in future).
const OrderSchema = new Schema(
  {
    orderNo: { type: String, trim: true, required: true, unique: true }, // ORD-0001
    date: { type: String, required: true }, // YYYY-MM-DD
    modelNo: text,
    productMaster: { type: Schema.Types.ObjectId, ref: 'ProductMaster', default: null },
    projectId: text,
    customerRef: text,
    remarks: text,
    machine: { type: Schema.Types.Mixed, default: null }, // the machine as ordered (copy of the BOM), for Reorder machine
    poIds: [{ type: Schema.Types.ObjectId, ref: 'PurchaseOrder' }],
    poNos: [String],
    reorderedFrom: {
      orderId: { type: Schema.Types.ObjectId, ref: 'Order', default: null },
      orderNo: text,
      poNos: [String],
      draftId: { type: Schema.Types.ObjectId, ref: 'ReorderDraft', default: null },
      draftNo: text,
      modelNo: text, // set when the order was prepared from a Product master
      reorderOfModelNo: text // set when that Product master is a Reorder copy
    }
  },
  { timestamps: true }
);

export const Order = mongoose.model('Order', OrderSchema);
