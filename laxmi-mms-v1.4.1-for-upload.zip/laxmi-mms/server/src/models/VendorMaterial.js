import mongoose from 'mongoose';

const { Schema } = mongoose;
const text = { type: String, trim: true, default: '' };

// One price on a material's timeline: typed in by hand ("manual") or taken from a purchase order ("po").
const RateEntrySchema = new Schema(
  {
    at: { type: String, required: true }, // YYYY-MM-DD (PO date for "po" entries)
    rate: { type: Number, min: 0, required: true },
    source: { type: String, enum: ['manual', 'po'], required: true },
    poId: { type: Schema.Types.ObjectId, ref: 'PurchaseOrder', default: null },
    poNo: text,
    qty: { type: Number, default: null },
    note: text,
    recordedAt: { type: Date, default: Date.now }
  },
  { _id: false }
);

// Vendor Material Mapping (developer document, section 21). Nothing has a default value.
const VendorMaterialSchema = new Schema(
  {
    vendorId: { type: Schema.Types.ObjectId, ref: 'Vendor', required: true, index: true },
    material: { type: String, trim: true, required: true },
    specification: text,
    unit: text,
    rate: { type: Number, min: 0, default: null }, // agreed rate typed in the master; null = not entered
    gstPct: { type: Number, min: 0, max: 100, default: null }, // GST rate for this material; blank = company standard rate on POs
    moq: { type: Number, min: 0, default: null }, // minimum order quantity
    leadTimeDays: { type: Number, min: 0, default: null },
    preferred: { type: String, enum: ['yes', 'no', ''], default: '' },
    status: { type: String, enum: ['active', 'inactive', ''], default: '' }, // the form requires a choice
    remarks: text,
    history: { type: [RateEntrySchema], default: [] }
  },
  { timestamps: true }
);

VendorMaterialSchema.index({ vendorId: 1, material: 1 });
VendorMaterialSchema.index({ 'history.poId': 1 });

export const VendorMaterial = mongoose.model('VendorMaterial', VendorMaterialSchema);
