import mongoose from 'mongoose';

const { Schema } = mongoose;

// A reorder draft is NOT a purchase order. It holds prepared POs for review and
// becomes purchase orders only through the one-time "generate" action.
const ReorderDraftSchema = new Schema(
  {
    draftNo: { type: String, required: true, unique: true }, // RD-0001
    status: { type: String, enum: ['draft', 'generating', 'generated', 'discarded'], default: 'draft', index: true },
    version: { type: Number, default: 1 }, // optimistic locking for edits
    source: {
      kind: { type: String, enum: ['order', 'pos', 'bom'], default: 'pos' },
      productMasterId: { type: Schema.Types.ObjectId, ref: 'ProductMaster', default: null },
      modelNo: { type: String, default: '' },
      machineName: { type: String, default: '' },
      reorderOfModelNo: { type: String, default: '' },
      revision: { type: Number, default: null },
      included: [String],
      rowCount: Number,
      skippedItems: Number,
      notIncluded: Number,
      orderId: { type: Schema.Types.ObjectId, ref: 'Order', default: null },
      orderNo: { type: String, default: '' },
      poIds: [{ type: Schema.Types.ObjectId, ref: 'PurchaseOrder' }],
      poNos: [String]
    },
    poDate: { type: String, default: '' },
    projectId: { type: String, default: '' },
    customerRef: { type: String, default: '' },
    modelNo: { type: String, default: '' },
    productMaster: { type: Schema.Types.ObjectId, ref: 'ProductMaster', default: null },
    pos: { type: Array, default: [] }, // prepared POs (see shared/reorder.js for the shape)
    // Reorder machine only: an editable copy of the machine and the purchase settings per BOM row.
    machine: { type: Schema.Types.Mixed, default: null },
    purchase: { type: Schema.Types.Mixed, default: null },
    poMeta: { type: Schema.Types.Mixed, default: null },
    saveAsNew: { type: Schema.Types.Mixed, default: null }, // { enabled, modelNo }: also save the copy as a new Product master
    generationKey: { type: String, required: true },
    generated: {
      at: Date,
      orderId: { type: Schema.Types.ObjectId, ref: 'Order', default: null },
      orderNo: String,
      productMasterId: { type: Schema.Types.ObjectId, ref: 'ProductMaster', default: null },
      productMasterModelNo: String,
      poIds: [{ type: Schema.Types.ObjectId, ref: 'PurchaseOrder' }],
      poNos: [String]
    },
    audit: { type: Array, default: [] } // append-only: { at, event, detail }
  },
  { timestamps: true }
);

export const ReorderDraft = mongoose.model('ReorderDraft', ReorderDraftSchema);
