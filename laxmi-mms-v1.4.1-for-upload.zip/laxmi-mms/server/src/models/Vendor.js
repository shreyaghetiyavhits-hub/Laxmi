import mongoose from 'mongoose';

const { Schema } = mongoose;
const text = { type: String, trim: true, default: '' };

// Vendor Master, fields from the developer document (section 21) plus the
// state, state code and GSTIN a purchase order needs. Nothing has a default
// value: blank means "not entered yet".
const VendorSchema = new Schema(
  {
    code: { type: String, trim: true, required: true, unique: true }, // e.g. V0001, automatic when left blank
    name: { type: String, trim: true, required: true },
    contactPerson: text,
    email: text,
    mobile: text,
    address: text,
    state: text,
    stateCode: text,
    gstin: text,
    category: text,
    materialsSupplied: text,
    preferred: { type: String, enum: ['yes', 'no', ''], default: '' },
    leadTimeDays: { type: Number, min: 0, default: null },
    paymentTerms: text,
    status: { type: String, enum: ['active', 'inactive', ''], default: '' }, // the form requires a choice; sample data may leave it blank
    remarks: text
  },
  { timestamps: true }
);

VendorSchema.index({ name: 1 });

export const Vendor = mongoose.model('Vendor', VendorSchema);
