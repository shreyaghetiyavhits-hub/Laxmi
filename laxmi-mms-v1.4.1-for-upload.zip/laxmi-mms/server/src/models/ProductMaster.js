import mongoose from 'mongoose';
import {
  LINE_UOMS, NODE_UOMS, SOURCE_VALUES, NODE_KINDS, ITEM_MODES, STATUSES, PROJECT_ID_PATTERN
} from '../../../shared/constants.js';
import { bomTotals } from '../../../shared/cost.js';

const { Schema } = mongoose;
const text = { type: String, trim: true, default: '' };

// Each sub-document carries a client-generated `uid` instead of a Mongo _id,
// so the React app can keep selection and keys stable before the first save.
const LineSchema = new Schema(
  {
    uid: { type: String, required: true },
    material: text,
    spec: text, // item code / special details, e.g. "8 LH 1"
    cutSize: text, // e.g. "Total length 5400 mm"
    source: { type: String, enum: [...SOURCE_VALUES, ''], default: '' }, // '' = not chosen yet
    process: text, // e.g. "Laser cutting"
    vendor: text,
    qty: { type: Number, min: 0, default: null }, // null = not entered yet
    uom: { type: String, enum: [...LINE_UOMS, ''], default: '' },
    rate: { type: Number, min: 0, default: null } // null = rate pending
  },
  { _id: false }
);

const SubAssemblySchema = new Schema(
  {
    uid: { type: String, required: true },
    code: text,
    name: text,
    qty: { type: Number, min: 0, default: null },
    uom: { type: String, enum: [...NODE_UOMS, ''], default: '' },
    lines: { type: [LineSchema], default: [] }
  },
  { _id: false }
);

const NodeSchema = new Schema(
  {
    uid: { type: String, required: true },
    kind: { type: String, enum: NODE_KINDS, default: 'item' },
    mode: { type: String, enum: [...ITEM_MODES, ''], default: '' }, // '' = made/bought not chosen yet
    code: text,
    name: text,
    qty: { type: Number, min: 0, default: null },
    uom: { type: String, enum: [...NODE_UOMS, ''], default: '' },
    // Used only by bought-out items:
    spec: text,
    vendor: text,
    rate: { type: Number, min: 0, default: null },
    lines: { type: [LineSchema], default: [] },
    subAssemblies: { type: [SubAssemblySchema], default: [] } // sub-items of a made-in-house item
  },
  { _id: false }
);

const ProductMasterSchema = new Schema(
  {
    machineName: text,
    modelNo: { type: String, trim: true, required: true },
    projectId: { type: String, default: null, match: PROJECT_ID_PATTERN },
    revision: { type: Number, default: 0, min: 0 },
    status: { type: String, enum: STATUSES, default: 'draft' },
    previousRevision: { type: Schema.Types.ObjectId, ref: 'ProductMaster', default: null },
    // Set on a copy made with "Reorder": which machine it was copied from.
    reorderOf: {
      productMasterId: { type: Schema.Types.ObjectId, ref: 'ProductMaster', default: null },
      modelNo: { type: String, default: '' },
      revision: { type: Number, default: null },
      at: { type: Date, default: null }
    },
    finalizedAt: { type: Date, default: null },
    nodes: { type: [NodeSchema], default: [] },
    totals: {
      items: { type: Number, default: 0 },
      boughtOut: { type: Number, default: 0 },
      madeInHouse: { type: Number, default: 0 },
      lineCount: { type: Number, default: 0 },
      pendingRates: { type: Number, default: 0 },
      cost: { type: Number, default: 0 }
    }
  },
  { timestamps: true }
);

// One document per model + revision.
ProductMasterSchema.index({ modelNo: 1, revision: 1 }, { unique: true });
ProductMasterSchema.index({ updatedAt: -1 });

// Keep stored totals in step with the nodes, so list pages need no extra maths.
ProductMasterSchema.pre('save', async function () {
  this.totals = bomTotals(this.toObject().nodes);
  if (this.status === 'final' && !this.finalizedAt) this.finalizedAt = new Date();
});

export const ProductMaster = mongoose.model('ProductMaster', ProductMasterSchema);
