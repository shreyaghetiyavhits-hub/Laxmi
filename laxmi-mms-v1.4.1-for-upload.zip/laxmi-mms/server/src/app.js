import express from 'express';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { basicAuth } from './middleware/basicAuth.js';
import cors from 'cors';
import { env } from './config/env.js';
import productMasters from './routes/productMasters.js';
import lookups from './routes/lookups.js';
import purchaseOrders from './routes/purchaseOrders.js';
import vendors from './routes/vendors.js';
import vendorMaterials from './routes/vendorMaterials.js';
import { reorders, orders } from './routes/reorders.js';
import { notFound, errorHandler } from './middleware/errors.js';

export function createApp() {
  const app = express();
  if (env.appUsername && env.appPassword) app.use(basicAuth(env.appUsername, env.appPassword));
  app.use(cors({ origin: env.clientOrigin }));
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (req, res) => res.json({ ok: true }));
  app.use('/api/product-masters', productMasters);
  app.use('/api/lookups', lookups);
  app.use('/api/purchase-orders', purchaseOrders);
  app.use('/api/vendors', vendors);
  app.use('/api/vendor-materials', vendorMaterials);
  // Smart Reorder (v1.1). Set SMART_REORDER_ENABLED=false to switch it off and run exactly like v1.0.
  if (env.smartReorder) {
    app.use('/api/reorders', reorders);
    app.use('/api/orders', orders);
  }

  // Production: the same server also serves the screens (client/dist), so the app has one web address.
  const clientDist = fileURLToPath(new URL('../../client/dist', import.meta.url));
  if (existsSync(path.join(clientDist, 'index.html'))) {
    app.use(express.static(clientDist, { index: false, maxAge: '1h' }));
    app.get(/^\/(?!api\/).*/, (req, res) => res.sendFile(path.join(clientDist, 'index.html')));
  }

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
