import { VendorMaterial } from '../models/VendorMaterial.js';

/**
 * Keeps price history in step with a purchase order: every PO row linked to one of
 * the vendor's materials adds a "po" entry (date, rate, qty, PO no). Saving the PO
 * again replaces its entries, so nothing is counted twice.
 */
export async function syncPoPriceHistory(po) {
  await removePoPriceHistory(po._id);
  if (!po.vendorId) return;
  const byMaterial = new Map();
  for (const line of po.lines || []) {
    if (!line.vendorMaterialId) continue;
    const id = String(line.vendorMaterialId);
    if (!byMaterial.has(id)) byMaterial.set(id, []);
    byMaterial.get(id).push({ at: po.date, rate: line.rate, source: 'po', poId: po._id, poNo: po.poNo, qty: line.qty });
  }
  if (!byMaterial.size) return;
  await VendorMaterial.bulkWrite(
    [...byMaterial.entries()].map(([id, entries]) => ({
      updateOne: { filter: { _id: id, vendorId: po.vendorId }, update: { $push: { history: { $each: entries } } } }
    }))
  );
}

export async function removePoPriceHistory(poId) {
  await VendorMaterial.updateMany({ 'history.poId': poId }, { $pull: { history: { poId } } });
}
