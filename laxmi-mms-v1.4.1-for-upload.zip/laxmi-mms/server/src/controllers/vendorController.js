import { Vendor } from '../models/Vendor.js';
import { VendorMaterial } from '../models/VendorMaterial.js';
import { PurchaseOrder } from '../models/PurchaseOrder.js';
import { vendorBody } from '../validation/vendor.js';
import { nextPoNumber } from '../../../shared/po.js';
import { HttpError } from '../middleware/errors.js';
import { vendorPurchaseSummary } from '../../../shared/priceHistory.js';

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const nextCode = async () => `V${nextPoNumber(await Vendor.distinct('code'))}`;

/** GET /api/vendors?q=&status= */
export async function list(req, res) {
  const q = String(req.query.q || '').trim().slice(0, 100);
  const filter = {};
  if (req.query.status === 'active' || req.query.status === 'inactive') filter.status = req.query.status;
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ name: rx }, { code: rx }, { contactPerson: rx }, { gstin: rx }, { materialsSupplied: rx }];
  }
  const items = await Vendor.find(filter).sort({ name: 1 }).limit(1000).lean();
  res.json({ items });
}

export async function nextVendorCode(req, res) {
  res.json({ code: await nextCode() });
}

export async function getOne(req, res) {
  const doc = await Vendor.findById(req.params.id).lean();
  if (!doc) throw new HttpError(404, 'Vendor not found.');
  res.json(doc);
}

async function assertUnique(body, id) {
  const sameName = await Vendor.findOne({ name: new RegExp(`^${escapeRegex(body.name)}$`, 'i'), _id: { $ne: id } }).lean();
  if (sameName) throw new HttpError(409, `A vendor called “${sameName.name}” already exists (${sameName.code}).`, { existingId: sameName._id });
  if (await Vendor.exists({ code: body.code, _id: { $ne: id } })) throw new HttpError(409, `Vendor code ${body.code} is already used.`);
}

export async function create(req, res) {
  const body = vendorBody.parse(req.body);
  if (!body.code) body.code = await nextCode();
  await assertUnique(body, undefined);
  const doc = await Vendor.create(body);
  res.status(201).json(doc.toObject());
}

export async function update(req, res) {
  const doc = await Vendor.findById(req.params.id);
  if (!doc) throw new HttpError(404, 'Vendor not found.');
  const body = vendorBody.parse(req.body);
  if (!body.code) body.code = doc.code;
  await assertUnique(body, doc._id);
  doc.set(body);
  await doc.save();
  res.json(doc.toObject());
}

/** Vendors already used on a purchase order are set to Inactive instead of deleted. */
export async function remove(req, res) {
  const doc = await Vendor.findById(req.params.id);
  if (!doc) throw new HttpError(404, 'Vendor not found.');
  const used = await PurchaseOrder.countDocuments({ vendorId: doc._id });
  if (used) throw new HttpError(409, `${doc.name} is on ${used} purchase order(s), so it cannot be deleted. Set its status to Inactive instead.`);
  await VendorMaterial.deleteMany({ vendorId: doc._id }); // its rate list goes with it (no PO used it)
  await doc.deleteOne();
  res.status(204).end();
}

/** GET /api/vendors/:id/purchases → every PO for this vendor, totals and what was bought */
export async function purchases(req, res) {
  const vendor = await Vendor.findById(req.params.id).lean();
  if (!vendor) throw new HttpError(404, 'Vendor not found.');
  const pos = await PurchaseOrder.find({ vendorId: vendor._id }).sort({ date: -1, poNo: -1 }).lean();
  res.json(vendorPurchaseSummary(pos));
}
