import { ProductMaster } from '../models/ProductMaster.js';
import { productMasterBody, listQuery } from '../validation/productMaster.js';
import { finalIssues } from '../../../shared/validation.js';
import { HttpError } from '../middleware/errors.js';
import { nextReorderModelNo } from '../../../shared/reorder.js';

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

async function findOr404(id) {
  const doc = await ProductMaster.findById(id);
  if (!doc) throw new HttpError(404, 'Product master not found.');
  return doc;
}

function assertFinalReady(body) {
  if (body.status !== 'final') return;
  const issues = finalIssues(body);
  if (issues.length) {
    throw new HttpError(422, 'Fix these items before saving as final, or save as a draft.', { issues });
  }
}

/** GET /api/product-masters?q=&status= */
export async function list(req, res) {
  const { q, status } = listQuery.parse(req.query);
  const filter = {};
  if (status) filter.status = status;
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ modelNo: rx }, { machineName: rx }, { projectId: rx }];
  }
  const items = await ProductMaster.find(filter)
    .select('machineName modelNo projectId revision status totals updatedAt finalizedAt reorderOf')
    .sort({ updatedAt: -1 })
    .limit(200)
    .lean();
  res.json({ items });
}

/** GET /api/product-masters/:id */
export async function getOne(req, res) {
  const doc = await ProductMaster.findById(req.params.id).lean();
  if (!doc) throw new HttpError(404, 'Product master not found.');
  res.json(doc);
}

/** POST /api/product-masters */
export async function create(req, res) {
  const body = productMasterBody.parse(req.body);
  assertFinalReady(body);
  const exists = await ProductMaster.exists({ modelNo: body.modelNo });
  if (exists) {
    throw new HttpError(409, `A BOM for model ${body.modelNo} already exists. Open it and create a new revision instead.`, {
      existingId: exists._id
    });
  }
  const doc = await ProductMaster.create({ ...body, revision: 0 });
  res.status(201).json(doc.toObject());
}

/** PUT /api/product-masters/:id  (drafts only) */
export async function update(req, res) {
  const doc = await findOr404(req.params.id);
  if (doc.status === 'final') {
    throw new HttpError(409, `R${doc.revision} is final and locked. Create a new revision to change it.`, { code: 'FINAL_LOCKED' });
  }
  const body = productMasterBody.parse(req.body);
  assertFinalReady(body);
  if (body.modelNo !== doc.modelNo) {
    const clash = await ProductMaster.exists({ modelNo: body.modelNo, _id: { $ne: doc._id } });
    if (clash) throw new HttpError(409, `Model no ${body.modelNo} is already used by another BOM.`);
  }
  doc.set(body);
  await doc.save();
  res.json(doc.toObject());
}

/** POST /api/product-masters/:id/revisions  → new draft copy with revision + 1 */
export async function createRevision(req, res) {
  const source = await findOr404(req.params.id);
  const draftExists = await ProductMaster.exists({ modelNo: source.modelNo, status: 'draft' });
  if (draftExists) {
    throw new HttpError(409, `Model ${source.modelNo} already has a draft revision. Finish or delete it first.`, {
      existingId: draftExists._id
    });
  }
  const latest = await ProductMaster.findOne({ modelNo: source.modelNo }).sort({ revision: -1 }).select('revision').lean();
  const plain = source.toObject();
  const doc = await ProductMaster.create({
    machineName: plain.machineName,
    modelNo: plain.modelNo,
    projectId: plain.projectId,
    nodes: plain.nodes,
    status: 'draft',
    revision: (latest?.revision ?? source.revision) + 1,
    previousRevision: source._id
  });
  res.status(201).json(doc.toObject());
}

/** DELETE /api/product-masters/:id  (drafts only) */
export async function remove(req, res) {
  const doc = await findOr404(req.params.id);
  if (doc.status === 'final') throw new HttpError(409, 'Final BOMs cannot be deleted.');
  await doc.deleteOne();
  res.status(204).end();
}

/**
 * POST /api/product-masters/:id/reorder
 * Makes a full, editable copy of the machine as a NEW Product master (draft), e.g. "LBSL 80-RO1",
 * marked "Reorder of LBSL 80". The original is not changed. No purchase order is created.
 */
export async function reorderCopy(req, res) {
  const source = await findOr404(req.params.id);
  const plain = source.toObject();
  const modelNo = nextReorderModelNo(plain.modelNo, await ProductMaster.distinct('modelNo'));
  const doc = await ProductMaster.create({
    machineName: plain.machineName,
    modelNo,
    projectId: null,
    status: 'draft',
    revision: 0,
    nodes: plain.nodes,
    reorderOf: { productMasterId: plain._id, modelNo: plain.modelNo, revision: plain.revision, at: new Date() }
  });
  res.status(201).json(doc.toObject());
}
