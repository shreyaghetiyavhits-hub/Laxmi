import mongoose from 'mongoose';
import { PurchaseOrder } from '../models/PurchaseOrder.js';
import { purchaseOrderBody } from '../validation/purchaseOrder.js';
import { nextPoNumber } from '../../../shared/po.js';
import { HttpError } from '../middleware/errors.js';
import { syncPoPriceHistory, removePoPriceHistory } from '../services/priceHistory.js';

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

async function allNumbers() {
  return PurchaseOrder.distinct('poNo');
}

function clean(body) {
  const pm = body.productMaster;
  const vid = body.vendorId;
  return {
    ...body,
    productMaster: pm && mongoose.isValidObjectId(pm) ? pm : null,
    vendorId: vid && mongoose.isValidObjectId(vid) ? vid : null,
    lines: body.lines.map((l) => ({ ...l, vendorMaterialId: l.vendorMaterialId && mongoose.isValidObjectId(l.vendorMaterialId) ? l.vendorMaterialId : null }))
  };
}

/** GET /api/purchase-orders?q= */
export async function list(req, res) {
  const q = String(req.query.q || '').trim().slice(0, 100);
  const filter = q
    ? { $or: [{ poNo: new RegExp(escapeRegex(q), 'i') }, { 'vendor.name': new RegExp(escapeRegex(q), 'i') }, { modelNo: new RegExp(escapeRegex(q), 'i') }] }
    : {};
  const items = await PurchaseOrder.find(filter)
    .select('poNo date vendorId vendor.name modelNo machines totals updatedAt lines.uid orderId reorder')
    .sort({ updatedAt: -1 })
    .limit(300)
    .lean();
  res.json({ items });
}

/** GET /api/purchase-orders/next-number */
export async function nextNumber(req, res) {
  res.json({ poNo: nextPoNumber(await allNumbers()) });
}

/** GET /api/purchase-orders/:id */
export async function getOne(req, res) {
  const doc = await PurchaseOrder.findById(req.params.id).lean();
  if (!doc) throw new HttpError(404, 'Purchase order not found.');
  res.json(doc);
}

/** POST /api/purchase-orders */
export async function create(req, res) {
  const body = clean(purchaseOrderBody.parse(req.body));
  if (!body.poNo) body.poNo = nextPoNumber(await allNumbers());
  if (await PurchaseOrder.exists({ poNo: body.poNo })) {
    throw new HttpError(409, `PO No ${body.poNo} is already used. Leave it blank to get the next number.`, {
      nextPoNo: nextPoNumber(await allNumbers())
    });
  }
  const doc = await PurchaseOrder.create(body);
  await syncPoPriceHistory(doc.toObject());
  res.status(201).json(doc.toObject());
}

/** PUT /api/purchase-orders/:id */
export async function update(req, res) {
  const doc = await PurchaseOrder.findById(req.params.id);
  if (!doc) throw new HttpError(404, 'Purchase order not found.');
  const body = clean(purchaseOrderBody.parse(req.body));
  if (!body.poNo) body.poNo = doc.poNo;
  if (body.poNo !== doc.poNo && (await PurchaseOrder.exists({ poNo: body.poNo }))) {
    throw new HttpError(409, `PO No ${body.poNo} is already used.`);
  }
  doc.set(body);
  await doc.save();
  await syncPoPriceHistory(doc.toObject());
  res.json(doc.toObject());
}

/** DELETE /api/purchase-orders/:id */
export async function remove(req, res) {
  const doc = await PurchaseOrder.findByIdAndDelete(req.params.id);
  if (!doc) throw new HttpError(404, 'Purchase order not found.');
  await removePoPriceHistory(doc._id);
  res.status(204).end();
}
