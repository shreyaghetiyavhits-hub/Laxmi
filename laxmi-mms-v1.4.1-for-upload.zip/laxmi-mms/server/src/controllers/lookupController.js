import { ProductMaster } from '../models/ProductMaster.js';
import { DEFAULT_LOOKUPS } from '../../../shared/sampleBom.js';
import { Vendor } from '../models/Vendor.js';

// Starter suggestions come from shared/sampleBom.js. Anything typed into a saved
// BOM is added automatically, because we also read distinct values from MongoDB.
// When the Material / Item / Vendor masters are built, point these at them.
const DEFAULTS = DEFAULT_LOOKUPS;

const merge = (a, b) =>
  [...new Set([...a, ...b].map((s) => String(s || '').trim()).filter(Boolean))].sort((x, y) => x.localeCompare(y));

/** GET /api/lookups → { materials, parts, vendors, processes } */
export async function getLookups(req, res) {
  const [masterVendors, materials, nodeNames, subNames, lineVendors, nodeVendors, processes] = await Promise.all([
    Vendor.distinct('name', { status: { $ne: 'inactive' } }),
    ProductMaster.distinct('nodes.lines.material'),
    ProductMaster.distinct('nodes.name'),
    ProductMaster.distinct('nodes.subAssemblies.name'),
    ProductMaster.distinct('nodes.lines.vendor'),
    ProductMaster.distinct('nodes.vendor'),
    ProductMaster.distinct('nodes.lines.process')
  ]);
  res.json({
    materials: merge(DEFAULTS.materials, materials),
    parts: merge(DEFAULTS.parts, [...nodeNames, ...subNames]),
    vendors: merge(masterVendors, [...lineVendors, ...nodeVendors]),
    processes: merge(DEFAULTS.processes, processes)
  });
}
