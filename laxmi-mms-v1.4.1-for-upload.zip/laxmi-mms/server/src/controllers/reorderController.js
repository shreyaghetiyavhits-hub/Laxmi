import mongoose from 'mongoose';
import { randomUUID } from 'node:crypto';
import { ReorderDraft } from '../models/ReorderDraft.js';
import { Order } from '../models/Order.js';
import { PurchaseOrder } from '../models/PurchaseOrder.js';
import { Vendor } from '../models/Vendor.js';
import { VendorMaterial } from '../models/VendorMaterial.js';
import { HttpError } from '../middleware/errors.js';
import { buildReorderDraft, buildReorderDraftFromBom, checkReorderDraft, posFromDraft, derivePosFromMachine } from '../../../shared/reorder.js';
import { ProductMaster } from '../models/ProductMaster.js';
import { nextPoNumber } from '../../../shared/po.js';
import { syncPoPriceHistory } from '../services/priceHistory.js';

const today = () => new Date().toISOString().slice(0, 10);
const nextNo = async (Model, field, prefix) => `${prefix}${nextPoNumber((await Model.distinct(field)).map((x) => String(x).replace(prefix, '')))}`;
const audit = (event, detail = {}) => ({ at: new Date(), event, detail });

async function mastersFor(vendorIds) {
  const ids = [...new Set(vendorIds.filter(Boolean).map(String))].filter((id) => mongoose.isValidObjectId(id));
  const [vendors, materials] = await Promise.all([Vendor.find({}).lean(), VendorMaterial.find({ vendorId: { $in: ids } }).lean()]);
  return { vendors, materials };
}

/** POST /api/reorders  { orderId } | { poIds: [] } | { productMasterId, include } → new draft. Creates NO purchase order. */
export async function create(req, res) {
  const { orderId, poIds, productMasterId, include, copyMachine } = req.body || {};
  if (productMasterId) return createFromBom(req, res, productMasterId, include, copyMachine !== false);
  let order = null;
  let sourcePos;
  if (orderId) {
    if (!mongoose.isValidObjectId(orderId)) throw new HttpError(404, 'Order not found.');
    order = await Order.findById(orderId).lean();
    if (!order) throw new HttpError(404, 'Order not found.');
    sourcePos = await PurchaseOrder.find({ _id: { $in: order.poIds } }).sort({ poNo: 1 }).lean();
  } else if (Array.isArray(poIds) && poIds.length) {
    const ids = poIds.filter((id) => mongoose.isValidObjectId(id));
    sourcePos = await PurchaseOrder.find({ _id: { $in: ids } }).sort({ poNo: 1 }).lean();
  } else {
    throw new HttpError(400, 'Choose an order or at least one purchase order to reorder.');
  }
  if (!sourcePos.length) throw new HttpError(404, 'The purchase orders to reorder were not found.');
  const { vendors, materials } = await mastersFor(sourcePos.map((p) => p.vendorId));
  const draft = buildReorderDraft({ sourcePos, sourceOrder: order, vendors, materials, uid: randomUUID });
  const doc = await ReorderDraft.create({
    ...draft,
    draftNo: await nextNo(ReorderDraft, 'draftNo', 'RD-'),
    generationKey: randomUUID(),
    audit: [audit('created', { from: order ? `Order ${order.orderNo}` : `PO ${draft.source.poNos.join(', ')}` })]
  });
  res.status(201).json(doc.toObject());
}

/** Reorder a whole machine from its BOM: one prepared PO per supplier. */
async function createFromBom(req, res, productMasterId, include, copyMachine) {
  if (!mongoose.isValidObjectId(productMasterId)) throw new HttpError(404, 'Product master not found.');
  const productMaster = await ProductMaster.findById(productMasterId).lean();
  if (!productMaster) throw new HttpError(404, 'Product master not found.');
  const [vendors, materials, pastPos] = await Promise.all([
    Vendor.find({}).lean(),
    VendorMaterial.find({}).lean(),
    // POs of this machine and, for a reorder copy, of the machine it was copied from (suppliers and rates come from them)
    PurchaseOrder.find({ $or: [
      { productMaster: { $in: [productMaster._id, productMaster.reorderOf?.productMasterId].filter(Boolean) } },
      { modelNo: { $in: [productMaster.modelNo, productMaster.reorderOf?.modelNo].filter(Boolean) } }
    ] }).lean()
  ]);
  const inc = include && typeof include === 'object' ? { BOC: !!include.BOC, OUT: !!include.OUT, IH: !!include.IH, '': !!include[''] } : undefined;
  const draft = buildReorderDraftFromBom({ productMaster, vendors, materials, pastPos, include: inc, uid: randomUUID, copyMachine });
  if (!draft.pos.length) throw new HttpError(400, 'Nothing to order with these choices. Include more kinds of rows, or complete the BOM first.');
  const doc = await ReorderDraft.create({
    ...draft,
    draftNo: await nextNo(ReorderDraft, 'draftNo', 'RD-'),
    generationKey: randomUUID(),
    audit: [audit('created', { from: `Product master ${productMaster.modelNo} R${productMaster.revision ?? 0}`, rows: draft.source.rowCount })]
  });
  res.status(201).json(doc.toObject());
}

/** GET /api/reorders?status= */
export async function list(req, res) {
  const filter = {};
  if (['draft', 'generated', 'discarded'].includes(req.query.status)) filter.status = req.query.status;
  const items = await ReorderDraft.find(filter).select('-pos -audit').sort({ updatedAt: -1 }).limit(300).lean();
  res.json({ items });
}

/** GET /api/reorders/:id */
export async function getOne(req, res) {
  if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Reorder draft not found.');
  const doc = await ReorderDraft.findById(req.params.id).lean();
  if (!doc) throw new HttpError(404, 'Reorder draft not found.');
  res.json(doc);
}

/** PUT /api/reorders/:id  — save edits (only while it is a draft). Sends `version`; a stale version is refused. */
export async function update(req, res) {
  const { version, poDate = '', projectId = '', customerRef = '', pos, change, machine, purchase, poMeta, saveAsNew } = req.body || {};
  if (!Array.isArray(pos)) throw new HttpError(400, 'Prepared POs are missing.');
  const machineFields = machine ? { machine, purchase: purchase || {}, poMeta: poMeta || {}, saveAsNew: saveAsNew || { enabled: false, modelNo: '' } } : {};
  const doc = await ReorderDraft.findOneAndUpdate(
    { _id: req.params.id, status: 'draft', version },
    {
      $set: { poDate, projectId, customerRef, pos, ...machineFields },
      $inc: { version: 1 },
      ...(change ? { $push: { audit: audit('edited', { change: String(change).slice(0, 300) }) } } : {})
    },
    { new: true }
  ).lean();
  if (!doc) {
    const now = await ReorderDraft.findById(req.params.id).select('status version').lean();
    if (!now) throw new HttpError(404, 'Reorder draft not found.');
    if (now.status !== 'draft') throw new HttpError(409, `This draft is ${now.status} and can no longer be changed.`, { code: 'NOT_DRAFT' });
    throw new HttpError(409, 'Someone else changed this draft. Reload to see the latest version.', { code: 'STALE' });
  }
  res.json(doc);
}

/** POST /api/reorders/:id/discard — no purchase order is created or changed */
export async function discard(req, res) {
  const doc = await ReorderDraft.findOneAndUpdate(
    { _id: req.params.id, status: 'draft' },
    { $set: { status: 'discarded' }, $push: { audit: audit('discarded') } },
    { new: true }
  ).lean();
  if (!doc) throw new HttpError(409, 'Only an open draft can be discarded.');
  res.json(doc);
}

/**
 * POST /api/reorders/:id/generate  { generationKey }
 * The ONLY place where a reorder creates purchase orders. Runs once per draft:
 * repeated calls (double click, refresh, two tabs) return the same POs.
 */
export async function generate(req, res) {
  const { generationKey } = req.body || {};
  const draft = await ReorderDraft.findById(req.params.id).lean();
  if (!draft) throw new HttpError(404, 'Reorder draft not found.');
  if (generationKey !== draft.generationKey) throw new HttpError(400, 'This confirmation does not belong to this draft. Reload and try again.');
  if (draft.status === 'generated') return res.json({ alreadyGenerated: true, draft });
  if (draft.status !== 'draft') throw new HttpError(409, `This draft is ${draft.status}.`);

  // Lock: only one request can move the draft from "draft" to "generating".
  const locked = await ReorderDraft.findOneAndUpdate({ _id: draft._id, status: 'draft', version: draft.version }, { $set: { status: 'generating' } }, { new: true }).lean();
  if (!locked) {
    // Another click is generating this draft right now: wait for it and return the same POs.
    let now = await ReorderDraft.findById(draft._id).lean();
    for (let i = 0; i < 20 && now?.status === 'generating'; i += 1) {
      await new Promise((r) => setTimeout(r, 250));
      now = await ReorderDraft.findById(draft._id).lean();
    }
    if (now?.status === 'generated') return res.json({ alreadyGenerated: true, draft: now });
    throw new HttpError(409, 'This draft is being generated or was just changed. Reload to see its status.');
  }

  const created = [];
  try {
    // Check again against TODAY's masters: anything inactive or missing stops generation.
    let { vendors, materials } = await mastersFor(locked.pos.map((p) => p.vendorId));
    if (locked.machine) {
      // The machine copy is the source of truth: work the POs out from it again on the server.
      locked.pos = derivePosFromMachine(locked, vendors);
      ({ vendors, materials } = await mastersFor(locked.pos.map((p) => p.vendorId)));
    }
    const check = checkReorderDraft(locked, { vendors, materials, today: today() });
    const newModelNo = locked.machine && locked.saveAsNew?.enabled ? String(locked.saveAsNew.modelNo || '').trim() : '';
    if (locked.machine && locked.saveAsNew?.enabled) {
      if (!newModelNo) check.blocks.push({ message: 'Enter the model no for the new Product master, or untick “Save as a new Product master”.' });
      else if (await ProductMaster.exists({ modelNo: newModelNo })) check.blocks.push({ message: `Model no ${newModelNo} already exists. Choose another model no for the new Product master.` });
      check.ok = check.blocks.length === 0;
    }
    if (!check.ok) {
      await ReorderDraft.updateOne({ _id: locked._id }, { $set: { status: 'draft' }, $push: { audit: audit('generation-stopped', { blocks: check.blocks.map((b) => b.message) }) } });
      throw new HttpError(409, 'Nothing was generated: please fix these first.', { code: 'CHECK_FAILED', issues: check.blocks });
    }
    let newPm = null;
    if (newModelNo) {
      newPm = await ProductMaster.create({
        machineName: locked.machine.machineName, modelNo: newModelNo, status: 'draft',
        nodes: locked.machine.nodes.map((n) => ({ ...n, kind: 'item' }))
      });
      created.newPm = newPm;
    }
    const payloads = posFromDraft(locked, { vendors }).map((p) => (newPm ? { ...p, productMaster: newPm._id, modelNo: newPm.modelNo } : p));
    const orderNo = await nextNo(Order, 'orderNo', 'ORD-');
    const order = await Order.create({
      orderNo, date: locked.poDate, modelNo: newPm ? newPm.modelNo : locked.modelNo, productMaster: newPm ? newPm._id : locked.productMaster,
      projectId: locked.projectId, customerRef: locked.customerRef,
      machine: locked.machine ? { ...locked.machine, modelNo: newPm ? newPm.modelNo : locked.machine.modelNo } : null,
      reorderedFrom: { orderId: locked.source.orderId, orderNo: locked.source.orderNo, poNos: locked.source.poNos, draftId: locked._id, draftNo: locked.draftNo, modelNo: locked.source.kind === 'bom' ? locked.source.modelNo : '', reorderOfModelNo: locked.source.reorderOfModelNo || '' }
    });
    for (const p of payloads) {
      const poNo = nextPoNumber(await PurchaseOrder.distinct('poNo'));
      const po = await PurchaseOrder.create({ ...p, poNo, orderId: order._id, reorder: { ...p.reorder, draftId: locked._id, draftNo: locked.draftNo } });
      created.push(po);
      await syncPoPriceHistory(po.toObject());
    }
    order.poIds = created.map((p) => p._id);
    order.poNos = created.map((p) => p.poNo);
    await order.save();
    const done = await ReorderDraft.findByIdAndUpdate(
      locked._id,
      {
        $set: {
          status: 'generated', pos: locked.pos,
          generated: { at: new Date(), orderId: order._id, orderNo, poIds: order.poIds, poNos: order.poNos, productMasterId: newPm?._id || null, productMasterModelNo: newPm?.modelNo || '' }
        },
        $push: { audit: audit('generated', { orderNo, poNos: order.poNos }) }
      },
      { new: true }
    ).lean();
    res.status(201).json({ draft: done, order: order.toObject() });
  } catch (err) {
    if (created.length || created.newPm) {
      // Roll back anything half-made, so a retry starts clean.
      const { removePoPriceHistory } = await import('../services/priceHistory.js');
      for (const po of created) await removePoPriceHistory(po._id);
      await PurchaseOrder.deleteMany({ _id: { $in: created.map((p) => p._id) } });
      await Order.deleteMany({ 'reorderedFrom.draftId': locked._id });
    }
    if (created.newPm) await ProductMaster.deleteOne({ _id: created.newPm._id });
    if (!(err instanceof HttpError)) {
      await ReorderDraft.updateOne({ _id: locked._id, status: 'generating' }, { $set: { status: 'draft' }, $push: { audit: audit('generation-failed', { error: err.message }) } });
    }
    throw err;
  }
}

/** GET /api/orders and /api/orders/:id */
export async function listOrders(req, res) {
  const items = await Order.find({}).sort({ createdAt: -1 }).limit(300).lean();
  res.json({ items });
}

export async function getOrder(req, res) {
  if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Order not found.');
  const order = await Order.findById(req.params.id).lean();
  if (!order) throw new HttpError(404, 'Order not found.');
  const pos = await PurchaseOrder.find({ _id: { $in: order.poIds } }).sort({ poNo: 1 }).lean();
  res.json({ ...order, pos });
}
