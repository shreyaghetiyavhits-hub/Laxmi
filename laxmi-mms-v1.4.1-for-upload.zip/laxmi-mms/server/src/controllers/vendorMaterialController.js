import mongoose from 'mongoose';
import { Vendor } from '../models/Vendor.js';
import { VendorMaterial } from '../models/VendorMaterial.js';
import { vendorMaterialBody } from '../validation/vendorMaterial.js';
import { HttpError } from '../middleware/errors.js';
import { priceStats, latestEntry } from '../../../shared/priceHistory.js';

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const today = () => new Date().toISOString().slice(0, 10);

const withCurrent = (m) => ({ ...m, current: latestEntry(m.history) });

async function vendorOr404(id) {
  if (!mongoose.isValidObjectId(id)) throw new HttpError(404, 'Vendor not found.');
  const v = await Vendor.findById(id).lean();
  if (!v) throw new HttpError(404, 'Vendor not found.');
  return v;
}

async function assertUnique(vendorId, body, id) {
  const clash = await VendorMaterial.findOne({
    vendorId, material: new RegExp(`^${escapeRegex(body.material)}$`, 'i'), specification: body.specification, _id: { $ne: id }
  }).lean();
  if (clash) throw new HttpError(409, `${clash.material}${clash.specification ? ` (${clash.specification})` : ''} is already in this vendor's list.`);
}

/** GET /api/vendors/:id/materials */
export async function list(req, res) {
  await vendorOr404(req.params.id);
  const items = await VendorMaterial.find({ vendorId: req.params.id }).sort({ material: 1 }).lean();
  res.json({ items: items.map(withCurrent) });
}

/** POST /api/vendors/:id/materials */
export async function create(req, res) {
  const vendor = await vendorOr404(req.params.id);
  const { rateDate, ...body } = vendorMaterialBody.parse(req.body);
  await assertUnique(vendor._id, body, undefined);
  const history = body.rate === null ? [] : [{ at: rateDate || today(), rate: body.rate, source: 'manual', note: 'First rate entered' }];
  const doc = await VendorMaterial.create({ ...body, vendorId: vendor._id, history });
  res.status(201).json(withCurrent(doc.toObject()));
}

/** PUT /api/vendor-materials/:mid  — a changed rate is added to the history */
export async function update(req, res) {
  const doc = await VendorMaterial.findById(req.params.mid);
  if (!doc) throw new HttpError(404, 'Material not found.');
  const { rateDate, ...body } = vendorMaterialBody.parse(req.body);
  await assertUnique(doc.vendorId, body, doc._id);
  if (body.rate !== null && body.rate !== doc.rate) {
    doc.history.push({ at: rateDate || today(), rate: body.rate, source: 'manual', note: doc.history.length ? 'Rate updated' : 'First rate entered' });
  }
  doc.set(body);
  await doc.save();
  res.json(withCurrent(doc.toObject()));
}

/** DELETE /api/vendor-materials/:mid — refused once POs have used it, to keep the history */
export async function remove(req, res) {
  const doc = await VendorMaterial.findById(req.params.mid);
  if (!doc) throw new HttpError(404, 'Material not found.');
  const poCount = new Set(doc.history.filter((h) => h.source === 'po').map((h) => String(h.poId))).size;
  if (poCount) throw new HttpError(409, `${doc.material} is on ${poCount} purchase order(s), so its price history is kept. Set it to Inactive instead.`);
  await doc.deleteOne();
  res.status(204).end();
}

/** GET /api/vendor-materials/:mid/history → the material, its price stats and other vendors' rates */
export async function history(req, res) {
  const doc = await VendorMaterial.findById(req.params.mid).lean();
  if (!doc) throw new HttpError(404, 'Material not found.');
  const others = await VendorMaterial.find({
    _id: { $ne: doc._id }, material: new RegExp(`^${escapeRegex(doc.material)}$`, 'i')
  }).lean();
  const vendors = await Vendor.find({ _id: { $in: others.map((o) => o.vendorId) } }).select('name code status').lean();
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  res.json({
    material: withCurrent(doc),
    stats: priceStats(doc.history),
    otherVendors: others.map((o) => ({
      _id: o._id, vendorId: o.vendorId, vendorName: vendorById.get(String(o.vendorId))?.name || '', vendorCode: vendorById.get(String(o.vendorId))?.code || '',
      specification: o.specification, unit: o.unit, status: o.status, current: latestEntry(o.history)
    }))
  });
}
