// Sample data for a fresh test server, the same as the hosted demo:
// the LBSL 80 machine, vendors Vishwakarma and Gracefull, their materials, and PO 0085.
// Only facts from the client's documents are used; anything they do not state is left blank.

import { randomUUID } from 'node:crypto';
import { ProductMaster } from '../models/ProductMaster.js';
import { Vendor } from '../models/Vendor.js';
import { VendorMaterial } from '../models/VendorMaterial.js';
import { PurchaseOrder } from '../models/PurchaseOrder.js';
import { buildLbsl80Nodes, SAMPLE_MACHINE } from '../../../shared/sampleBom.js';
import { syncPoPriceHistory } from '../services/priceHistory.js';

export async function seedSampleData({ log = console.log } = {}) {
  const done = [];
  if (!(await ProductMaster.exists({ modelNo: SAMPLE_MACHINE.modelNo }))) {
    await ProductMaster.create({ ...SAMPLE_MACHINE, status: 'draft', nodes: buildLbsl80Nodes(randomUUID) });
    done.push(`Product master ${SAMPLE_MACHINE.modelNo}`);
  }

  let vishwakarma = await Vendor.findOne({ name: 'VISHWAKARMA DIES & TOOLS INDUSTRIES' });
  if (!vishwakarma) {
    vishwakarma = await Vendor.create({
      code: 'V0001', name: 'VISHWAKARMA DIES & TOOLS INDUSTRIES', status: '',
      address: 'PLOT NO 5/34, PHASE-1, OPP. MARUTI\nESTATE, GIDC, VATVA, AHMEDABAD.', state: 'GUJARAT', stateCode: '24', remarks: 'From PO 0085'
    });
    done.push('vendor Vishwakarma');
  }
  let gracefull = await Vendor.findOne({ name: 'Gracefull' });
  if (!gracefull) {
    gracefull = await Vendor.create({ code: 'V0002', name: 'Gracefull', status: '', remarks: 'From the LBSL 80 BOM' });
    await VendorMaterial.create({ vendorId: gracefull._id, material: '3/4" leveling bolt', status: '', remarks: 'From the LBSL 80 BOM' });
    done.push('vendor Gracefull');
  }

  if (!(await PurchaseOrder.exists({ poNo: '0085' }))) {
    // PO 0085 exactly as printed; its rows become Vishwakarma's material list with the prices paid.
    const rows = [
      ['SPROKET 17 T X 24 HOLE X 1/4 KEYWAY', 2, 'NOS', 575],
      ['SPROKET 17T X 24 HOLE', 2, 'NOS', 550],
      ['GREEN STRIP 1250 X 25 X 12MM 3MM SLOT', 3, 'NOS', 425],
      ['BELT SS 304 3.5', 16, 'FT', 415],
      ['RETURN ROLLER', 4, 'NOS', 100],
      ['KNOB', 25, 'NOS', 108]
    ];
    const lines = [];
    for (const [description, qty, uom, rate] of rows) {
      const m = await VendorMaterial.create({ vendorId: vishwakarma._id, material: description, unit: uom, gstPct: 18, status: '' });
      lines.push({ uid: randomUUID(), description, hsn: '', qty, uom, rate, discPct: null, gstPct: 18, vendorMaterialId: m._id, source: {} });
    }
    const po = await PurchaseOrder.create({
      poNo: '0085', date: '2026-04-24', refNo: 'EKTA RR', vendorId: vishwakarma._id,
      vendor: { name: vishwakarma.name, address: vishwakarma.address, state: 'GUJARAT', stateCode: '24', gstin: '' },
      lines
    });
    await syncPoPriceHistory(po.toObject());
    done.push('PO 0085 and Vishwakarma’s material prices');
  }
  log(done.length ? `Sample data loaded: ${done.join(', ')}.` : 'Sample data already present.');
}
