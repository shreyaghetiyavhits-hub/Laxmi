// Loads the sample data (LBSL 80, vendors, their materials, PO 0085) into the database.
//   npm run seed            → adds whatever is missing
//   npm run seed -- --reset → first deletes LBSL 80 and PO 0085 so they are loaded fresh

import { connectDb, disconnectDb } from '../config/db.js';
import { ProductMaster } from '../models/ProductMaster.js';
import { PurchaseOrder } from '../models/PurchaseOrder.js';
import { seedSampleData } from './sampleData.js';

async function run() {
  await connectDb();
  if (process.argv.includes('--reset')) {
    await ProductMaster.deleteMany({ modelNo: 'LBSL 80' });
    await PurchaseOrder.deleteMany({ poNo: '0085' });
    console.log('Removed LBSL 80 and PO 0085.');
  }
  await seedSampleData();
  await disconnectDb();
}

run().catch(async (err) => {
  console.error('Seed failed:', err.message);
  await disconnectDb().catch(() => {});
  process.exit(1);
});
