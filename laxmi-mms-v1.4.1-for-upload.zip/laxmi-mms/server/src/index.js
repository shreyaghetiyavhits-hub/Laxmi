import { createApp } from './app.js';
import { connectDb } from './config/db.js';
import { env } from './config/env.js';
import { ProductMaster } from './models/ProductMaster.js';
import { seedSampleData } from './seed/sampleData.js';

try {
  await connectDb();
  if (env.seedSampleData && (await ProductMaster.estimatedDocumentCount()) === 0) {
    await seedSampleData(); // first start on an empty database only
  }
  createApp().listen(env.port, () => {
    console.log(`Laxmi MMS running on port ${env.port}${env.appUsername ? ' (password protected)' : ''}`);
  });
} catch (err) {
  console.error('Could not start the app:', err.message);
  process.exit(1);
}
