# Put Laxmi MMS online for client testing

Two ways, pick one.

| | Option A: share the demo link | Option B: real test server |
|---|---|---|
| Time | 2 minutes | about 45 minutes, once |
| Cost | Free | Free plans (limits below) |
| Data | Saved only in each person's own browser | Saved in a real database, everyone sees the same data |
| Good for | Showing the screens | Real testing by the client team |

---

## Option A: share the demo link (2 minutes)

1. Open the live demo in claude.ai.
2. Click **Share** at the top right of the page and copy the link.
3. Send the link to the client.

Each person's changes stay in their own browser, so the client's team will not see each other's work.

---

## Option B: real test server (MongoDB Atlas + GitHub + Render)

You need: the code zip, an email address, and about 45 minutes.
Write every username and password down as you create it.

### Part 1. Database: MongoDB Atlas (free)

1. Go to **https://www.mongodb.com/cloud/atlas/register** and sign up.
2. Create a cluster: choose **M0 (Free)**, provider **AWS**, region **Mumbai (ap-south-1)**. Click **Create**.
3. **Database user**: when asked, create a username (for example `laxmi`) and a password made of
   **letters and numbers only** (symbols like @ # / break the connection string). Save both.
4. **Network access**: choose **Add IP address → Allow access from anywhere (0.0.0.0/0)**. Render's free
   plan has no fixed address, so this is needed. Your data is still protected by the database password.
5. Click **Connect → Drivers**. Copy the connection string. It looks like
   `mongodb+srv://laxmi:<db_password>@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority`
6. Edit it: put your password in place of `<db_password>`, and add the database name `laxmi_mms`
   right after `.mongodb.net/`:
   `mongodb+srv://laxmi:YourPassword123@cluster0.abcde.mongodb.net/laxmi_mms?retryWrites=true&w=majority`
   Keep this. It is your **MONGODB_URI**.

### Part 2. Code: GitHub (private)

1. Create a free account at **https://github.com**.
2. Install **GitHub Desktop** from **https://desktop.github.com** and sign in.
3. Unzip the code zip into a folder, for example `Documents\laxmi-mms`.
   (The folder already contains the full version history v1.0 to v1.4.1.)
4. In GitHub Desktop: **File → Add local repository…** → choose that folder → **Add repository**.
5. Click **Publish repository**. Keep **"Keep this code private"** ticked. Click **Publish**.

### Part 3. Server: Render (free)

1. Go to **https://render.com** and **Sign up with GitHub**. Allow Render to see the new repository.
2. Click **New + → Blueprint**. Pick your repository. Render finds the file `render.yaml`.
3. Render asks for three values:
   - **MONGODB_URI**: the connection string from Part 1, step 6.
   - **APP_USERNAME**: a username for the client, for example `laxmi-test`.
   - **APP_PASSWORD**: a strong password for the client (at least 10 characters).
4. Click **Apply**. The first build takes about 5 minutes. Wait for **Live** (green).
5. Click the web address shown at the top (like `https://laxmi-mms.onrender.com`). Your browser asks for
   the username and password from step 3. You should see Product master with **LBSL 80**.
   On first start the app loads the sample data: LBSL 80, vendors Vishwakarma and Gracefull, and PO 0085.

### Part 4. Share with the client

Send the web address by email, and the username and password separately (for example by phone or
WhatsApp). Ask them to test, and to send a screenshot and a one-line note for anything wrong.

Suggested test list:

1. Product master: open LBSL 80, edit an item, Save as draft, Full BOM view, Print BOM.
2. Vendor master: complete Vishwakarma and Gracefull (status, state), add a material with a rate,
   change the rate and open Price history.
3. Purchase orders: open LBSL 80 → Create PO; check the printout against your PO format.
4. Reorder a PO: Purchase orders → Reorder on PO 0085 → Review and confirm → Generate.
5. Reorder a machine: Product master → Reorder → edit the copy → Prepare purchase orders →
   Review and confirm → Generate.

### Good to know

- **Free plan sleep**: on Render's free plan the app sleeps after about 15 minutes without use. The next
  visit takes up to a minute to wake it. A paid Render plan keeps it awake. Check Render's current prices.
- **Database size**: Atlas M0 gives 512 MB, plenty for testing.
- **Security**: the username and password protect the whole app, but there are no separate users or
  roles yet. Use test data only.
- **Start fresh**: in Atlas, **Browse Collections → laxmi_mms → Drop database**. Then in Render,
  **Manual Deploy → Restart service**. The sample data loads again.
- **Updates**: when you get a new code zip, copy its files over your folder (not the hidden `.git`
  folder), then in GitHub Desktop write a summary like "Update to v1.5", click **Commit to main**
  (or master), then **Push origin**. Render rebuilds and goes live by itself in about 5 minutes.
- **Go back to an earlier version**: in Render, open **Events**, pick an earlier deploy and click
  **Rollback**. The code's version tags are listed in `RESTORE.md`.

### If something goes wrong

| What you see | What to do |
|---|---|
| Render build fails | Open the build log. Most often a value in Part 3, step 3 is missing. |
| "Could not start the app: … authentication failed" in the Render log | The database password in MONGODB_URI is wrong, or contains symbols. Create a new Atlas user with letters and numbers only. |
| "… querySrv … / timed out" in the Render log | Atlas Network access does not allow 0.0.0.0/0 (Part 1, step 4). |
| Browser keeps asking for the password | Check APP_USERNAME and APP_PASSWORD in Render → Environment. |
| Page loads slowly the first time | Free plan waking up; wait up to a minute. |

---

## For developers

- One service: `npm run build` (installs server and client, builds the client) and `npm start`
  (Express serves the API under `/api` and the built screens). Node 20 or newer.
- Settings (environment variables): see `server/.env.example`. `APP_USERNAME` + `APP_PASSWORD` turn on a simple
  sign-in for the whole app; `SEED_SAMPLE_DATA=true` loads the sample data when the database is empty.
- Health check: `GET /api/health` (no password needed).
- Local development is unchanged: `npm run dev:server` and `npm run dev:client`.
