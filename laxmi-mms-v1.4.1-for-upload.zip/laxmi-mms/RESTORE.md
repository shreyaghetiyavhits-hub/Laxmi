# Versions and how to restore an earlier version

| Version | Date | What it adds | Demo link |
|---|---|---|---|
| v1.0 | 2026-10-23 | Product master, Vendor master with materials and price history, Purchase orders, GST by state | https://claude.ai/artifact/W622CCgHhvQgJ6S9MahTN9 (frozen) |
| v1.1 | 2026-10-23 | Smart Reorder from purchase orders: reorder drafts, Orders, one-time generation | https://claude.ai/artifact/Tn8hwCNT7vwyEyfnd5rgQp (frozen) |
| v1.2 | 2026-10-23 | Reorder machine from Product master (POs only) | https://claude.ai/artifact/CbX4m5eQ3ftDLkDBzQ9yBy (frozen) |
| v1.3 | 2026-10-23 | Reorder machine copies the machine (two-tab screen), optional new Product master | https://claude.ai/artifact/GYvo4zanSGXFCxTtTvafaa (frozen) |
| v1.4 | 2026-10-23 | Simple Reorder: copy as a new Product master ("Reorder of …"), then Prepare purchase orders → Review and confirm | https://claude.ai/artifact/M8R31TFBiUDdS3YJ6YfbCk (live) |
| v1.4.1 | 2026-10-26 | Ready to put online: one service, password sign-in, sample data on first start, DEPLOY.md. Same screens as v1.4 | — |

Quickest way back to v1.0 behaviour without changing code: set `SMART_REORDER_ENABLED=false` (API) and build the
client with `VITE_SMART_REORDER=false`. To run the exact code of any version: `git checkout v1.0` … `v1.4.1`.

# How to restore v1.0

**v1.0** (2026-10-23) is the restore point taken before the Smart Reorder module.
It contains: Product master with one item list, BOM print, Vendor master with materials and
price history, Purchase orders (PO 0085 layout), automatic GST state code and GST rate.

## Restore the code

The project is a git repository and v1.0 is a tag.

```bash
git tag                         # lists v1.0 (and later versions)
git checkout v1.0               # look at / run v1.0
git switch -c restore-v1.0 v1.0 # or: make a branch from it and deploy that
```

Without git: unzip `laxmi-bom-items-v1.0-restore-point.zip`, which holds exactly the same files.

## Restore the data

Later versions only ADD collections and fields (for example an Orders collection and a
"reordered from" link on purchase orders). They never rename or remove what v1.0 uses, so
v1.0 runs against the same MongoDB database and simply ignores the newer data.

Before deploying any new version, back up the database:

```bash
mongodump --uri "$MONGODB_URI" --out backup-before-<version>-$(date +%F)
# to put the data back exactly as it was:
mongorestore --uri "$MONGODB_URI" --drop backup-before-<version>-<date>
```

## The hosted demo

- Live demo (gets new versions): https://claude.ai/artifact/M8R31TFBiUDdS3YJ6YfbCk
- v1.0 demo (frozen, never changed): https://claude.ai/artifact/W622CCgHhvQgJ6S9MahTN9
