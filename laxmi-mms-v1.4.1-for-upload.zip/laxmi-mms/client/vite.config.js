import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import { fileURLToPath } from 'node:url';

const sharedDir = fileURLToPath(new URL('../shared', import.meta.url));

export default defineConfig(({ mode }) => {
  const demo = mode === 'demo';
  return {
    // The demo build is one self-contained HTML file that can be hosted anywhere.
    plugins: demo ? [react(), viteSingleFile()] : [react()],
    resolve: {
      alias: { '@shared': sharedDir }
    },
    build: { outDir: demo ? 'dist-demo' : 'dist' },
    server: {
      port: 5173,
      // The cost and validation rules live in ../shared and are used by both apps.
      fs: { allow: ['..'] },
      proxy: { '/api': 'http://localhost:5000' }
    }
  };
});
