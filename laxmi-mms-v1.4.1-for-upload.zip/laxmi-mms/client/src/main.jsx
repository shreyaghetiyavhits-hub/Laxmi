import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, MemoryRouter } from 'react-router-dom';
import App from './App.jsx';
import { IS_DEMO } from './api/productMasters.js';
import { ConfirmProvider } from './components/ConfirmProvider.jsx';
import './styles.css';

// The demo is a single hosted page, so it keeps its routes in memory.
const Router = IS_DEMO ? MemoryRouter : BrowserRouter;

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Router>
      <ConfirmProvider>
        <App />
      </ConfirmProvider>
    </Router>
  </React.StrictMode>
);
