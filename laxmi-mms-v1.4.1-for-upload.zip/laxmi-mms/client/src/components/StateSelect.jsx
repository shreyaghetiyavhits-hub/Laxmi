import { GST_STATES, stateByName } from '@shared/gstStates.js';

/**
 * Indian state drop-down. The GST state code is shown next to it and is never typed:
 * it follows the state chosen (Gujarat → 24).
 */
export function StateSelect({ id, value, onChange, required = false }) {
  const known = stateByName(value);
  const legacy = value && !known; // text saved before the list existed
  return (
    <div className="state-select">
      <select id={id} className={`f ${known ? '' : 'unset'}`} value={known ? known.name : ''} aria-required={required || undefined}
        onChange={(e) => {
          const s = stateByName(e.target.value);
          onChange({ state: s ? s.name : '', stateCode: s ? s.code : '' });
        }}>
        <option value="">Select state…</option>
        {GST_STATES.map((s) => <option key={s.code} value={s.name}>{s.name}</option>)}
      </select>
      <span className={`state-code ${known ? '' : 'none'}`} title="GST state code, filled in from the state">
        {known ? `Code ${known.code}` : 'Code —'}
      </span>
      {legacy && <p className="help pending-text">Saved as “{value}”, which is not in the list. Please choose the state.</p>}
    </div>
  );
}
