// Native <datalist>s give every type-or-pick field its suggestions.
// Inputs refer to them with list="dl-materials" and so on.
export function LookupLists({ lookups }) {
  return (
    <>
      <datalist id="dl-materials">{lookups.materials.map((v) => <option key={v} value={v} />)}</datalist>
      <datalist id="dl-parts">{lookups.parts.map((v) => <option key={v} value={v} />)}</datalist>
      <datalist id="dl-vendors">{lookups.vendors.map((v) => <option key={v} value={v} />)}</datalist>
      <datalist id="dl-processes">{lookups.processes.map((v) => <option key={v} value={v} />)}</datalist>
    </>
  );
}
