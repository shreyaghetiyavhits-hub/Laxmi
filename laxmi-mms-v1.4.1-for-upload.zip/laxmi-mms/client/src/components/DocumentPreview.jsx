import { useEffect, useRef, useState } from 'react';
import { printFrame, downloadHtml } from '../lib/docActions.js';
import { IS_DEMO } from '../api/productMasters.js';
import { Icon } from './Icon.jsx';

/**
 * Full-screen preview of a printable document (BOM sheet, purchase order),
 * with Print and Download. `html` is shown; `fileHtml` is what Download saves.
 */
export function DocumentPreview({ title, subtitle, html, fileHtml, filename, onClose, children }) {
  const dialogRef = useRef(null);
  const frameRef = useRef(null);
  const [note, setNote] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const d = dialogRef.current;
    if (d && typeof d.showModal === 'function' && !d.open) d.showModal();
  }, []);

  function print() {
    setNote(null);
    if (!printFrame(frameRef.current)) {
      setNote({ kind: 'info', text: 'If no print window opened, click Download, open the file, then click “Print / Save as PDF”.' });
    }
  }

  async function download() {
    setBusy(true);
    const result = await downloadHtml(filename, fileHtml || html);
    setNote({ kind: result.ok ? 'ok' : 'info', text: result.message });
    setBusy(false);
  }

  return (
    <dialog ref={dialogRef} className="print-dialog" aria-label={title}
      onCancel={(e) => { e.preventDefault(); onClose(); }}>
      <div className="print-bar">
        <div className="grow min0">
          <h2>{title}</h2>
          {subtitle && <p className="muted small">{subtitle}</p>}
        </div>
        {children}
        <button type="button" className="btn" onClick={download} disabled={busy}><Icon name="download" size={16} /> Download</button>
        <button type="button" className="btn primary" onClick={print}><Icon name="printer" size={16} /> Print</button>
        <button type="button" className="ib" aria-label={`Close ${title.toLowerCase()}`} onClick={onClose}><Icon name="close" /></button>
      </div>
      {(note || IS_DEMO) && (
        <p className={`print-note ${note?.kind || 'info'}`} role="status">
          {note ? note.text : 'In this demo, your browser may block the Print button. If it does, use Download, open the file and print from there.'}
        </p>
      )}
      <iframe ref={frameRef} className="print-frame" title={title} srcDoc={html} />
    </dialog>
  );
}
