import { NavLink, Outlet } from 'react-router-dom';
import { Icon } from './Icon.jsx';
import { IS_DEMO, productMastersApi, purchaseOrdersApi, vendorsApi, vendorMaterialsApi, reordersApi } from '../api/productMasters.js';
import { useConfirm } from './ConfirmProvider.jsx';

// Only Product master is wired up in this module; the rest are placeholders
// for the other MMS modules and stay disabled until those are built.
const NAV = [
  { icon: 'dashboard', label: 'Dashboard' },
  { icon: 'reports', label: 'Reports' },
  { icon: 'history', label: 'History' },
  { icon: 'product', label: 'Product master', to: '/product-master' },
  { icon: 'customers', label: 'Customers' },
  { icon: 'estimation', label: 'Estimation' },
  { icon: 'purchase', label: 'Purchase orders', to: '/purchase-orders' },
  { icon: 'vendors', label: 'Vendor master', to: '/vendors' },
  { icon: 'dispatch', label: 'Dispatch' }
];

export function AppShell() {
  const confirm = useConfirm();
  return (
    <div className="shell">
      <nav className="rail" aria-label="Main menu">
        <span className="rail-logo" aria-label="Laxmi Engineering">L</span>
        {NAV.map((item) =>
          item.to ? (
            <NavLink key={item.label} to={item.to} className="rail-btn" aria-label={item.label} title={item.label}>
              <Icon name={item.icon} size={20} />
            </NavLink>
          ) : (
            <button key={item.label} type="button" className="rail-btn" aria-label={`${item.label} (coming soon)`} title={`${item.label} (coming soon)`} disabled>
              <Icon name={item.icon} size={20} />
            </button>
          )
        )}
      </nav>
      <div className="content">
        {IS_DEMO && (
          <div className="demo-bar" role="note">
            <span className="grow">
              <strong>Demo, simplified version (one item list).</strong> Your changes are saved in this browser only, so other people will not see them.
            </span>
            <button
              type="button"
              className="btn sm"
              onClick={async () => {
                const ok = await confirm({
                  title: 'Reset the sample data?',
                  message: 'Everything you added or changed in this demo, including vendors, their materials, purchase orders, orders and reorder drafts, will be deleted. The LBSL 80 sample, its vendors and PO 0085 come back.',
                  confirmLabel: 'Reset',
                  danger: true
                });
                if (ok) {
                  productMastersApi.reset();
                  purchaseOrdersApi.reset();
                  vendorsApi.reset();
                  vendorMaterialsApi.reset();
                  reordersApi.reset?.();
                  window.location.reload();
                }
              }}
            >
              Reset sample data
            </button>
          </div>
        )}
        <Outlet />
      </div>
    </div>
  );
}
