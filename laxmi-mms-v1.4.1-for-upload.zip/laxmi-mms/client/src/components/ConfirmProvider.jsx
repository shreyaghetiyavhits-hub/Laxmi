import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';

// In-app "Are you sure?" box. We do not use window.confirm because browsers
// and embedded pages can block it silently, which made delete buttons do nothing.
//
// Usage:  const confirm = useConfirm();
//         if (await confirm({ title: 'Remove A1?', confirmLabel: 'Remove', danger: true })) { … }

const ConfirmContext = createContext(null);

export function useConfirm() {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error('useConfirm must be used inside <ConfirmProvider>');
  return ctx;
}

export function ConfirmProvider({ children }) {
  const [request, setRequest] = useState(null);

  const confirm = useCallback(
    (options) =>
      new Promise((resolve) => {
        setRequest({ confirmLabel: 'Confirm', cancelLabel: 'Cancel', ...options, resolve });
      }),
    []
  );

  const finish = (answer) => {
    request?.resolve(answer);
    setRequest(null);
  };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      {request && <ConfirmDialog request={request} onAnswer={finish} />}
    </ConfirmContext.Provider>
  );
}

function ConfirmDialog({ request, onAnswer }) {
  const ref = useRef(null);
  const cancelRef = useRef(null);

  useEffect(() => {
    const dialog = ref.current;
    if (dialog && typeof dialog.showModal === 'function' && !dialog.open) dialog.showModal();
    cancelRef.current?.focus();
  }, []);

  return (
    <dialog
      ref={ref}
      className="dialog"
      aria-labelledby="confirm-title"
      aria-describedby={request.message ? 'confirm-message' : undefined}
      onCancel={(e) => {
        e.preventDefault();
        onAnswer(false);
      }}
    >
      <div className="dialog-body">
        <h2 id="confirm-title">{request.title}</h2>
        {request.message && <p id="confirm-message" className="muted">{request.message}</p>}
      </div>
      <div className="dialog-actions">
        <button ref={cancelRef} type="button" className="btn" onClick={() => onAnswer(false)}>
          {request.cancelLabel}
        </button>
        <button type="button" className={`btn ${request.danger ? 'danger' : 'primary'}`} onClick={() => onAnswer(true)}>
          {request.confirmLabel}
        </button>
      </div>
    </dialog>
  );
}
