import { Navigate, Route, Routes } from 'react-router-dom';
import { AppShell } from './components/AppShell.jsx';
import { ProductMasterListPage } from './features/product-master/ProductMasterListPage.jsx';
import { ProductMasterEditorPage } from './features/product-master/ProductMasterEditorPage.jsx';
import { PurchaseOrdersPage } from './features/purchase-order/PurchaseOrdersPage.jsx';
import { VendorsPage } from './features/vendors/VendorsPage.jsx';
import { VendorDetailPage } from './features/vendors/VendorDetailPage.jsx';
import { ReorderPage } from './features/reorder/ReorderPage.jsx';
import { SMART_REORDER } from './api/productMasters.js';

export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<Navigate to="/product-master" replace />} />
        <Route path="/product-master" element={<ProductMasterListPage />} />
        <Route path="/product-master/new" element={<ProductMasterEditorPage />} />
        <Route path="/product-master/:id" element={<ProductMasterEditorPage />} />
        <Route path="/purchase-orders" element={<PurchaseOrdersPage />} />
        <Route path="/vendors" element={<VendorsPage />} />
        <Route path="/vendors/:id" element={<VendorDetailPage />} />
        {SMART_REORDER && <Route path="/reorder/:id" element={<ReorderPage />} />}
        <Route path="*" element={<Navigate to="/product-master" replace />} />
      </Route>
    </Routes>
  );
}
