import { useEffect, useState } from 'react';
import { lookupsApi } from '../api/productMasters.js';

const EMPTY = { materials: [], parts: [], vendors: [], processes: [] };

/** Suggestions for the type-or-pick fields. Fails quietly: fields still accept typing. */
export function useLookups(refreshKey) {
  const [lookups, setLookups] = useState(EMPTY);
  useEffect(() => {
    let alive = true;
    lookupsApi.get().then((data) => alive && setLookups({ ...EMPTY, ...data })).catch(() => {});
    return () => {
      alive = false;
    };
  }, [refreshKey]);
  return lookups;
}
