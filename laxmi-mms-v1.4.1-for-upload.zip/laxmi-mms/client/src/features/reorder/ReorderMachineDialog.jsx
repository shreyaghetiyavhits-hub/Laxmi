import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { reordersApi } from '../../api/productMasters.js';
import { bomPurchaseRows, BOM_REORDER_SOURCES } from '@shared/reorder.js';
import { plural } from '../../lib/format.js';
import { Icon } from '../../components/Icon.jsx';

/**
 * "Reorder machine": prepares a draft with one PO per supplier from a saved BOM.
 * Nothing is generated here; the user reviews, edits and confirms on the next screen.
 */
export function ReorderMachineDialog({ productMaster, onClose }) {
  const ref = useRef(null);
  const navigate = useNavigate();
  const [include, setInclude] = useState({ BOC: true, OUT: true, IH: false, '': true });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const d = ref.current;
    if (d && typeof d.showModal === 'function' && !d.open) d.showModal();
  }, []);

  const { rows, skipped } = useMemo(() => bomPurchaseRows(productMaster.nodes || []), [productMaster]);
  const count = (key) => rows.filter((r) => (r.source || '') === key).length;
  const chosen = rows.filter((r) => include[r.source || '']).length;

  async function prepare() {
    setBusy(true);
    setError('');
    try {
      const draft = await reordersApi.create({ productMasterId: productMaster._id, include });
      navigate(`/reorder/${draft._id}`);
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  }

  return (
    <dialog ref={ref} className="form-dialog" aria-labelledby="rm-title" onCancel={(e) => { e.preventDefault(); onClose(); }}>
      <header className="form-dialog-head">
        <div className="grow min0">
          <h2 id="rm-title">Reorder machine {productMaster.modelNo}</h2>
          <p className="muted small">{productMaster.machineName || 'Machine'}, revision R{productMaster.revision ?? 0}</p>
        </div>
        <button type="button" className="ib" aria-label="Close" onClick={onClose}><Icon name="close" /></button>
      </header>
      <div className="form-dialog-body">
        <p>All purchase orders for this machine are prepared for you, <strong>one PO per supplier</strong>. You then review, edit, choose the PO date and confirm. <strong>Nothing is generated until you confirm.</strong></p>
        {error && <p className="error-box" role="alert">{error}</p>}
        <fieldset className="form-section">
          <legend>Which BOM rows should be ordered?</legend>
          <div className="src-choices">
            {BOM_REORDER_SOURCES.map((s) => (
              <label key={s.key || 'unset'} className="check big">
                <input type="checkbox" checked={!!include[s.key]} onChange={(e) => setInclude((x) => ({ ...x, [s.key]: e.target.checked }))} />
                <span className="grow">{s.label}</span>
                <span className="muted small num">{plural(count(s.key), 'row', 'rows')}</span>
              </label>
            ))}
          </div>
          {skipped > 0 && <p className="help">{plural(skipped, 'item is', 'items are')} skipped because Made in-house or Bought-out is not chosen in the BOM.</p>}
        </fieldset>
        <fieldset className="form-section">
          <legend>How suppliers and rates are filled in</legend>
          <ul className="rules">
            <li><strong>Supplier:</strong> the vendor named on the material in the BOM, otherwise the one on the last PO for that item, otherwise a supplier whose material list has it (preferred first, then lowest rate). Rows without a supplier are grouped for you to assign.</li>
            <li><strong>Rate:</strong> the supplier’s current rate, otherwise the last PO rate, otherwise the BOM rate.</li>
            <li><strong>GST:</strong> from the supplier’s list, otherwise the last PO, otherwise the standard rate.</li>
            <li><strong>Quantity:</strong> as in the BOM. Everything stays editable.</li>
          </ul>
        </fieldset>
      </div>
      <footer className="form-dialog-foot">
        <span className="muted small grow">{plural(chosen, 'row', 'rows')} will be prepared</span>
        <button type="button" className="btn" onClick={onClose}>Cancel</button>
        <button type="button" className="btn primary" onClick={prepare} disabled={busy || chosen === 0}>{busy ? 'Preparing…' : 'Prepare POs for review'}</button>
      </footer>
    </dialog>
  );
}
