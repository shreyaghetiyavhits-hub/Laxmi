import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { reordersApi, vendorsApi, vendorMaterialsApi, purchaseOrdersApi } from '../../api/productMasters.js';
import { checkReorderDraft, preparedPoAsPo, draftTotals } from '@shared/reorder.js';
import { computePo } from '@shared/po.js';
import { latestEntry } from '@shared/priceHistory.js';
import { resolveState } from '@shared/gstStates.js';
import { GST_RATES } from '@shared/company.js';
import { toNumber } from '@shared/cost.js';
import { buildPoHtml, poDate, poFileName } from '../../lib/poDocument.js';
import { cleanDecimal, formatINR, plural } from '../../lib/format.js';
import { uid } from '../../lib/bom.js';
import { DocumentPreview } from '../../components/DocumentPreview.jsx';
import { useConfirm } from '../../components/ConfirmProvider.jsx';
import { Icon } from '../../components/Icon.jsx';
import { ConfirmGenerateDialog } from './ConfirmGenerateDialog.jsx';
import { MachineReorderPage } from './MachineReorderPage.jsx';

const blank = (v) => v === null || v === undefined || String(v).trim() === '';
const str = (v) => (v === null || v === undefined ? '' : String(v));
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export function ReorderPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const confirm = useConfirm();
  const [draft, setDraft] = useState(null);
  const [vendors, setVendors] = useState([]);
  const [materials, setMaterials] = useState({}); // vendorId -> list
  const [error, setError] = useState('');
  const [saveState, setSaveState] = useState('saved'); // saved | saving | error
  const [message, setMessage] = useState(null);
  const [openMore, setOpenMore] = useState({});
  const [preview, setPreview] = useState(null);
  const [confirming, setConfirming] = useState(false);
  const [showIssues, setShowIssues] = useState(false);
  const saveTimer = useRef(null);
  const pending = useRef(null);
  const versionRef = useRef(0);

  useEffect(() => {
    let alive = true;
    Promise.all([reordersApi.get(id), vendorsApi.list()])
      .then(([d, v]) => {
        if (!alive) return;
        versionRef.current = d.version;
        setDraft(d);
        setVendors(v.items || []);
      })
      .catch((e) => alive && setError(e.message));
    return () => { alive = false; };
  }, [id]);

  // Load the material list of every supplier in the draft (for rates, GST, MOQ and inactive checks).
  const vendorIds = useMemo(() => [...new Set((draft?.pos || []).map((c) => c.vendorId).filter(Boolean))], [draft]);
  useEffect(() => {
    vendorIds.filter((vid) => !materials[vid]).forEach((vid) => {
      vendorMaterialsApi.list(vid).then((r) => setMaterials((m) => ({ ...m, [vid]: r.items || [] }))).catch(() => setMaterials((m) => ({ ...m, [vid]: [] })));
    });
  }, [vendorIds, materials]);

  const allMaterials = useMemo(() => Object.values(materials).flat(), [materials]);
  const vendorById = useMemo(() => new Map(vendors.map((v) => [v._id, v])), [vendors]);
  const editable = draft?.status === 'draft';
  // Check only once every supplier's material list has loaded, so nothing is reported as missing while loading.
  const listsReady = vendorIds.every((vid) => materials[vid]);
  const check = useMemo(
    () => (draft && listsReady ? checkReorderDraft(draft, { vendors, materials: allMaterials, today: today() }) : null),
    [draft, vendors, allMaterials, listsReady]
  );
  const totals = useMemo(() => (draft ? draftTotals(draft, vendors) : null), [draft, vendors]);

  // ---------- saving (automatic, after each change) ----------
  const flush = useCallback(async () => {
    const job = pending.current;
    if (!job) return;
    pending.current = null;
    setSaveState('saving');
    try {
      const saved = await reordersApi.update(id, { version: versionRef.current, poDate: job.draft.poDate, projectId: job.draft.projectId, customerRef: job.draft.customerRef, pos: job.draft.pos, change: job.change });
      versionRef.current = saved.version;
      setSaveState(pending.current ? 'saving' : 'saved');
      if (pending.current) flush();
    } catch (e) {
      setSaveState('error');
      setMessage({ kind: 'err', text: e.message });
    }
  }, [id]);

  // Every edit goes through here: update the screen, then save automatically half a second later.
  const draftRef = useRef(null);
  draftRef.current = draft;
  const change = (fn, description) => {
    const next = fn(draftRef.current);
    draftRef.current = next;
    setDraft(next);
    pending.current = { draft: next, change: description || pending.current?.change };
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(flush, 500);
    setSaveState('saving');
  };
  useEffect(() => () => clearTimeout(saveTimer.current), []);

  const setCard = (cardUid, patch, description) => change((d) => ({ ...d, pos: d.pos.map((c) => (c.uid === cardUid ? { ...c, ...(typeof patch === 'function' ? patch(c) : patch) } : c)) }), description);
  const setRow = (cardUid, rowUid, patch, description) => setCard(cardUid, (c) => ({ lines: c.lines.map((l) => (l.uid === rowUid ? { ...l, ...(typeof patch === 'function' ? patch(l) : patch) } : l)) }), description);

  // ---------- actions ----------
  /** A row moved to a supplier links to that supplier's own material (same name), with its rate and GST. */
  const relink = (l, list) => {
    const name = String(l.material || l.description || '').trim().toLowerCase();
    const m = name ? list.find((x) => x.status !== 'inactive' && x.material.trim().toLowerCase() === name) : null;
    if (!m) return { ...l, vendorMaterialId: null };
    const current = latestEntry(m.history);
    return {
      ...l,
      vendorMaterialId: m._id,
      ...(current && l.rateFrom !== 'typed' ? { rate: current.rate, rateFrom: 'current' } : {}),
      ...(!blank(m.gstPct) ? { gstPct: m.gstPct } : {}),
      uom: l.uom || m.unit || ''
    };
  };
  async function listFor(vendorId) {
    if (!vendorId) return [];
    if (materials[vendorId]) return materials[vendorId];
    const items = (await vendorMaterialsApi.list(vendorId).catch(() => ({ items: [] }))).items || [];
    setMaterials((m) => ({ ...m, [vendorId]: items }));
    return items;
  }

  async function changeSupplier(card, vendorId) {
    const v = vendorById.get(vendorId);
    const list = await listFor(v?._id);
    setCard(card.uid, (c) => ({
      vendorId: v ? v._id : null,
      vendorName: v ? v.name : c.vendorName,
      unassigned: v ? false : c.unassigned,
      kindAttn: v?.contactPerson || '',
      paymentTerms: v?.paymentTerms || '',
      lines: c.lines.map((l) => (v ? relink(l, list) : { ...l, vendorMaterialId: null }))
    }), `Supplier ${card.sourcePoNo ? `of PO from ${card.sourcePoNo} ` : ''}changed to ${v?.name || '—'}`);
  }

  function linkMaterial(card, row, mid) {
    const m = (materials[card.vendorId] || []).find((x) => x._id === mid);
    const current = m ? latestEntry(m.history) : null;
    setRow(card.uid, row.uid, (l) => ({
      vendorMaterialId: m ? m._id : null,
      description: l.description || (m ? [m.material, m.specification].filter(Boolean).join(' ') : ''),
      uom: l.uom || m?.unit || '',
      ...(m && current && blank(l.rate) ? { rate: current.rate, rateFrom: 'current' } : {}),
      ...(m && !blank(m.gstPct) && blank(l.gstPct) ? { gstPct: m.gstPct } : {})
    }), `Row ${row.description || ''} linked to ${m?.material || 'nothing'}`);
  }

  function addRow(card, mid) {
    const m = mid ? (materials[card.vendorId] || []).find((x) => x._id === mid) : null;
    const current = m ? latestEntry(m.history) : null;
    const row = {
      uid: uid(), description: m ? [m.material, m.specification].filter(Boolean).join(' ') : '', hsn: '', qty: '', uom: m?.unit || '',
      rate: current ? current.rate : '', rateFrom: current ? 'current' : '', discPct: null, gstPct: m && !blank(m.gstPct) ? m.gstPct : '',
      vendorMaterialId: m ? m._id : null, bomSource: {}, from: null
    };
    setCard(card.uid, (c) => ({ lines: [...c.lines, row] }), `Row added${m ? `: ${m.material}` : ''}`);
  }

  async function removeRow(card, row) {
    const ok = await confirm({ title: `Remove ${row.description || 'this row'}?`, message: 'It will not be ordered in this reorder. The original PO does not change.', confirmLabel: 'Remove', danger: true });
    if (ok) setCard(card.uid, (c) => ({ lines: c.lines.filter((l) => l.uid !== row.uid) }), `Row removed: ${row.description}`);
  }

  async function moveRow(card, row, target) {
    if (!target) return;
    const targetCard = target.startsWith('card:') ? draftRef.current.pos.find((c) => c.uid === target.slice(5)) : null;
    const v = targetCard ? vendorById.get(targetCard.vendorId) : vendorById.get(target.slice(7));
    const moved = v ? relink(row, await listFor(v._id)) : { ...row, vendorMaterialId: null };
    change((d) => {
      let pos = d.pos.map((c) => (c.uid === card.uid ? { ...c, lines: c.lines.filter((l) => l.uid !== row.uid) } : c));
      if (targetCard) pos = pos.map((c) => (c.uid === targetCard.uid ? { ...c, lines: [...c.lines, moved] } : c));
      else pos = [...pos, newCard(v, [moved])];
      // An emptied "Rows without a supplier" card is removed.
      pos = pos.filter((c) => !(c.unassigned && !c.vendorId && c.lines.length === 0));
      return { ...d, pos };
    }, `Row ${row.description} moved to ${v?.name || 'another PO'}`);
  }

  function newCard(v, lines = []) {
    return { uid: uid(), sourcePoId: null, sourcePoNo: '', vendorId: v?._id || null, vendorName: v?.name || '', excluded: false,
      kindAttn: v?.contactPerson || '', paymentTerms: v?.paymentTerms || '', refNo: '', refDate: '', remark: '', terms: '', lines };
  }

  function revertRow(card, row) {
    if (!row.from) return;
    setRow(card.uid, row.uid, { description: row.from.description, qty: row.from.qty, uom: row.from.uom, rate: row.from.rate, rateFrom: 'source', discPct: row.from.discPct, ...(blank(row.from.gstPct) ? {} : { gstPct: row.from.gstPct }) },
      `Row ${row.description} reverted to ${row.from.label || `PO ${row.from.poNo}`}`);
  }

  async function discard() {
    const ok = await confirm({ title: `Discard draft ${draft.draftNo}?`, message: 'No purchase order will be created or changed.', confirmLabel: 'Discard draft', danger: true });
    if (!ok) return;
    try {
      clearTimeout(saveTimer.current);
      pending.current = null;
      setDraft(await reordersApi.discard(id));
      setMessage({ kind: 'ok', text: 'Draft discarded. No purchase order was created or changed.' });
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    }
  }

  async function openConfirm() {
    clearTimeout(saveTimer.current);
    await flush();
    if (!check.ok) {
      setShowIssues(true);
      return;
    }
    setConfirming(true);
  }

  async function openSavedPo(poId) {
    try {
      const po = await purchaseOrdersApi.get(poId);
      setPreview({ title: `Purchase order ${po.poNo}`, html: buildPoHtml(po, { withBar: false }), fileHtml: buildPoHtml(po, { withBar: true }), filename: poFileName(po) });
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    }
  }

  const goTo = (rowUid, cardUid) => {
    const el = document.getElementById(rowUid ? `row-${rowUid}` : `card-${cardUid}`);
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el?.querySelector('input, select')?.focus();
  };

  if (error) return <div className="page"><p className="error-box" role="alert">{error}</p><Link to="/purchase-orders" className="btn">Back to Purchase orders</Link></div>;
  if (draft?.machine) return <MachineReorderPage key={draft._id} initialDraft={draft} />;
  if (!draft || !check) return <div className="page"><p className="muted">Preparing reorder and checking supplier lists…</p></div>;

  const isBom = draft.source.kind === 'bom';
  const from = isBom ? `machine ${draft.source.modelNo}` : draft.source.orderNo ? `Order ${draft.source.orderNo}` : `PO ${draft.source.poNos.join(', ')}`;
  const original = isBom ? 'Product master' : draft.source.orderNo ? 'order and its POs' : 'PO';
  const activeVendors = vendors.filter((v) => v.status !== 'inactive');

  return (
    <div className="page reorder-page">
      <div className="page-head">
        <Link to={isBom ? `/product-master/${draft.source.productMasterId}` : '/purchase-orders?tab=drafts'} className="ib bordered" aria-label={isBom ? `Back to ${draft.source.modelNo}` : 'Back to Purchase orders'}><Icon name="back" /></Link>
        <div className="grow min0">
          <p className="muted small">{isBom ? `Product master / ${draft.source.modelNo} / ` : 'Purchase orders / Reorder / '}{draft.draftNo}</p>
          <h1 className="row gap center wrap">
            {isBom ? `Purchase orders for ${draft.source.modelNo}` : `Reorder from ${from}`}
            <span className={`rstatus ${draft.status}`}>{{ draft: 'Draft, not generated', generated: 'Generated', discarded: 'Discarded', generating: 'Generating' }[draft.status]}</span>
          </h1>
          {editable && <p className="muted small" aria-live="polite">{saveState === 'saving' ? 'Saving…' : saveState === 'error' ? 'Not saved' : 'All changes saved'}</p>}
        </div>
        {editable && (
          <div className="row gap wrap">
            <button type="button" className="btn danger-text" onClick={discard}>Discard draft</button>
            <button type="button" className="btn primary" onClick={openConfirm}>
              <Icon name="purchase" size={16} /> Review and confirm
            </button>
          </div>
        )}
      </div>

      {message && (
        <div role="status" className={`msg ${message.kind}`}>
          <span className="grow">{message.text}</span>
          <button type="button" className="ib sm" aria-label="Dismiss message" onClick={() => setMessage(null)}><Icon name="close" size={16} /></button>
        </div>
      )}

      {draft.status === 'generated' && (
        <section className="panel done-panel" aria-label="Generated purchase orders">
          <h2>Generated {plural(draft.generated.poNos.length, 'purchase order', 'purchase orders')}</h2>
          <p className="muted">Order {draft.generated.orderNo}, from {from}. The original {original} did not change.</p>
          <div className="row gap wrap">
            {draft.generated.poIds.map((pid, i) => (
              <button key={pid} type="button" className="btn" onClick={() => openSavedPo(pid)}><Icon name="printer" size={16} /> PO {draft.generated.poNos.at(i)}</button>
            ))}
            <Link to="/purchase-orders" className="btn primary">Go to Purchase orders</Link>
          </div>
        </section>
      )}
      {draft.status === 'discarded' && <p className="locked-note"><Icon name="lock" /> This draft was discarded. No purchase order was created or changed.</p>}

      {editable && (
        <p className="info-note"><Icon name="alert" size={16} />
          {isBom
            ? <span>{draft.source.reorderOfModelNo ? <>This is the reorder of <strong>{draft.source.reorderOfModelNo}</strong>. </> : ''}All POs for <strong>{draft.source.modelNo}</strong> are prepared from its items, one per supplier, with suppliers and rates from earlier orders. Review and edit them; nothing is generated until you click <strong>Review and confirm</strong> and then <strong>Generate</strong>.</span>
            : <span>Nothing is generated until you click <strong>Review and confirm</strong> and then <strong>Generate</strong>. The original {original} will not change.</span>}
        </p>
      )}

      <fieldset className="plain" disabled={!editable}>
        <section className="panel reorder-head" aria-label="New order details">
          <div>
            <label className="lbl" htmlFor="rd-date">PO date for the new POs <span className="req">*</span></label>
            <div className="row gap">
              <input id="rd-date" className={`f ${draft.poDate ? '' : 'unset-input'}`} type="date" min={today()} value={draft.poDate}
                onChange={(e) => change((d) => ({ ...d, poDate: e.target.value }), 'PO date set')} />
              <button type="button" className="btn sm" onClick={() => change((d) => ({ ...d, poDate: today() }), 'PO date set to today')}>Today</button>
            </div>
          </div>
          <div>
            <label className="lbl" htmlFor="rd-prj">Project ID</label>
            <input id="rd-prj" className="f" placeholder="Optional" value={draft.projectId} onChange={(e) => change((d) => ({ ...d, projectId: e.target.value }))} />
          </div>
          <div>
            <label className="lbl" htmlFor="rd-cust">Customer reference</label>
            <input id="rd-cust" className="f" placeholder="Optional" value={draft.customerRef} onChange={(e) => change((d) => ({ ...d, customerRef: e.target.value }))} />
          </div>
          <div className="stat-mini">
            <span>{plural(totals.pos, 'PO', 'POs')}, {plural(totals.rows, 'row', 'rows')}</span>
            <strong>{formatINR(totals.value)}</strong>
          </div>
        </section>
      </fieldset>

      {editable && (check.blocks.length > 0 || check.warnings.length > 0) && (
        <section className={`check-strip ${check.blocks.length ? 'bad' : 'warn'}`} aria-label="Checks">
          <button type="button" className="linkish" aria-expanded={showIssues} onClick={() => setShowIssues((x) => !x)}>
            {check.blocks.length ? `${plural(check.blocks.length, 'item needs', 'items need')} fixing before you can confirm` : 'Ready to confirm'}
            {check.warnings.length ? ` · ${plural(check.warnings.length, 'thing', 'things')} to review` : ''}
            {showIssues ? ' (hide)' : ' (show)'}
          </button>
          {showIssues && (
            <ul>
              {check.blocks.map((b, i) => <li key={`b${i}`} className="blk"><span className="grow">{b.message}</span>{(b.rowUid || b.cardUid) && <button type="button" className="btn sm" onClick={() => goTo(b.rowUid, b.cardUid)}>Go to</button>}</li>)}
              {check.warnings.map((w, i) => <li key={`w${i}`} className="wrn"><span className="grow">{w.message}</span><button type="button" className="btn sm" onClick={() => goTo(w.rowUid, w.cardUid)}>Go to</button></li>)}
            </ul>
          )}
        </section>
      )}
      {editable && check.ok && check.warnings.length === 0 && <p className="ok-note">Everything checks out. Review the POs below, then confirm.</p>}

      {draft.pos.map((card, ci) => {
        const vendor = card.vendorId ? vendorById.get(card.vendorId) : null;
        const st = resolveState(vendor || {});
        const t = computePo(preparedPoAsPo(card, vendor, draft));
        const cc = check.cards[card.uid] || { blocks: [], warnings: [] };
        const list = (materials[card.vendorId] || []).filter((m) => m.status !== 'inactive');
        const others = draft.pos.filter((c) => c.uid !== card.uid);
        return (
          <article key={card.uid} id={`card-${card.uid}`} className={`panel rcard ${card.excluded ? 'excluded' : ''} ${cc.blocks.length ? 'has-block' : ''}`}>
            <header className="rcard-head">
              <span className="badge sm item" aria-hidden="true">{ci + 1}</span>
              <div className="grow min0">
                <div className="row gap center wrap">
                  <label className="sr-only" htmlFor={`sup-${card.uid}`}>Supplier</label>
                  <select id={`sup-${card.uid}`} className={`f sup-select ${card.vendorId ? '' : 'unset'}`} value={card.vendorId || ''} disabled={!editable}
                    onChange={(e) => changeSupplier(card, e.target.value)}>
                    <option value="">{card.unassigned ? 'Choose a supplier for these rows…' : card.vendorName ? `${card.vendorName} (not in Vendor master): choose…` : 'Choose supplier…'}</option>
                    {vendors.filter((v) => v.status !== 'inactive' || v._id === card.vendorId).map((v) => <option key={v._id} value={v._id}>{v.name}{v.status === 'inactive' ? ' (inactive)' : ''}</option>)}
                  </select>
                  <span className="draft-tag">DRAFT, not a PO</span>
                  {card.excluded && <span className="kind-pill unset">Excluded from this run</span>}
                </div>
                <p className="muted small">
                  {card.unassigned ? 'Rows without a supplier: choose one above, or use Move… on each row' : card.sourcePoNo ? `From PO ${card.sourcePoNo}` : isBom ? `From the BOM of ${draft.source.modelNo}` : 'Added in this draft'}
                  {vendor ? ` · ${st.stateCode ? `${st.state}: ${t.intra ? 'CGST + SGST' : 'IGST'}` : 'state missing'}` : ''}
                </p>
              </div>
              <div className="r">
                <div className="muted small">{plural(card.lines.length, 'row', 'rows')}</div>
                <div className="strong num">{formatINR(t.grandTotal)}</div>
              </div>
              <div className="row gap">
                <button type="button" className="btn sm" onClick={() => setPreview({ title: `Preview: ${card.vendorName || 'PO'}`, html: buildPoHtml(preparedPoAsPo(card, vendor, draft), { withBar: false, draft: true }) })}>Preview</button>
                {editable && (
                  <button type="button" className="btn sm" onClick={() => setCard(card.uid, { excluded: !card.excluded }, card.excluded ? 'PO included again' : 'PO excluded from this run')}>
                    {card.excluded ? 'Include' : 'Exclude'}
                  </button>
                )}
              </div>
            </header>
            {cc.blocks.length > 0 && <ul className="card-issues">{cc.blocks.map((b, i) => <li key={i}>{b.message}</li>)}</ul>}

            {!card.excluded && (
              <fieldset className="plain" disabled={!editable}>
                <div className="scroll-x">
                  <table className="rtable">
                    <colgroup>
                      <col style={{ width: 34 }} /><col /><col style={{ width: 84 }} /><col style={{ width: 96 }} /><col style={{ width: 84 }} />
                      <col style={{ width: 132 }} /><col style={{ width: 70 }} /><col style={{ width: 84 }} /><col style={{ width: 112 }} /><col style={{ width: 168 }} />
                    </colgroup>
                    <thead><tr><th>#</th><th>Description</th><th>HSN</th><th className="r">Qty</th><th>Unit</th><th className="r">Rate (₹)</th><th className="r">Disc %</th><th>GST</th><th className="r">Amount</th><th /></tr></thead>
                    <tbody>
                      {card.lines.map((row, i) => {
                        const rc = check.rows[row.uid] || { blocks: [], warnings: [], infos: [] };
                        const m = row.vendorMaterialId ? (materials[card.vendorId] || []).find((x) => x._id === row.vendorMaterialId) : null;
                        const current = m ? latestEntry(m.history) : null;
                        const amount = t.lines.at(i)?.amount ?? 0;
                        const sr = (field, clean = (x) => x, label = field) => (e) => {
                          const v = clean(e.target.value);
                          setRow(card.uid, row.uid, { [field]: v, ...(field === 'rate' ? { rateFrom: 'typed' } : {}) }, `${row.description || 'Row'}: ${label} → ${v}`);
                        };
                        return (
                          <tr key={row.uid} id={`row-${row.uid}`} className={rc.blocks.length ? 'blk' : rc.warnings.length ? 'wrn' : ''}>
                            <td className="muted">{i + 1}</td>
                            <td>
                              <input className="f sm" aria-label={`Row ${i + 1} description`} value={row.description} onChange={sr('description', (x) => x, 'description')} />
                              {card.vendorId && (
                                <select className={`f sm rate-link ${row.vendorMaterialId ? 'linked' : 'unset'}`} aria-label={`Row ${i + 1}: supplier's material`} value={row.vendorMaterialId || ''} onChange={(e) => linkMaterial(card, row, e.target.value)}>
                                  <option value="">{list.length ? 'Link to supplier’s material list…' : 'Supplier has no material list'}</option>
                                  {list.map((x) => <option key={x._id} value={x._id}>{x.material}{latestEntry(x.history) ? `: ₹${latestEntry(x.history).rate}` : ''}</option>)}
                                </select>
                              )}
                              {[...rc.blocks.map((x) => ({ k: 'b', t: x.message.split(': ').slice(1).join(': ') || x.message })), ...rc.warnings.map((x) => ({ k: 'w', t: x.message.split(': ').slice(1).join(': ') || x.message }))].map((n, j) => (
                                <div key={j} className={`row-note ${n.k === 'b' ? 'blk' : 'wrn'}`}>{n.t}</div>
                              ))}
                              {rc.infos.map((n, j) => <div key={`i${j}`} className="row-note info">{n}</div>)}
                            </td>
                            <td><input className="f sm" aria-label={`Row ${i + 1} HSN`} value={row.hsn} onChange={sr('hsn')} /></td>
                            <td><input className={`f sm num ${blank(row.qty) ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Qty" aria-label={`Row ${i + 1} quantity`} value={str(row.qty)} onChange={sr('qty', cleanDecimal, 'qty')} /></td>
                            <td><input className="f sm" aria-label={`Row ${i + 1} unit`} value={row.uom} onChange={sr('uom', (x) => x.toUpperCase(), 'unit')} /></td>
                            <td>
                              <input className={`f sm num ${blank(row.rate) ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Rate" aria-label={`Row ${i + 1} rate`} value={str(row.rate)} onChange={sr('rate', cleanDecimal, 'rate')} />
                              {current && toNumber(current.rate) !== toNumber(row.rate) && editable && (
                                <button type="button" className="linkish small" onClick={() => setRow(card.uid, row.uid, { rate: current.rate, rateFrom: 'current' }, `${row.description}: rate → current ₹${current.rate}`)}>Use current ₹{current.rate}</button>
                              )}
                              {row.rateFrom === 'current' && <div className="muted small rate-from">supplier’s current rate</div>}
                              {row.rateFrom === 'bom' && <div className="muted small rate-from">BOM rate</div>}
                            </td>
                            <td><input className="f sm num" inputMode="decimal" aria-label={`Row ${i + 1} discount`} value={str(row.discPct)} onChange={sr('discPct', cleanDecimal, 'discount')} /></td>
                            <td>
                              <select className={`f sm ${blank(row.gstPct) ? 'unset' : ''}`} aria-label={`Row ${i + 1} GST`} value={str(row.gstPct)} onChange={sr('gstPct', (x) => x, 'GST')}>
                                <option value="">GST…</option>
                                {[...new Set([...GST_RATES.map(String), ...(blank(row.gstPct) ? [] : [str(row.gstPct)])])].map((g) => <option key={g} value={g}>{g}%</option>)}
                              </select>
                            </td>
                            <td className="r num strong">{formatINR(amount)}</td>
                            <td className="row-actions">
                              {editable && (
                                <>
                                  {row.from && <button type="button" className="ib sm" aria-label={`Revert row ${i + 1} to ${row.from.label || `PO ${row.from.poNo}`}`} title={`Revert to ${row.from.label || `PO ${row.from.poNo}`}`} onClick={() => revertRow(card, row)}><Icon name="history" size={15} /></button>}
                                  <select className="f sm move" aria-label={`Move row ${i + 1} to another supplier`} value="" onChange={(e) => moveRow(card, row, e.target.value)}>
                                    <option value="">Move…</option>
                                    {others.map((o) => <option key={o.uid} value={`card:${o.uid}`}>{o.vendorName || 'Unassigned'}{o.sourcePoNo ? ` (PO ${o.sourcePoNo})` : ''}</option>)}
                                    {activeVendors.filter((v) => !draft.pos.some((c) => c.vendorId === v._id)).map((v) => <option key={v._id} value={`vendor:${v._id}`}>New PO: {v.name}</option>)}
                                  </select>
                                  <button type="button" className="ib sm danger" aria-label={`Remove row ${i + 1}`} onClick={() => removeRow(card, row)}><Icon name="close" size={15} /></button>
                                </>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                {editable && (
                  <div className="row gap wrap rcard-foot">
                    <button type="button" className="btn sm" onClick={() => addRow(card)}><Icon name="plus" size={14} strokeWidth={2.2} /> Add row</button>
                    {card.vendorId && list.length > 0 && (
                      <select className="f sm add-from" aria-label="Add a row from the supplier's material list" value="" onChange={(e) => e.target.value && addRow(card, e.target.value)}>
                        <option value="">Add from supplier’s list…</option>
                        {list.map((x) => <option key={x._id} value={x._id}>{x.material}{latestEntry(x.history) ? `: ₹${latestEntry(x.history).rate}` : ''}</option>)}
                      </select>
                    )}
                    <span className="grow" />
                    <button type="button" className="linkish small" aria-expanded={!!openMore[card.uid]} onClick={() => setOpenMore((o) => ({ ...o, [card.uid]: !o[card.uid] }))}>
                      {openMore[card.uid] ? 'Hide PO details' : 'PO details: Kind Attn., payment terms, reference, remark'}
                    </button>
                  </div>
                )}
                {openMore[card.uid] && (
                  <div className="g3 more-fields">
                    <div><label className="lbl" htmlFor={`ka-${card.uid}`}>Kind Attn.</label><input id={`ka-${card.uid}`} className="f" value={card.kindAttn} onChange={(e) => setCard(card.uid, { kindAttn: e.target.value })} /></div>
                    <div><label className="lbl" htmlFor={`pt-${card.uid}`}>Payment terms (days)</label><input id={`pt-${card.uid}`} className="f" value={card.paymentTerms} onChange={(e) => setCard(card.uid, { paymentTerms: e.target.value })} /></div>
                    <div><label className="lbl" htmlFor={`rn-${card.uid}`}>Ref. No</label><input id={`rn-${card.uid}`} className="f" value={card.refNo} onChange={(e) => setCard(card.uid, { refNo: e.target.value })} /></div>
                    <div className="span3"><label className="lbl" htmlFor={`rm-${card.uid}`}>Remark</label><input id={`rm-${card.uid}`} className="f" value={card.remark} onChange={(e) => setCard(card.uid, { remark: e.target.value })} /></div>
                  </div>
                )}
              </fieldset>
            )}
          </article>
        );
      })}

      {editable && (
        <div className="row gap wrap">
          <label className="sr-only" htmlFor="add-supplier">Add a PO for another supplier</label>
          <select id="add-supplier" className="f add-supplier" value="" onChange={(e) => { const v = vendorById.get(e.target.value); if (v) change((d) => ({ ...d, pos: [...d.pos, newCard(v)] }), `PO added for ${v.name}`); }}>
            <option value="">+ Add a PO for another supplier…</option>
            {activeVendors.filter((v) => !draft.pos.some((c) => c.vendorId === v._id)).map((v) => <option key={v._id} value={v._id}>{v.name}</option>)}
          </select>
          <span className="grow" />
          <button type="button" className="btn primary" onClick={openConfirm}><Icon name="purchase" size={16} /> Review and confirm</button>
        </div>
      )}

      {confirming && (
        <ConfirmGenerateDialog
          draft={draft}
          vendors={vendors}
          warnings={check.warnings}
          onClose={() => setConfirming(false)}
          onGenerated={(res) => {
            setConfirming(false);
            setDraft(res.draft);
            setMessage({ kind: 'ok', text: res.alreadyGenerated
              ? `These POs were already generated: ${res.draft.generated.poNos.map((n) => `PO ${n}`).join(', ')}.`
              : `Generated ${res.draft.generated.poNos.map((n) => `PO ${n}`).join(', ')} (Order ${res.draft.generated.orderNo}). The original did not change.` });
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onStopped={(err) => {
            setConfirming(false);
            setShowIssues(true);
            setMessage({ kind: 'err', text: `${err.message}${err.issues?.length ? ` ${err.issues.map((i) => i.message).join(' ')}` : ''}` });
            vendorsApi.list().then((v) => setVendors(v.items || []));
            setMaterials({});
          }}
        />
      )}
      {preview && (
        <DocumentPreview title={preview.title} subtitle={preview.fileHtml ? '' : 'Preview of a prepared PO. It is not generated yet.'}
          html={preview.html} fileHtml={preview.fileHtml || preview.html} filename={preview.filename || 'prepared-po.html'} onClose={() => setPreview(null)} />
      )}
    </div>
  );
}
