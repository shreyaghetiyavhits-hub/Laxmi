import { useEffect, useRef, useState } from 'react';
import { reordersApi } from '../../api/productMasters.js';
import { preparedPoAsPo } from '@shared/reorder.js';
import { computePo } from '@shared/po.js';
import { formatINR, plural } from '../../lib/format.js';
import { poDate } from '../../lib/poDocument.js';
import { Icon } from '../../components/Icon.jsx';

/**
 * The only screen that can turn a reorder draft into purchase orders.
 * The Generate button needs the review tick, locks on the first click, and the
 * server accepts each draft's generation key only once.
 */
export function ConfirmGenerateDialog({ draft, vendors, warnings, extra = '', onClose, onGenerated, onStopped }) {
  const ref = useRef(null);
  const busy = useRef(false);
  const [reviewed, setReviewed] = useState(false);
  const [working, setWorking] = useState(false);
  const vendorById = new Map(vendors.map((v) => [v._id, v]));
  const cards = draft.pos.filter((c) => !c.excluded);
  const rows = cards.map((c) => ({ c, t: computePo(preparedPoAsPo(c, vendorById.get(c.vendorId), draft)) }));
  const total = rows.reduce((a, r) => a + r.t.grandTotal, 0);
  const n = cards.length;

  useEffect(() => {
    const d = ref.current;
    if (d && typeof d.showModal === 'function' && !d.open) d.showModal();
  }, []);

  async function generate() {
    if (busy.current) return; // second click while working does nothing
    busy.current = true;
    setWorking(true);
    try {
      const res = await reordersApi.generate(draft._id, { generationKey: draft.generationKey });
      onGenerated(res);
    } catch (err) {
      busy.current = false;
      setWorking(false);
      onStopped(err);
    }
  }

  return (
    <dialog ref={ref} className="form-dialog" aria-labelledby="gen-title" onCancel={(e) => { e.preventDefault(); if (!working) onClose(); }}>
      <header className="form-dialog-head">
        <h2 id="gen-title" className="grow">Generate {plural(n, 'purchase order', 'purchase orders')}?</h2>
        <button type="button" className="ib" aria-label="Close" onClick={onClose} disabled={working}><Icon name="close" /></button>
      </header>
      <div className="form-dialog-body">
        <p>These POs will be numbered and saved with PO date <strong>{poDate(draft.poDate)}</strong>. The original {draft.source.kind === 'bom' ? `Product master ${draft.source.modelNo}` : draft.source.orderNo ? `order ${draft.source.orderNo} and its POs` : `PO ${draft.source.poNos.join(', ')}`} will not change.</p>
        <div className="scroll-x">
          <table className="table">
            <thead><tr><th>#</th><th>Supplier</th><th className="r">Rows</th><th className="r">Grand total</th></tr></thead>
            <tbody>
              {rows.map(({ c, t }, i) => (
                <tr key={c.uid}><td>{i + 1}</td><td className="strong-ish">{c.vendorName}</td><td className="r num">{c.lines.length}</td><td className="r num strong">{formatINR(t.grandTotal)}</td></tr>
              ))}
            </tbody>
            <tfoot><tr><td colSpan={3} className="r strong">Total</td><td className="r num strong">{formatINR(total)}</td></tr></tfoot>
          </table>
        </div>
        {extra && <p><strong>{extra}</strong></p>}
        {draft.pos.length > n && <p className="muted small">{plural(draft.pos.length - n, 'excluded PO stays', 'excluded POs stay')} in the draft and is not generated.</p>}
        {warnings.length > 0 && (
          <div className="warn-box">
            <strong>Please note ({warnings.length}):</strong>
            <ul>{warnings.map((w, i) => <li key={i}>{w.message}</li>)}</ul>
          </div>
        )}
        <label className="check big"><input type="checkbox" checked={reviewed} onChange={(e) => setReviewed(e.target.checked)} disabled={working} /> I have reviewed these purchase orders</label>
      </div>
      <footer className="form-dialog-foot">
        <button type="button" className="btn" onClick={onClose} disabled={working}>Back to review</button>
        <button type="button" className="btn primary" onClick={generate} disabled={!reviewed || working}>
          {working ? 'Generating…' : `Generate ${plural(n, 'PO', 'POs')}`}
        </button>
      </footer>
    </dialog>
  );
}
