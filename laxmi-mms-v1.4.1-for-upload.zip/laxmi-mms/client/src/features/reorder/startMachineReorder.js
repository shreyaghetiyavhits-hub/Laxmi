import { productMastersApi } from '../../api/productMasters.js';

/**
 * Reorder a machine: asks once, then makes a full, editable copy as a new Product master and opens it.
 * Nothing else is created; purchase orders are prepared later from the copy.
 */
export async function startMachineReorder({ id, modelNo, confirm, navigate, onError }) {
  const ok = await confirm({
    title: `Reorder ${modelNo}?`,
    message: `A full copy of ${modelNo} is made as a new Product master, with all its items and materials, ready to edit for this order. The original ${modelNo} does not change. Purchase orders are prepared from the copy when you are ready.`,
    confirmLabel: 'Make reorder copy'
  });
  if (!ok) return;
  try {
    const copy = await productMastersApi.reorder(id);
    navigate(`/product-master/${copy._id}`, { state: { flash: { kind: 'ok', text: `Reorder copy ${copy.modelNo} created from ${modelNo}. Edit anything you need, then click Prepare purchase orders.` } } });
  } catch (e) {
    onError?.(e.message);
  }
}
