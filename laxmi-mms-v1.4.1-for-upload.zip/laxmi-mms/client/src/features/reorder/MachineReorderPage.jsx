import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { reordersApi, vendorsApi, vendorMaterialsApi, purchaseOrdersApi } from '../../api/productMasters.js';
import {
  checkReorderDraft, preparedPoAsPo, draftTotals, derivePosFromMachine, supplierContext, purchaseForVendor, vendorOffers, bomPurchaseRows
} from '@shared/reorder.js';
import { computePo } from '@shared/po.js';
import { resolveState } from '@shared/gstStates.js';
import { GST_RATES, STANDARD_GST_PCT } from '@shared/company.js';
import { SOURCES, LINE_UOMS, NODE_UOMS } from '@shared/constants.js';
import { buildPoHtml, poFileName } from '../../lib/poDocument.js';
import { cleanDecimal, formatINR, plural } from '../../lib/format.js';
import { uid } from '../../lib/bom.js';
import { DocumentPreview } from '../../components/DocumentPreview.jsx';
import { useConfirm } from '../../components/ConfirmProvider.jsx';
import { Icon } from '../../components/Icon.jsx';
import { ConfirmGenerateDialog } from './ConfirmGenerateDialog.jsx';

const blank = (v) => v === null || v === undefined || String(v).trim() === '';
const str = (v) => (v === null || v === undefined ? '' : String(v));
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const newPurchase = (order = true) => ({ order, vendorId: null, vendorName: '', supplierFrom: '', vendorMaterialId: null, rate: '', rateFrom: '', gstPct: STANDARD_GST_PCT, discPct: null, hsn: '', from: null });

/**
 * Reorder machine: an editable COPY of the machine (items, sub-items, materials, quantities) with a vendor
 * per material, and the purchase orders worked out from it, one per vendor. Nothing is generated until
 * Review and confirm → Generate. The original Product master never changes.
 */
export function MachineReorderPage({ initialDraft }) {
  const confirm = useConfirm();
  const [draft, setDraft] = useState(initialDraft);
  const [vendors, setVendors] = useState([]);
  const [materials, setMaterials] = useState(null); // all vendors' material lists
  const [tab, setTab] = useState('machine');
  const [saveState, setSaveState] = useState('saved');
  const [message, setMessage] = useState(null);
  const [showIssues, setShowIssues] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [preview, setPreview] = useState(null);
  const [q, setQ] = useState('');
  const [show, setShow] = useState('all'); // all | order | novendor
  const [openMore, setOpenMore] = useState({});
  const saveTimer = useRef(null);
  const pending = useRef(null);
  const versionRef = useRef(initialDraft.version);
  const draftRef = useRef(initialDraft);
  draftRef.current = draft;

  const loadMasters = useCallback(async () => {
    const v = (await vendorsApi.list()).items || [];
    setVendors(v);
    const lists = await Promise.all(v.map((x) => vendorMaterialsApi.list(x._id).then((r) => r.items || []).catch(() => [])));
    setMaterials(lists.flat());
  }, []);
  useEffect(() => { loadMasters(); }, [loadMasters]);

  const ctx = useMemo(() => supplierContext({ vendors, materials: materials || [] }), [vendors, materials]);
  const vendorById = useMemo(() => new Map(vendors.map((v) => [String(v._id), v])), [vendors]);
  const activeVendors = vendors.filter((v) => v.status !== 'inactive');
  const editable = draft.status === 'draft';
  const nodes = draft.machine.nodes;
  const rowsByKey = useMemo(() => new Map(bomPurchaseRows(nodes).rows.map((r) => [r.key, r])), [nodes]);
  const check = useMemo(() => (materials ? checkReorderDraft(draft, { vendors, materials, today: today() }) : null), [draft, vendors, materials]);
  const totals = useMemo(() => draftTotals(draft, vendors), [draft, vendors]);

  // ---------- autosave ----------
  const flush = useCallback(async () => {
    const job = pending.current;
    if (!job) return;
    pending.current = null;
    setSaveState('saving');
    try {
      const d = job.draft;
      const saved = await reordersApi.update(d._id, {
        version: versionRef.current, poDate: d.poDate, projectId: d.projectId, customerRef: d.customerRef, pos: d.pos,
        machine: d.machine, purchase: d.purchase, poMeta: d.poMeta, saveAsNew: d.saveAsNew, change: job.change
      });
      versionRef.current = saved.version;
      setSaveState(pending.current ? 'saving' : 'saved');
      if (pending.current) flush();
    } catch (e) {
      setSaveState('error');
      setMessage({ kind: 'err', text: e.message });
    }
  }, []);
  useEffect(() => () => clearTimeout(saveTimer.current), []);

  /** Every edit: apply, work the POs out again from the machine copy, save half a second later. */
  const change = (fn, description) => {
    const next0 = fn(draftRef.current);
    const next = { ...next0, pos: derivePosFromMachine(next0, vendors) };
    draftRef.current = next;
    setDraft(next);
    pending.current = { draft: next, change: description || pending.current?.change };
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(flush, 500);
    setSaveState('saving');
  };

  // ---------- machine copy edits ----------
  const mapNode = (d, nodeUid, fn) => ({ ...d, machine: { ...d.machine, nodes: d.machine.nodes.map((n) => (n.uid === nodeUid ? fn(n) : n)) } });
  const setNode = (nodeUid, patch, what) => change((d) => mapNode(d, nodeUid, (n) => ({ ...n, ...patch })), what);
  const mapLines = (n, subUid, fn) => (subUid ? { ...n, subAssemblies: n.subAssemblies.map((s) => (s.uid === subUid ? { ...s, lines: fn(s.lines) } : s)) } : { ...n, lines: fn(n.lines) });
  const setLine = (nodeUid, subUid, lineUid, patch, what) => change((d) => mapNode(d, nodeUid, (n) => mapLines(n, subUid, (ls) => ls.map((l) => (l.uid === lineUid ? { ...l, ...patch } : l)))), what);
  const setSub = (nodeUid, subUid, patch, what) => change((d) => mapNode(d, nodeUid, (n) => ({ ...n, subAssemblies: n.subAssemblies.map((s) => (s.uid === subUid ? { ...s, ...patch } : s)) })), what);
  const setPurchase = (key, patch, what) => change((d) => ({ ...d, purchase: { ...d.purchase, [key]: { ...(d.purchase[key] || newPurchase()), ...patch } } }), what);

  function addLine(nodeUid, subUid) {
    const l = { uid: uid(), material: '', spec: '', cutSize: '', source: '', process: '', vendor: '', qty: '', uom: '', rate: null };
    change((d) => ({ ...mapNode(d, nodeUid, (n) => mapLines(n, subUid, (ls) => [...ls, l])), purchase: { ...d.purchase, [`l:${l.uid}`]: newPurchase() } }), 'Material added');
  }
  async function removeLine(nodeUid, subUid, line) {
    const ok = await confirm({ title: `Remove ${line.material || 'this material'} from this order?`, message: 'Only this reorder’s copy of the machine changes. The Product master stays as it is.', confirmLabel: 'Remove', danger: true });
    if (ok) change((d) => mapNode(d, nodeUid, (n) => mapLines(n, subUid, (ls) => ls.filter((x) => x.uid !== line.uid))), `Material removed: ${line.material}`);
  }
  function addItem(mode) {
    const n = { uid: uid(), kind: 'item', mode, code: '', name: '', qty: '', uom: '', spec: '', vendor: '', rate: null, lines: [], subAssemblies: [] };
    change((d) => ({ ...d, machine: { ...d.machine, nodes: [...d.machine.nodes, n] }, purchase: mode === 'bought_out' ? { ...d.purchase, [`i:${n.uid}`]: newPurchase() } : d.purchase }), 'Item added');
  }
  async function removeItem(n, i) {
    const ok = await confirm({ title: `Remove item ${i + 1}${n.name ? ` (${n.name})` : ''} from this order?`, message: 'Its materials are removed from this reorder too. The Product master stays as it is.', confirmLabel: 'Remove', danger: true });
    if (ok) change((d) => ({ ...d, machine: { ...d.machine, nodes: d.machine.nodes.filter((x) => x.uid !== n.uid) } }), `Item removed: ${n.name}`);
  }
  function addSub(nodeUid) {
    change((d) => mapNode(d, nodeUid, (n) => ({ ...n, subAssemblies: [...(n.subAssemblies || []), { uid: uid(), code: '', name: '', qty: '', uom: '', lines: [] }] })), 'Sub-item added');
  }

  /** Choose a vendor for one row: links to that vendor's material, with its rate and GST. */
  function chooseVendor(key, vendorId) {
    const row = rowsByKey.get(key) || { material: '' };
    const v = vendorById.get(vendorId) || null;
    change((d) => {
      const prev = d.purchase[key] || newPurchase();
      const purchase = { ...d.purchase, [key]: purchaseForVendor(row, prev, v, ctx) };
      const poMeta = v && !d.poMeta?.[v._id]
        ? { ...d.poMeta, [v._id]: { kindAttn: v.contactPerson || '', paymentTerms: v.paymentTerms || '', refNo: '', refDate: '', remark: '', terms: '', excluded: false } }
        : d.poMeta;
      return { ...d, purchase, poMeta };
    }, `${row.material || 'Row'}: vendor → ${v?.name || 'none'}`);
  }
  /** Give every ticked row that has no vendor the same vendor. */
  function assignAll(vendorId) {
    const v = vendorById.get(vendorId);
    if (!v) return;
    change((d) => {
      const purchase = { ...d.purchase };
      for (const [key, p] of Object.entries(purchase)) if (p.order && !p.vendorId && rowsByKey.get(key)) purchase[key] = purchaseForVendor(rowsByKey.get(key), p, v, ctx);
      const poMeta = d.poMeta?.[v._id] ? d.poMeta : { ...d.poMeta, [v._id]: { kindAttn: v.contactPerson || '', paymentTerms: v.paymentTerms || '', refNo: '', refDate: '', remark: '', terms: '', excluded: false } };
      return { ...d, purchase, poMeta };
    }, `All rows without a vendor → ${v.name}`);
  }
  const setMeta = (vid, patch, what) => change((d) => ({ ...d, poMeta: { ...d.poMeta, [vid]: { ...(d.poMeta?.[vid] || {}), ...patch } } }), what);

  // ---------- top-level actions ----------
  async function discard() {
    const ok = await confirm({ title: `Discard draft ${draft.draftNo}?`, message: 'No purchase order or Product master will be created or changed.', confirmLabel: 'Discard draft', danger: true });
    if (!ok) return;
    try {
      clearTimeout(saveTimer.current);
      pending.current = null;
      setDraft(await reordersApi.discard(draft._id));
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    }
  }
  async function openConfirm() {
    clearTimeout(saveTimer.current);
    await flush();
    if (!check?.ok) {
      setShowIssues(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setConfirming(true);
  }
  const goTo = (rowUid, cardUid) => {
    if (rowUid) setTab('machine');
    else setTab('pos');
    setTimeout(() => {
      const el = document.getElementById(rowUid ? `mrow-${rowUid}` : `card-${cardUid}`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el?.querySelector('input, select')?.focus();
    }, 60);
  };
  async function openSavedPo(poId) {
    const po = await purchaseOrdersApi.get(poId);
    setPreview({ title: `Purchase order ${po.poNo}`, html: buildPoHtml(po, { withBar: false }), fileHtml: buildPoHtml(po, { withBar: true }), filename: poFileName(po) });
  }

  // ---------- row filters ----------
  const needle = q.trim().toLowerCase();
  const rowVisible = (key, text) => {
    const p = draft.purchase[key];
    if (show === 'order' && !p?.order) return false;
    if (show === 'novendor' && !(p?.order && !p?.vendorId)) return false;
    return !needle || String(text || '').toLowerCase().includes(needle);
  };
  const counts = useMemo(() => {
    const ps = [...rowsByKey.keys()].map((k) => draft.purchase[k]).filter(Boolean);
    return { rows: rowsByKey.size, order: ps.filter((p) => p.order).length, noVendor: ps.filter((p) => p.order && !p.vendorId).length };
  }, [rowsByKey, draft.purchase]);

  /** Vendor drop-down: vendors that list this material first, with their price. */
  const vendorSelect = ({ rowKey, material, label }) => {
    const p = draft.purchase[rowKey] || newPurchase();
    const offers = materials ? vendorOffers(material, ctx) : [];
    const listed = new Set(offers.map((o) => String(o.vendor._id)));
    const current = p.vendorId ? vendorById.get(String(p.vendorId)) : null;
    return (
      <select className={`f sm ${p.vendorId ? '' : 'unset'}`} aria-label={label} value={p.vendorId || ''} onChange={(e) => chooseVendor(rowKey, e.target.value)}>
        <option value="">{p.order ? 'Choose vendor…' : 'No vendor'}</option>
        {offers.length > 0 && (
          <optgroup label="Vendors with this material">
            {offers.map((o, i) => <option key={o.vendor._id} value={o.vendor._id}>{o.vendor.name}{o.rate !== null ? ` — ₹${o.rate}` : ''}{o.material.preferred === 'yes' ? ' ★' : i === 0 && offers.length > 1 ? ' (lowest)' : ''}</option>)}
          </optgroup>
        )}
        <optgroup label={offers.length ? 'Other vendors' : 'Vendors'}>
          {activeVendors.filter((v) => !listed.has(String(v._id))).map((v) => <option key={v._id} value={v._id}>{v.name}</option>)}
          {current && current.status === 'inactive' && <option value={current._id}>{current.name} (inactive)</option>}
        </optgroup>
      </select>
    );
  };

  /** One orderable row: tick, vendor, rate, GST, and its notes. */
  const purchaseCells = ({ rowKey, material, n }) => {
    const p = draft.purchase[rowKey] || newPurchase(false);
    const rc = check?.rows[rowKey];
    return (
      <>
        <td className="c"><input type="checkbox" aria-label={`Order ${material || `row ${n}`}`} checked={!!p.order} onChange={(e) => setPurchase(rowKey, { order: e.target.checked }, `${material}: ${e.target.checked ? 'order' : 'do not order'}`)} /></td>
        <td>
          {vendorSelect({ rowKey, material, label: `Vendor for ${material || `row ${n}`}` })}
          {p.order && !p.vendorId && <div className="row-note blk">Choose a vendor</div>}
          {p.order && p.supplierFrom && <div className="row-note info">{p.supplierFrom}</div>}
        </td>
        <td>
          <input className={`f sm num ${p.order && blank(p.rate) ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Rate" aria-label={`Rate for ${material || `row ${n}`}`} value={str(p.rate)}
            onChange={(e) => setPurchase(rowKey, { rate: cleanDecimal(e.target.value), rateFrom: 'typed' }, `${material}: rate`)} />
          {p.order && rc?.infos.filter((x) => x.startsWith('Was ₹')).map((x, j) => <div key={j} className="row-note info">{x}</div>)}
        </td>
        <td>
          <select className="f sm" aria-label={`GST for ${material || `row ${n}`}`} value={str(p.gstPct)} onChange={(e) => setPurchase(rowKey, { gstPct: e.target.value }, `${material}: GST`)}>
            <option value="">GST…</option>
            {[...new Set([...GST_RATES.map(String), ...(blank(p.gstPct) ? [] : [str(p.gstPct)])])].map((g) => <option key={g} value={g}>{g}%</option>)}
          </select>
        </td>
      </>
    );
  };

  const issuesFor = (key) => {
    const rc = check?.rows[key];
    if (!rc || !draft.purchase[key]?.order) return null;
    const list = [...rc.blocks.map((x) => ['blk', x.message]), ...rc.warnings.map((x) => ['wrn', x.message])];
    return list.length ? list.map(([k, t], j) => <div key={j} className={`row-note ${k}`}>{t.split(': ').slice(1).join(': ') || t}</div>) : null;
  };

  const linesTable = ({ node, sub, lines }) => (
    <div className="scroll-x">
      <table className="mtable">
        <colgroup>
          <col style={{ width: 52 }} /><col style={{ width: 230 }} /><col style={{ width: 104 }} /><col style={{ width: 84 }} /><col /><col style={{ width: 160 }} />
          <col style={{ width: 118 }} /><col style={{ width: 76 }} /><col style={{ width: 84 }} /><col style={{ width: 40 }} />
        </colgroup>
        <thead><tr><th className="c">Order</th><th>Vendor</th><th className="r">Rate (₹)</th><th>GST</th><th>Material</th><th>Details / cutting size</th><th>Source</th><th className="r">Qty</th><th>Unit</th><th /></tr></thead>
        <tbody>
          {lines.map((l, j) => {
            const key = `l:${l.uid}`;
            if (!rowVisible(key, `${l.material} ${l.spec} ${l.cutSize} ${draft.purchase[key]?.vendorName || ''}`)) return null;
            const p = draft.purchase[key];
            const rc = check?.rows[key];
            return (
              <tr key={l.uid} id={`mrow-${key}`} className={`${p?.order ? '' : 'not-ordered'} ${p?.order && rc?.blocks.length ? 'blk' : p?.order && rc?.warnings.length ? 'wrn' : ''}`}>
                {purchaseCells({ rowKey: key, material: l.material, n: j + 1 })}
                <td>
                  <input className="f sm" aria-label={`Material ${j + 1}`} placeholder="Material" value={l.material} onChange={(e) => setLine(node.uid, sub?.uid, l.uid, { material: e.target.value }, 'material')} />
                  {issuesFor(key)}
                </td>
                <td><input className="f sm" aria-label={`Details of ${l.material || `material ${j + 1}`}`} placeholder="Details, cutting size" value={[l.spec, l.cutSize].filter(Boolean).join(', ')}
                  onChange={(e) => setLine(node.uid, sub?.uid, l.uid, { spec: e.target.value, cutSize: '' }, 'details')} /></td>
                <td>
                  <select className={`f sm ${l.source ? '' : 'unset'}`} aria-label={`Source of ${l.material || `material ${j + 1}`}`} value={l.source || ''} onChange={(e) => setLine(node.uid, sub?.uid, l.uid, { source: e.target.value }, 'source')}>
                    <option value="">Select…</option>
                    {SOURCES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                </td>
                <td><input className={`f sm num ${blank(l.qty) ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Qty" aria-label={`Quantity of ${l.material || `material ${j + 1}`}`} value={str(l.qty)}
                  onChange={(e) => setLine(node.uid, sub?.uid, l.uid, { qty: cleanDecimal(e.target.value) }, `${l.material}: qty`)} /></td>
                <td>
                  <select className={`f sm ${l.uom ? '' : 'unset'}`} aria-label={`Unit of ${l.material || `material ${j + 1}`}`} value={l.uom || ''} onChange={(e) => setLine(node.uid, sub?.uid, l.uid, { uom: e.target.value }, 'unit')}>
                    <option value="">Unit…</option>
                    {LINE_UOMS.map((u) => <option key={u}>{u}</option>)}
                  </select>
                </td>
                <td>{editable && <button type="button" className="ib sm danger" aria-label={`Remove ${l.material || `material ${j + 1}`}`} onClick={() => removeLine(node.uid, sub?.uid, l)}><Icon name="close" size={15} /></button>}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  const machineSummary = `${plural(nodes.length, 'item', 'items')}, ${plural(counts.rows, 'material row', 'material rows')}; ${counts.order} to order${counts.noVendor ? `, ${counts.noVendor} without a vendor` : ''}`;

  return (
    <div className="page reorder-page">
      <div className="page-head">
        <Link to="/purchase-orders?tab=drafts" className="ib bordered" aria-label="Back to Purchase orders"><Icon name="back" /></Link>
        <div className="grow min0">
          <p className="muted small">Purchase orders / Reorder / {draft.draftNo}</p>
          <h1 className="row gap center wrap">
            Reorder machine {draft.source.modelNo}
            <span className={`rstatus ${draft.status}`}>{{ draft: 'Draft, not generated', generated: 'Generated', discarded: 'Discarded', generating: 'Generating' }[draft.status]}</span>
          </h1>
          {editable && <p className="muted small" aria-live="polite">{saveState === 'saving' ? 'Saving…' : saveState === 'error' ? 'Not saved' : 'All changes saved'}</p>}
        </div>
        {editable && (
          <div className="row gap wrap">
            <button type="button" className="btn danger-text" onClick={discard}>Discard draft</button>
            <button type="button" className="btn primary" onClick={openConfirm} disabled={!check}><Icon name="purchase" size={16} /> Review and confirm</button>
          </div>
        )}
      </div>

      {message && (
        <div role="status" className={`msg ${message.kind}`}>
          <span className="grow">{message.text}</span>
          <button type="button" className="ib sm" aria-label="Dismiss message" onClick={() => setMessage(null)}><Icon name="close" size={16} /></button>
        </div>
      )}

      {draft.status === 'generated' && (
        <section className="panel done-panel" aria-label="Generated">
          <h2>Generated {plural(draft.generated.poNos.length, 'purchase order', 'purchase orders')}</h2>
          <p className="muted">Order {draft.generated.orderNo} for machine {draft.machine.modelNo}{draft.customerRef ? ` (${draft.customerRef})` : ''}. The original Product master {draft.source.modelNo} did not change.</p>
          {draft.generated.productMasterId && <p>Saved as a new Product master: <Link to={`/product-master/${draft.generated.productMasterId}`}>{draft.generated.productMasterModelNo}</Link></p>}
          <div className="row gap wrap">
            {draft.generated.poIds.map((pid, i) => <button key={pid} type="button" className="btn" onClick={() => openSavedPo(pid)}><Icon name="printer" size={16} /> PO {draft.generated.poNos.at(i)}</button>)}
            <Link to="/purchase-orders" className="btn primary">Go to Purchase orders</Link>
          </div>
        </section>
      )}
      {draft.status === 'discarded' && <p className="locked-note"><Icon name="lock" /> This draft was discarded. Nothing was created or changed.</p>}
      {editable && (
        <p className="info-note"><Icon name="alert" size={16} />
          <span>This is a copy of machine <strong>{draft.source.modelNo}</strong> for a new order. Change materials, quantities and vendors as needed; the POs are worked out from it, one per vendor. Nothing is generated until you click <strong>Review and confirm</strong> and then <strong>Generate</strong>.</span>
        </p>
      )}

      <fieldset className="plain" disabled={!editable}>
        <section className="panel reorder-head" aria-label="New order">
          <div>
            <label className="lbl" htmlFor="mr-name">Machine name</label>
            <input id="mr-name" className="f" value={draft.machine.machineName} onChange={(e) => change((d) => ({ ...d, machine: { ...d.machine, machineName: e.target.value } }), 'Machine name')} />
            <p className="help">Copied from {draft.source.modelNo}, revision R{draft.source.revision ?? 0}</p>
          </div>
          <div>
            <label className="lbl" htmlFor="mr-cust">Customer reference</label>
            <input id="mr-cust" className="f" placeholder="e.g. customer name or order no" value={draft.customerRef} onChange={(e) => change((d) => ({ ...d, customerRef: e.target.value }))} />
          </div>
          <div>
            <label className="lbl" htmlFor="mr-prj">Project ID</label>
            <input id="mr-prj" className="f" placeholder="Optional" value={draft.projectId} onChange={(e) => change((d) => ({ ...d, projectId: e.target.value }))} />
          </div>
          <div>
            <label className="lbl" htmlFor="mr-date">PO date <span className="req">*</span></label>
            <div className="row gap">
              <input id="mr-date" className={`f ${draft.poDate ? '' : 'unset-input'}`} type="date" min={today()} value={draft.poDate} onChange={(e) => change((d) => ({ ...d, poDate: e.target.value }), 'PO date')} />
              <button type="button" className="btn sm" onClick={() => change((d) => ({ ...d, poDate: today() }), 'PO date: today')}>Today</button>
            </div>
          </div>
          <div className="span-all save-new">
            <label className="check">
              <input type="checkbox" checked={!!draft.saveAsNew?.enabled} onChange={(e) => change((d) => ({ ...d, saveAsNew: { ...(d.saveAsNew || {}), enabled: e.target.checked } }), 'Save as new Product master')} />
              Also save this machine as a new Product master (for a customer variant)
            </label>
            {draft.saveAsNew?.enabled && (
              <input className={`f sm ${draft.saveAsNew.modelNo ? '' : 'unset-input'}`} aria-label="Model no for the new Product master" placeholder={`New model no, e.g. ${draft.source.modelNo}-A`}
                value={draft.saveAsNew.modelNo || ''} onChange={(e) => change((d) => ({ ...d, saveAsNew: { ...d.saveAsNew, modelNo: e.target.value } }))} />
            )}
          </div>
        </section>
      </fieldset>

      {editable && check && (check.blocks.length > 0 || check.warnings.length > 0) && (
        <section className={`check-strip ${check.blocks.length ? 'bad' : 'warn'}`} aria-label="Checks">
          <button type="button" className="linkish" aria-expanded={showIssues} onClick={() => setShowIssues((x) => !x)}>
            {check.blocks.length ? `${plural(check.blocks.length, 'item needs', 'items need')} fixing before you can confirm` : 'Ready to confirm'}
            {check.warnings.length ? ` · ${plural(check.warnings.length, 'thing', 'things')} to review` : ''}{showIssues ? ' (hide)' : ' (show)'}
          </button>
          {showIssues && (
            <ul>
              {check.blocks.map((b, i) => <li key={`b${i}`} className="blk"><span className="grow">{b.message}</span>{(b.rowUid || b.cardUid) && <button type="button" className="btn sm" onClick={() => goTo(b.rowUid, b.cardUid)}>Go to</button>}</li>)}
              {check.warnings.map((w, i) => <li key={`w${i}`} className="wrn"><span className="grow">{w.message}</span><button type="button" className="btn sm" onClick={() => goTo(w.rowUid, w.cardUid)}>Go to</button></li>)}
            </ul>
          )}
        </section>
      )}
      {editable && check?.ok && check.warnings.length === 0 && <p className="ok-note">Everything checks out. Review the purchase orders, then confirm.</p>}
      {!materials && <p className="muted">Loading vendors and their material lists…</p>}

      <div role="tablist" aria-label="Reorder sections" className="tabs">
        <button type="button" role="tab" aria-selected={tab === 'machine'} className={tab === 'machine' ? 'on' : ''} onClick={() => setTab('machine')}>1. Machine &amp; materials</button>
        <button type="button" role="tab" aria-selected={tab === 'pos'} className={tab === 'pos' ? 'on' : ''} onClick={() => setTab('pos')}>2. Purchase orders ({totals.pos}) · {formatINR(totals.value)}</button>
      </div>

      {tab === 'machine' && (
        <fieldset className="plain" disabled={!editable}>
          <section className="panel tab-panel" aria-label="Machine and materials">
            <div className="toolbar">
              <div className="search">
                <label htmlFor="mr-q" className="sr-only">Search materials</label>
                <Icon name="search" size={16} />
                <input id="mr-q" className="f" placeholder="Search material or vendor" value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
              <div role="group" aria-label="Show" className="seg">
                {[['all', `All (${counts.rows})`], ['order', `To order (${counts.order})`], ['novendor', `Without vendor (${counts.noVendor})`]].map(([k, t]) => (
                  <button key={k} type="button" aria-pressed={show === k} className={show === k ? 'on' : ''} onClick={() => setShow(k)}>{t}</button>
                ))}
              </div>
              {counts.noVendor > 0 && editable && (
                <select className="f sm assign-all" aria-label="Give all rows without a vendor the same vendor" value="" onChange={(e) => e.target.value && assignAll(e.target.value)}>
                  <option value="">Set vendor for all {counts.noVendor} rows without one…</option>
                  {activeVendors.map((v) => <option key={v._id} value={v._id}>{v.name}</option>)}
                </select>
              )}
            </div>
            <p className="muted small">{machineSummary}. Tick <strong>Order</strong> for the rows to buy; untick rows made from stock or not needed.</p>

            {nodes.map((n, i) => {
              const boc = n.mode === 'bought_out';
              const key = `i:${n.uid}`;
              const lineCount = (n.lines || []).length + (n.subAssemblies || []).reduce((a, s) => a + s.lines.length, 0);
              const anyVisible = boc ? rowVisible(key, `${n.name} ${n.spec} ${draft.purchase[key]?.vendorName || ''}`)
                : [...(n.lines || []), ...(n.subAssemblies || []).flatMap((s) => s.lines)].some((l) => rowVisible(`l:${l.uid}`, `${l.material} ${l.spec} ${l.cutSize} ${draft.purchase[`l:${l.uid}`]?.vendorName || ''}`));
              if ((needle || show !== 'all') && !anyVisible) return null;
              return (
                <article key={n.uid} className="mitem">
                  <header className="mitem-head">
                    <span className={`tag ${boc ? 'boc' : n.mode ? 'item' : 'unset'}`}>{i + 1}</span>
                    <input className="f sm mitem-name" aria-label={`Item ${i + 1} name`} placeholder="Item name" value={n.name} onChange={(e) => setNode(n.uid, { name: e.target.value }, 'item name')} />
                    <select className={`f sm ${n.mode ? '' : 'unset'}`} aria-label={`Item ${i + 1} type`} value={n.mode || ''} onChange={(e) => {
                      const mode = e.target.value;
                      change((d) => ({ ...mapNode(d, n.uid, (x) => ({ ...x, mode })), purchase: mode === 'bought_out' && !d.purchase[key] ? { ...d.purchase, [key]: newPurchase() } : d.purchase }), 'item type');
                    }}>
                      <option value="">Type…</option><option value="fabricated">Made in-house</option><option value="bought_out">Bought-out</option>
                    </select>
                    <input className={`f sm num qty-in ${blank(n.qty) ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Qty" aria-label={`Item ${i + 1} quantity`} value={str(n.qty)} onChange={(e) => setNode(n.uid, { qty: cleanDecimal(e.target.value) }, `${n.name}: qty`)} />
                    <select className={`f sm unit-in ${n.uom ? '' : 'unset'}`} aria-label={`Item ${i + 1} unit`} value={n.uom || ''} onChange={(e) => setNode(n.uid, { uom: e.target.value }, 'unit')}>
                      <option value="">Unit…</option>{NODE_UOMS.map((u) => <option key={u}>{u}</option>)}
                    </select>
                    <span className="muted small grow">{boc ? 'Bought-out' : n.mode ? plural(lineCount, 'material', 'materials') : 'Type not chosen: not ordered'}</span>
                    {editable && <button type="button" className="ib sm danger" aria-label={`Remove item ${i + 1}`} onClick={() => removeItem(n, i)}><Icon name="trash" size={15} /></button>}
                  </header>

                  {boc && rowVisible(key, `${n.name} ${n.spec}`) && (
                    <div className="scroll-x">
                      <table className="mtable">
                        <colgroup><col style={{ width: 52 }} /><col style={{ width: 230 }} /><col style={{ width: 104 }} /><col style={{ width: 84 }} /><col /></colgroup>
                        <thead><tr><th className="c">Order</th><th>Vendor</th><th className="r">Rate (₹)</th><th>GST</th><th>Specification</th></tr></thead>
                        <tbody>
                          <tr id={`mrow-${key}`} className={`${draft.purchase[key]?.order ? '' : 'not-ordered'} ${draft.purchase[key]?.order && check?.rows[key]?.blocks.length ? 'blk' : ''}`}>
                            {purchaseCells({ rowKey: key, material: n.name, n: 1 })}
                            <td><input className="f sm" aria-label={`Item ${i + 1} specification`} placeholder="Make, model, size" value={n.spec || ''} onChange={(e) => setNode(n.uid, { spec: e.target.value }, 'specification')} />{issuesFor(key)}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  )}

                  {n.mode === 'fabricated' && (
                    <>
                      {(n.lines || []).length > 0 && linesTable({ node: n, lines: n.lines })}
                      {(n.subAssemblies || []).map((s) => (
                        <div key={s.uid} className="msub">
                          <div className="msub-head">
                            <span className="muted small">Sub-item</span>
                            <input className="f sm" aria-label="Sub-item name" placeholder="Sub-item name" value={s.name} onChange={(e) => setSub(n.uid, s.uid, { name: e.target.value }, 'sub-item name')} />
                            <input className={`f sm num qty-in ${blank(s.qty) ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Qty" aria-label={`${s.name || 'Sub-item'} quantity`} value={str(s.qty)} onChange={(e) => setSub(n.uid, s.uid, { qty: cleanDecimal(e.target.value) }, 'sub-item qty')} />
                            <select className={`f sm unit-in ${s.uom ? '' : 'unset'}`} aria-label={`${s.name || 'Sub-item'} unit`} value={s.uom || ''} onChange={(e) => setSub(n.uid, s.uid, { uom: e.target.value }, 'sub-item unit')}>
                              <option value="">Unit…</option>{NODE_UOMS.map((u) => <option key={u}>{u}</option>)}
                            </select>
                            <span className="grow" />
                            {editable && <button type="button" className="btn sm" onClick={() => addLine(n.uid, s.uid)}><Icon name="plus" size={14} /> Material</button>}
                          </div>
                          {s.lines.length > 0 && linesTable({ node: n, sub: s, lines: s.lines })}
                        </div>
                      ))}
                      {editable && !needle && show === 'all' && (
                        <div className="row gap wrap mitem-foot">
                          <button type="button" className="btn sm" onClick={() => addLine(n.uid)}><Icon name="plus" size={14} strokeWidth={2.2} /> Add material</button>
                          <button type="button" className="btn sm" onClick={() => addSub(n.uid)}><Icon name="plus" size={14} /> Add sub-item</button>
                        </div>
                      )}
                    </>
                  )}
                </article>
              );
            })}
            {editable && !needle && show === 'all' && (
              <div className="row gap wrap">
                <button type="button" className="btn" onClick={() => addItem('fabricated')}><Icon name="plus" size={16} /> Add made in-house item</button>
                <button type="button" className="btn" onClick={() => addItem('bought_out')}><Icon name="plus" size={16} /> Add bought-out item</button>
              </div>
            )}
          </section>
        </fieldset>
      )}

      {tab === 'pos' && (
        <section className="tab-panel col-gap" aria-label="Purchase orders">
          {draft.pos.length === 0 && <p className="empty-box">No rows are ticked to order yet. Tick rows in <button type="button" className="linkish" onClick={() => setTab('machine')}>Machine &amp; materials</button>.</p>}
          {draft.pos.map((card, ci) => {
            const vendor = card.vendorId ? vendorById.get(String(card.vendorId)) : null;
            const st = resolveState(vendor || {});
            const t = computePo(preparedPoAsPo(card, vendor, draft));
            const cc = check?.cards[card.uid] || { blocks: [] };
            return (
              <article key={card.uid} id={`card-${card.uid}`} className={`panel rcard ${card.excluded ? 'excluded' : ''} ${cc.blocks.length ? 'has-block' : ''}`}>
                <header className="rcard-head">
                  <span className="badge sm item" aria-hidden="true">{ci + 1}</span>
                  <div className="grow min0">
                    <div className="row gap center wrap">
                      <strong className="ellipsis">{card.vendorName}</strong>
                      <span className="draft-tag">DRAFT, not a PO</span>
                      {card.excluded && <span className="kind-pill unset">Excluded from this run</span>}
                    </div>
                    <p className="muted small">{card.unassigned ? 'Choose vendors for these rows in Machine & materials' : st.stateCode ? `${st.state}: ${t.intra ? 'CGST + SGST' : 'IGST'}` : 'State missing in Vendor master'}</p>
                  </div>
                  <div className="r"><div className="muted small">{plural(card.lines.length, 'row', 'rows')}</div><div className="strong num">{formatINR(t.grandTotal)}</div></div>
                  <div className="row gap">
                    <button type="button" className="btn sm" onClick={() => setPreview({ title: `Preview: ${card.vendorName}`, html: buildPoHtml(preparedPoAsPo(card, vendor, draft), { withBar: false, draft: true }) })}>Preview</button>
                    {editable && card.vendorId && <button type="button" className="btn sm" onClick={() => setMeta(card.vendorId, { excluded: !card.excluded }, card.excluded ? 'PO included' : 'PO excluded')}>{card.excluded ? 'Include' : 'Exclude'}</button>}
                  </div>
                </header>
                {cc.blocks.length > 0 && <ul className="card-issues">{cc.blocks.map((b, i) => <li key={i}>{b.message}</li>)}</ul>}
                {!card.excluded && (
                  <>
                    <div className="scroll-x">
                      <table className="table">
                        <thead><tr><th>#</th><th>Description</th><th>From</th><th className="r">Qty</th><th>Unit</th><th className="r">Rate</th><th className="r">GST</th><th className="r">Amount</th><th /></tr></thead>
                        <tbody>
                          {card.lines.map((l, i) => (
                            <tr key={l.uid} className={check?.rows[l.uid]?.blocks.length ? 'blk-row' : ''}>
                              <td className="muted">{i + 1}</td>
                              <td className="strong-ish">{l.description || <em className="muted">No description</em>}</td>
                              <td className="muted small">{l.bomSource?.label}</td>
                              <td className="r num">{blank(l.qty) ? <span className="pending-text">—</span> : l.qty}</td>
                              <td>{l.uom || '—'}</td>
                              <td className="r num">{blank(l.rate) ? <span className="pending-text">Missing</span> : formatINR(toNum(l.rate))}</td>
                              <td className="r num">{blank(l.gstPct) ? '—' : `${l.gstPct}%`}</td>
                              <td className="r num strong">{formatINR(t.lines.at(i)?.amount ?? 0)}</td>
                              <td><button type="button" className="btn sm" onClick={() => goTo(l.uid)}>Edit</button></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {editable && card.vendorId && (
                      <div className="rcard-foot row gap wrap">
                        <span className="grow" />
                        <button type="button" className="linkish small" aria-expanded={!!openMore[card.uid]} onClick={() => setOpenMore((o) => ({ ...o, [card.uid]: !o[card.uid] }))}>
                          {openMore[card.uid] ? 'Hide PO details' : 'PO details: Kind Attn., payment terms, reference, remark'}
                        </button>
                      </div>
                    )}
                    {openMore[card.uid] && card.vendorId && (
                      <fieldset className="plain" disabled={!editable}>
                        <div className="g3 more-fields">
                          <div><label className="lbl" htmlFor={`ka-${card.uid}`}>Kind Attn.</label><input id={`ka-${card.uid}`} className="f" value={card.kindAttn} onChange={(e) => setMeta(card.vendorId, { kindAttn: e.target.value })} /></div>
                          <div><label className="lbl" htmlFor={`pt-${card.uid}`}>Payment terms (days)</label><input id={`pt-${card.uid}`} className="f" value={card.paymentTerms} onChange={(e) => setMeta(card.vendorId, { paymentTerms: e.target.value })} /></div>
                          <div><label className="lbl" htmlFor={`rn-${card.uid}`}>Ref. No</label><input id={`rn-${card.uid}`} className="f" value={card.refNo} onChange={(e) => setMeta(card.vendorId, { refNo: e.target.value })} /></div>
                          <div className="span3"><label className="lbl" htmlFor={`rm-${card.uid}`}>Remark</label><input id={`rm-${card.uid}`} className="f" value={card.remark} onChange={(e) => setMeta(card.vendorId, { remark: e.target.value })} /></div>
                        </div>
                      </fieldset>
                    )}
                  </>
                )}
              </article>
            );
          })}
        </section>
      )}

      {editable && (
        <div className="row gap wrap">
          <span className="grow" />
          {tab === 'machine' && <button type="button" className="btn" onClick={() => { setTab('pos'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>See the purchase orders</button>}
          <button type="button" className="btn primary" onClick={openConfirm} disabled={!check}><Icon name="purchase" size={16} /> Review and confirm</button>
        </div>
      )}

      {confirming && (
        <ConfirmGenerateDialog
          draft={draft}
          vendors={vendors}
          warnings={check.warnings}
          extra={draft.saveAsNew?.enabled ? `The machine is also saved as a new Product master: ${draft.saveAsNew.modelNo || '(model no missing)'}.` : ''}
          onClose={() => setConfirming(false)}
          onGenerated={(res) => {
            setConfirming(false);
            setDraft(res.draft);
            setMessage({ kind: 'ok', text: `Generated ${res.draft.generated.poNos.map((n) => `PO ${n}`).join(', ')} (Order ${res.draft.generated.orderNo}).${res.draft.generated.productMasterModelNo ? ` New Product master ${res.draft.generated.productMasterModelNo} saved.` : ''}` });
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onStopped={(err) => {
            setConfirming(false);
            setShowIssues(true);
            setMessage({ kind: 'err', text: `${err.message}${err.issues?.length ? ` ${err.issues.map((i) => i.message).join(' ')}` : ''}` });
            loadMasters();
          }}
        />
      )}
      {preview && (
        <DocumentPreview title={preview.title} subtitle={preview.fileHtml ? '' : 'Preview of a prepared PO. It is not generated yet.'}
          html={preview.html} fileHtml={preview.fileHtml || preview.html} filename={preview.filename || 'prepared-po.html'} onClose={() => setPreview(null)} />
      )}
    </div>
  );
}

const toNum = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
