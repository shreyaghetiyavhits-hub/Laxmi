import { useEditorStore } from '../../store/editorStore.js';
import { NODE_UOMS } from '@shared/constants.js';
import { nodeUnitCost, subAssemblyUnitCost, nodePendingRates, isBoughtOut, toNumber, isPendingRate } from '@shared/cost.js';
import { formatINR, cleanDecimal, plural } from '../../lib/format.js';
import { Icon } from '../../components/Icon.jsx';
import { LineItems } from './LineItems.jsx';
import { qtyText } from '../../lib/labels.js';
import { useConfirm } from '../../components/ConfirmProvider.jsx';

export function NodeEditor({ tags, locked }) {
  const nodes = useEditorStore((s) => s.nodes);
  const selected = useEditorStore((s) => s.selected);
  const modelNo = useEditorStore((s) => s.modelNo);
  const actions = useEditorStore();
  const confirm = useConfirm();

  const node = nodes.find((n) => n.uid === selected.nodeUid);
  if (!node) {
    return (
      <section className="panel empty-editor">
        <h2>Start the bill of materials</h2>
        <p className="muted">Add the first item. It opens here for editing.</p>
        {!locked && (
          <div className="row gap">
            <button type="button" className="btn" onClick={() => actions.addNode({ mode: 'fabricated' })}>Add made in-house item</button>
            <button type="button" className="btn" onClick={() => actions.addNode({ mode: 'bought_out', lines: [] })}>Add bought-out item</button>
          </div>
        )}
      </section>
    );
  }

  const sub = selected.subUid ? node.subAssemblies.find((s) => s.uid === selected.subUid) : null;
  const boc = !sub && isBoughtOut(node);
  const typeUnset = !sub && !node.mode;
  const entity = sub || node;
  const num = tags[node.uid];
  const label = sub ? `Item ${num}, sub-item` : `Item ${num}`;

  const unit = sub ? subAssemblyUnitCost(sub) : nodeUnitCost(node);
  const pending = sub ? sub.lines.filter((l) => isPendingRate(l.rate)).length : nodePendingRates(node);

  const set = (field) => (e) => {
    const value = field === 'qty' || field === 'rate' ? cleanDecimal(e.target.value) : e.target.value;
    if (sub) actions.updateSub(node.uid, sub.uid, { [field]: value });
    else actions.updateNode(node.uid, { [field]: value });
  };

  const remove = async () => {
    const name = entity.name ? ` (${entity.name})` : '';
    const extra = sub
      ? 'Its materials will be removed too.'
      : boc
        ? 'Its vendor and rate will be removed too.'
        : 'Its materials and sub-items will be removed too.';
    const ok = await confirm({
      title: `Remove ${label}${name}?`,
      message: `${extra} The change is kept only when you save.`,
      confirmLabel: 'Remove',
      danger: true
    });
    if (!ok) return;
    if (sub) actions.removeSub(node.uid, sub.uid);
    else actions.removeNode(node.uid);
  };

  const crumb = `${modelNo || 'New model'} / Items${sub ? ` / ${num}. ${node.name || 'Untitled'}` : ''}`;

  return (
    <section className="panel editor-card" aria-label={`Edit ${label}`}>
      <header className="editor-head">
        <span className={`badge ${boc ? 'boc' : typeUnset ? 'unset' : 'item'} ${sub ? 'sub' : ''}`} aria-hidden="true">{sub ? `${num}.` : num}</span>
        <div className="grow min0">
          <p className="muted small">{crumb}</p>
          <h2 className="ellipsis">{entity.name || (sub ? 'Untitled sub-item' : 'Untitled item')}</h2>
        </div>
        <div className="r">
          <div className="muted small">{sub ? 'Sub-item cost' : 'Item cost'}</div>
          <div className="cost-xl num">{formatINR(unit * toNumber(entity.qty))}</div>
        </div>
        {!locked && (
          <div className="row">
            {!sub && (
              <button type="button" className="ib" aria-label={`Duplicate item ${num}`} title="Duplicate" onClick={() => actions.duplicateNode(node.uid)}>
                <Icon name="copy" />
              </button>
            )}
            <button type="button" className="ib danger" aria-label={`Remove ${label}`} title="Remove" onClick={remove}>
              <Icon name="trash" />
            </button>
          </div>
        )}
      </header>

      <div className="editor-body">
        <fieldset className="plain" disabled={locked}>
          {!sub && (
            <div className="row gap wrap center">
              <div role="group" aria-label="How do we get this item?" className={`seg ${typeUnset ? 'seg-unset' : ''}`}>
                <button type="button" aria-pressed={node.mode === 'fabricated'} className={node.mode === 'fabricated' ? 'on' : ''} onClick={() => actions.updateNode(node.uid, { mode: 'fabricated' })}>Made in-house</button>
                <button type="button" aria-pressed={boc} className={boc ? 'on' : ''} onClick={() => actions.updateNode(node.uid, { mode: 'bought_out' })}>Bought-out</button>
              </div>
              <span className={typeUnset ? 'pending-text small' : 'muted small'}>
                {typeUnset
                  ? 'Not chosen yet. Pick how we get this item.'
                  : boc ? 'Bought ready-made. Enter the spec, vendor and rate once.' : 'Made from the materials listed below. Add sub-items if it has separate parts.'}
              </span>
            </div>
          )}

          <div className="grid-fields">
            <div>
              <label className="lbl" htmlFor="ed-code">Item code</label>
              <input id="ed-code" className="f" placeholder="Select or type code" value={entity.code} onChange={set('code')} />
            </div>
            <div>
              <label className="lbl" htmlFor="ed-name">Name <span className="req">*</span></label>
              <input id="ed-name" className="f" list="dl-parts" placeholder="Select or type name" value={entity.name} onChange={set('name')} />
            </div>
            <div>
              <label className="lbl" htmlFor="ed-qty">Qty</label>
              <input id="ed-qty" className="f num" inputMode="decimal" placeholder="Qty" value={entity.qty} onChange={set('qty')} />
            </div>
            <div>
              <label className="lbl" htmlFor="ed-uom">Unit</label>
              <select id="ed-uom" className={`f ${entity.uom ? '' : 'unset'}`} value={entity.uom} onChange={set('uom')}>
                <option value="">Select…</option>
                {NODE_UOMS.map((u) => <option key={u}>{u}</option>)}
              </select>
            </div>
          </div>

          {boc && (
            <div className="grid-boc">
              <div>
                <label className="lbl" htmlFor="ed-spec">Specification</label>
                <input id="ed-spec" className="f" placeholder="Make, model, size or rating" value={node.spec} onChange={set('spec')} />
              </div>
              <div>
                <label className="lbl" htmlFor="ed-vendor">Vendor</label>
                <input id="ed-vendor" className="f" list="dl-vendors" placeholder="Optional" value={node.vendor} onChange={set('vendor')} />
              </div>
              <div>
                <label className="lbl" htmlFor="ed-rate">Rate per unit (₹)</label>
                <input id="ed-rate" className={`f num ${isPendingRate(node.rate) ? 'pending' : ''}`} inputMode="decimal" placeholder="0.00"
                  value={node.rate} onChange={set('rate')} />
              </div>
            </div>
          )}

          {!boc && !typeUnset && <LineItems nodeUid={node.uid} subUid={sub ? sub.uid : null} lines={entity.lines} tag={label} />}
        </fieldset>

        {!sub && !boc && !typeUnset && (
          <section aria-label="Sub-items">
            <div className="section-head">
              <h3>Sub-items <span className="muted">{node.subAssemblies.length}</span></h3>
              {!locked && (
                <button type="button" className="btn sm item-text" onClick={() => actions.addSub(node.uid)}>
                  <Icon name="plus" size={14} strokeWidth={2.2} /> Add sub-item
                </button>
              )}
            </div>
            {node.subAssemblies.length === 0 ? (
              <p className="muted small">Optional. Use a sub-item for a part built separately with its own materials, such as the machine body inside the frame.</p>
            ) : (
              <div className="sub-cards">
                {node.subAssemblies.map((s) => (
                  <div key={s.uid} className="sub-card">
                    <span className="strong">{s.name || 'Untitled sub-item'}</span>
                    <span className="muted small">{plural(s.lines.length, 'material', 'materials')}, qty {qtyText(s.qty, s.uom)}</span>
                    <span className="small num">{formatINR(subAssemblyUnitCost(s) * toNumber(s.qty))}</span>
                    <button type="button" className="btn sm" onClick={() => actions.select(node.uid, s.uid)}>Open</button>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {sub && (
          <button type="button" className="btn sm self-start" onClick={() => actions.select(node.uid)}>
            <Icon name="back" size={14} /> Back to item {num} {node.name || ''}
          </button>
        )}

        <footer className="editor-foot">
          <span className="num">{entity.qty === '' ? 'Enter the quantity to see the total cost.' : `${formatINR(unit)} per ${(entity.uom || 'unit').toLowerCase()} × ${entity.qty}`}</span>
          {pending > 0 && <span className="pending-text">{plural(pending, 'rate', 'rates')} pending</span>}
        </footer>
      </div>
    </section>
  );
}
