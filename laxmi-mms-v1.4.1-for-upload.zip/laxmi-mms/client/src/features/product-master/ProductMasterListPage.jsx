import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { productMastersApi, SMART_REORDER } from '../../api/productMasters.js';
import { startMachineReorder } from '../reorder/startMachineReorder.js';
import { useConfirm } from '../../components/ConfirmProvider.jsx';
import { formatINR, formatDate } from '../../lib/format.js';
import { Icon } from '../../components/Icon.jsx';

export function ProductMasterListPage() {
  const confirm = useConfirm();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [state, setState] = useState({ loading: true, error: '', items: [] });
  const [listError, setListError] = useState('');

  useEffect(() => {
    let alive = true;
    const t = setTimeout(() => {
      setState((s) => ({ ...s, loading: true, error: '' }));
      productMastersApi
        .list({ q, status })
        .then((data) => alive && setState({ loading: false, error: '', items: data.items }))
        .catch((err) => alive && setState({ loading: false, error: err.message, items: [] }));
    }, 250);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [q, status]);

  return (
    <div className="page">
      <div className="page-head">
        <div className="grow">
          <p className="muted small">Dashboard / Product master</p>
          <h1>Product master</h1>
        </div>
        <Link to="/product-master/new" className="btn primary"><Icon name="plus" size={16} strokeWidth={2.2} /> New product master</Link>
      </div>

      <div className="toolbar">
        <div className="search">
          <label htmlFor="pm-q" className="sr-only">Search by model, machine or project</label>
          <Icon name="search" size={16} />
          <input id="pm-q" className="f" placeholder="Search model, machine or project" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <label htmlFor="pm-status" className="sr-only">Status</label>
        <select id="pm-status" className="f status-filter" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="final">Final</option>
        </select>
      </div>

      <div className="panel table-wrap">
        {(state.error || listError) && <p className="error-box" role="alert">{state.error || listError}</p>}
        {!state.error && !state.loading && state.items.length === 0 && (
          <div className="empty-list">
            <h2>No product masters yet</h2>
            <p className="muted">Create the first one, or run <code>npm run seed</code> to load the LBSL 80 sample.</p>
          </div>
        )}
        {state.items.length > 0 && (
          <div className="scroll-x">
            <table className="table">
              <thead>
                <tr>
                  <th>Model no</th><th>Machine</th><th>Revision</th><th>Status</th>
                  <th className="r">Items</th><th className="r">Bought-out</th><th className="r">Rates pending</th>
                  <th className="r">Est. cost</th><th>Updated</th>{SMART_REORDER && <th className="r">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {state.items.map((it) => (
                  <tr key={it._id}>
                    <td>
                      <Link to={`/product-master/${it._id}`} className="strong">{it.modelNo}</Link>
                      {it.reorderOf?.modelNo && <div className="muted small reorder-of">Reorder of {it.reorderOf.modelNo}</div>}
                    </td>
                    <td>{it.machineName || <span className="muted">Not set</span>}</td>
                    <td>R{it.revision}</td>
                    <td><span className={`status ${it.status}`}>{it.status === 'final' ? 'Final' : 'Draft'}</span></td>
                    <td className="r num">{it.totals?.items ?? 0}</td>
                    <td className="r num">{it.totals?.boughtOut ?? 0}</td>
                    <td className="r num">{it.totals?.pendingRates ?? 0}</td>
                    <td className="r num strong">{formatINR(it.totals?.cost)}</td>
                    <td className="muted">{formatDate(it.updatedAt)}</td>
                    {SMART_REORDER && (
                      <td className="r">
                        <button type="button" className="btn sm reorder-btn" onClick={() => startMachineReorder({ id: it._id, modelNo: it.modelNo, confirm, navigate, onError: setListError })}>
                          <Icon name="history" size={14} /> Reorder
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {state.loading && state.items.length === 0 && !state.error && <p className="muted pad">Loading…</p>}
      </div>
      <p className="muted small">Tip: click a model no to open it. For a new order of the same machine, click <strong>Reorder</strong>: a full copy is made for you to edit, and its POs are prepared for review. <button type="button" className="linkish" onClick={() => navigate('/product-master/new')}>Create a new one</button></p>
    </div>
  );
}
