import { useEditorStore } from '../../store/editorStore.js';
import { Icon } from '../../components/Icon.jsx';

export function IssuesPanel({ issues, onClose }) {
  const select = useEditorStore((s) => s.select);
  if (!issues.length) return null;
  return (
    <section className="issues" role="alert" aria-label="Items to fix">
      <div className="issues-head">
        <Icon name="alert" />
        <strong className="grow">Fix {issues.length === 1 ? 'this item' : `these ${issues.length} items`} before saving as final, or save as a draft.</strong>
        <button type="button" className="ib sm" aria-label="Hide list" onClick={onClose}><Icon name="close" size={16} /></button>
      </div>
      <ul>
        {issues.map((issue, i) => (
          <li key={i}>
            <span className="grow">{issue.message}</span>
            {issue.nodeUid && (
              <button type="button" className="btn sm" onClick={() => select(issue.nodeUid, issue.subUid || null)}>Go to item</button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
