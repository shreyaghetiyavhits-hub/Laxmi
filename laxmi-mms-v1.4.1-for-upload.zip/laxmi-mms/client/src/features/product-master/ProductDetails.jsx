import { useEditorStore } from '../../store/editorStore.js';
import { formatINR } from '../../lib/format.js';

export function ProductDetails({ totals }) {
  const machineName = useEditorStore((s) => s.machineName);
  const modelNo = useEditorStore((s) => s.modelNo);
  const projectDigits = useEditorStore((s) => s.projectDigits);
  const setField = useEditorStore((s) => s.setField);
  const projectInvalid = projectDigits.length > 0 && projectDigits.length !== 4;

  return (
    <section className="panel details" aria-label="Product details">
      <div>
        <label className="lbl" htmlFor="pm-machine">Machine name</label>
        <input id="pm-machine" className="f" placeholder="e.g. Bottle sticker labelling machine"
          value={machineName} onChange={(e) => setField('machineName', e.target.value)} />
      </div>
      <div>
        <label className="lbl" htmlFor="pm-model">Model no <span className="req">*</span></label>
        <input id="pm-model" className="f" placeholder="e.g. LBSL 80" aria-required="true"
          value={modelNo} onChange={(e) => setField('modelNo', e.target.value)} />
      </div>
      <div>
        <label className="lbl" htmlFor="pm-project">Project ID (optional)</label>
        <div className="prefixed">
          <span className="prefix">PRJ-</span>
          <input id="pm-project" className="f" inputMode="numeric" maxLength={4} placeholder="0000"
            aria-invalid={projectInvalid} aria-describedby="pm-project-help"
            value={projectDigits} onChange={(e) => setField('projectDigits', e.target.value.replace(/\D/g, '').slice(0, 4))} />
        </div>
        <p id="pm-project-help" className={projectInvalid ? 'help err' : 'help'}>
          {projectInvalid ? 'Enter all 4 digits, or leave it blank.' : 'Leave blank if not tied to a project.'}
        </p>
      </div>
      <div className="details-total">
        <span className="lbl">Est. machine cost</span>
        <span className="big-cost">{formatINR(totals.cost)}</span>
        <span className="muted small">{totals.pendingRates ? `${totals.pendingRates} rates pending` : 'All rates filled in'}</span>
      </div>
    </section>
  );
}
