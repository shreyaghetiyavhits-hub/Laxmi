import { useEditorStore } from '../../store/editorStore.js';
import { Icon } from '../../components/Icon.jsx';
import { formatINR } from '../../lib/format.js';
import { nodeCost, isBoughtOut, isPendingRate, toNumber } from '@shared/cost.js';
import { qtyText } from '../../lib/labels.js';

/** Read-only list of materials shown under an expanded item. */
function TreeLines({ lines }) {
  if (!lines.length) return <p className="td-empty">No materials yet</p>;
  return (
    <ul className="td-lines">
      {lines.map((l) => (
        <li key={l.uid}>
          <span className="grow ellipsis" title={l.material}>{l.material || <em className="muted">Material not set</em>}</span>
          <span className="td-qty num">{qtyText(l.qty, l.uom)}</span>
        </li>
      ))}
    </ul>
  );
}

export function BomTree({ tags, locked, onOpenFull }) {
  const nodes = useEditorStore((s) => s.nodes);
  const selected = useEditorStore((s) => s.selected);
  const expanded = useEditorStore((s) => s.expanded);
  const select = useEditorStore((s) => s.select);
  const addNode = useEditorStore((s) => s.addNode);
  const toggleExpanded = useEditorStore((s) => s.toggleExpanded);
  const setAllExpanded = useEditorStore((s) => s.setAllExpanded);
  const modelNo = useEditorStore((s) => s.modelNo);
  const machineName = useEditorStore((s) => s.machineName);
  const anyOpen = nodes.some((n) => expanded[n.uid]);

  return (
    <aside className="panel tree" aria-label="Bill of materials">
      <div className="tree-root">
        <Icon name="gear" />
        <div className="grow">
          <div className="strong">{modelNo || 'New model'}</div>
          <div className="muted small ellipsis">{machineName || 'Machine name not set'}</div>
        </div>
        {onOpenFull && (
          <button type="button" className="ib bordered expand-btn" aria-label="Open full detailed view" title="Open full detailed view"
            onClick={onOpenFull}>
            <Icon name="expand" size={16} />
          </button>
        )}
      </div>

      {nodes.length > 0 && (
        <div className="tree-tools">
          <span className="muted small">Details</span>
          <button type="button" className="linkish small" onClick={() => setAllExpanded(true)}>Expand all</button>
          <button type="button" className="linkish small" onClick={() => setAllExpanded(false)} disabled={!anyOpen}>Collapse all</button>
        </div>
      )}

      <div className="tree-group">
        <div className="tree-group-head">
          <span className="tree-group-title">Items <span className="muted">{nodes.length}</span></span>

        </div>

        {nodes.length === 0 && <p className="muted small tree-empty">No items yet.</p>}

        <ul className="tree-list">
          {nodes.map((n) => {
            const tag = tags[n.uid];
            const current = selected.nodeUid === n.uid && !selected.subUid;
            const open = !!expanded[n.uid];
            const boc = isBoughtOut(n);
            const subCount = boc ? 0 : n.subAssemblies.length;
            return (
              <li key={n.uid}>
                <div className="tn-row">
                  <button type="button" className="chev" aria-expanded={open}
                    aria-label={`${open ? 'Hide' : 'Show'} details of item ${tag} ${n.name || ''}`.trim()}
                    onClick={() => toggleExpanded(n.uid)}>
                    <Icon name="chevron" size={14} strokeWidth={2.4} style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform .15s' }} />
                  </button>
                  <button type="button" className={`tn ${current ? 'on' : ''}`} aria-current={current ? 'true' : undefined} onClick={() => select(n.uid)}>
                    <span className={`tag ${boc ? 'boc' : n.mode ? 'item' : 'unset'}`}>{tag}</span>
                    <span className="grow ellipsis strong-ish" title={n.name}>{n.name || 'Untitled'}</span>
                    {boc && <span className="boc-mark" title="Bought-out">BOC</span>}
                    {!n.mode && <span className="unset-mark" title="Made in-house or bought-out not chosen yet">?</span>}
                    {!open && subCount > 0 && <span className="sub-count" title={`${subCount} sub-items`}>+{subCount}</span>}
                    <span className="muted small num">{formatINR(nodeCost(n))}</span>
                  </button>
                </div>

                {open && (
                  <div className="tree-detail">
                    {boc ? (
                      <dl className="td-boc">
                        <div><dt>Qty</dt><dd>{qtyText(n.qty, n.uom)}</dd></div>
                        <div><dt>Spec</dt><dd>{n.spec || '—'}</dd></div>
                        <div><dt>Vendor</dt><dd>{n.vendor || '—'}</dd></div>
                        <div><dt>Rate</dt><dd className="num">{isPendingRate(n.rate) ? 'Pending' : formatINR(toNumber(n.rate))}</dd></div>
                      </dl>
                    ) : n.mode ? (
                      <TreeLines lines={n.lines} />
                    ) : (
                      <p className="td-empty">Type not chosen yet</p>
                    )}

                    {!boc && n.subAssemblies.length > 0 && (
                      <ul className="tree-sub">
                        {n.subAssemblies.map((sub) => {
                          const on = selected.subUid === sub.uid;
                          return (
                            <li key={sub.uid}>
                              <button type="button" className={`tn sub ${on ? 'on' : ''}`} aria-current={on ? 'true' : undefined}
                                onClick={() => select(n.uid, sub.uid)}>
                                <span className="elbow" aria-hidden="true" />
                                <span className="grow ellipsis">{sub.name || 'Untitled sub-item'}</span>
                                <span className="muted small num">{qtyText(sub.qty, sub.uom)}</span>
                              </button>
                              <div className="td-sub-lines"><TreeLines lines={sub.lines} /></div>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      </div>

      {!locked && (
        <div className="tree-actions">
          <button type="button" className="btn sm item-text" onClick={() => addNode({ mode: 'fabricated' })}>Add made in-house</button>
          <button type="button" className="btn sm boc-text" onClick={() => addNode({ mode: 'bought_out', lines: [] })}>Add bought-out</button>
        </div>
      )}
    </aside>
  );
}
