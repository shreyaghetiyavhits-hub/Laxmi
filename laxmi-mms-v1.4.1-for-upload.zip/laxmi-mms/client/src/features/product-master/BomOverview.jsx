import { useEditorStore } from '../../store/editorStore.js';
import { Icon } from '../../components/Icon.jsx';
import { formatINR, plural } from '../../lib/format.js';
import { sourceLabel, kindLabel, qtyText } from '../../lib/labels.js';
import {
  nodeCost, nodeUnitCost, nodePendingRates, nodeLines, isBoughtOut, isPendingRate, lineTotal,
  subAssemblyUnitCost, toNumber
} from '@shared/cost.js';

/** Read-only table of material lines. */
function LinesTable({ lines, caption }) {
  if (!lines.length) return <p className="ov-empty">No materials yet.</p>;
  return (
    <div className="scroll-x">
      <table className="ov-table">
        <caption className="sr-only">{caption}</caption>
        <colgroup>
          <col style={{ width: 48 }} /><col style={{ width: '22%' }} /><col style={{ width: '14%' }} /><col style={{ width: '12%' }} />
          <col style={{ width: 104 }} /><col style={{ width: '13%' }} /><col style={{ width: '10%' }} /><col style={{ width: 64 }} />
          <col style={{ width: 60 }} /><col style={{ width: 104 }} /><col style={{ width: 110 }} />
        </colgroup>
        <thead>
          <tr>
            <th>#</th><th>Material</th><th>Code / details</th><th>Cutting size</th><th>Source</th>
            <th>Process</th><th>Vendor</th><th className="r">Qty</th><th>Unit</th><th className="r">Rate</th><th className="r">Total</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={l.uid}>
              <td className="muted">{i + 1}</td>
              <td className="strong-ish">{l.material || <em className="muted">Not set</em>}</td>
              <td>{l.spec || '—'}</td>
              <td>{l.cutSize || '—'}</td>
              <td><span className={`src ${l.source || 'none'}`}>{sourceLabel(l.source)}</span></td>
              <td>{l.process || '—'}</td>
              <td>{l.vendor || '—'}</td>
              <td className="r num">{l.qty === '' || l.qty === null ? '—' : l.qty}</td>
              <td>{l.uom || '—'}</td>
              <td className={`r num ${isPendingRate(l.rate) ? 'pending-text' : ''}`}>{isPendingRate(l.rate) ? 'Pending' : formatINR(toNumber(l.rate))}</td>
              <td className="r num strong">{isPendingRate(l.rate) ? '—' : formatINR(lineTotal(l))}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function OverviewItem({ node, tag, open, onToggle, onEdit, editLabel }) {
  const boc = isBoughtOut(node);
  const pending = nodePendingRates(node);
  const lineCount = nodeLines(node).length;
  const qty = qtyText(node.qty, node.uom);
  const meta = !node.mode
    ? `Type not chosen yet, qty ${qty}`
    : boc
      ? `Bought-out, qty ${qty}`
      : `${plural(lineCount, 'material', 'materials')}${node.subAssemblies.length ? `, ${plural(node.subAssemblies.length, 'sub-item', 'sub-items')}` : ''}, qty ${qty}`;

  return (
    <article className={`ov-item ${open ? 'open' : ''}`}>
      <div className="ov-item-head">
        <button type="button" className="chev" aria-expanded={open} aria-label={`${open ? 'Hide' : 'Show'} details of item ${tag}`} onClick={onToggle}>
          <Icon name="chevron" size={16} strokeWidth={2.4} style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform .15s' }} />
        </button>
        <span className={`badge sm ${boc ? 'boc' : node.mode ? 'item' : 'unset'}`}>{tag}</span>
        <div className="grow min0">
          <div className="row gap center wrap">
            <h4 className="ellipsis">{node.name || 'Untitled'}</h4>
            <span className={`kind-pill ${boc ? 'boc' : node.mode ? 'item' : 'unset'}`}>{kindLabel(node)}</span>
          </div>
          <p className="muted small">{meta}</p>
        </div>
        <div className="r">
          <div className="strong num">{formatINR(nodeCost(node))}</div>
          {pending > 0 && <div className="small pending-text">{plural(pending, 'rate', 'rates')} pending</div>}
        </div>
        <button type="button" className="btn sm" onClick={() => onEdit(node.uid, null)}>
          <Icon name="edit" size={14} /> {editLabel}
        </button>
      </div>

      {open && (
        <div className="ov-item-body">
          {boc ? (
            <dl className="ov-boc">
              <div><dt>Specification</dt><dd>{node.spec || '—'}</dd></div>
              <div><dt>Vendor</dt><dd>{node.vendor || '—'}</dd></div>
              <div><dt>Rate per unit</dt><dd className="num">{isPendingRate(node.rate) ? 'Pending' : formatINR(toNumber(node.rate))}</dd></div>
              <div><dt>Item code</dt><dd>{node.code || '—'}</dd></div>
            </dl>
          ) : node.mode ? (
            <LinesTable lines={node.lines} caption={`Materials of item ${tag}`} />
          ) : (
            <p className="ov-empty">Choose Made in-house or Bought-out for this item first.</p>
          )}

          {!boc && node.subAssemblies.map((sub) => {
            const unit = subAssemblyUnitCost(sub);
            return (
              <section key={sub.uid} className="ov-sub" aria-label={`Sub-item ${sub.name || ''}`}>
                <div className="ov-sub-head">
                  <span className="sub-tag">Sub-item</span>
                  <strong className="grow ellipsis">{sub.name || 'Untitled sub-item'}</strong>
                  <span className="muted small">{sub.code ? `Code ${sub.code}, ` : ''}qty {qtyText(sub.qty, sub.uom)}</span>
                  <span className="strong num">{formatINR(unit * toNumber(sub.qty))}</span>
                  <button type="button" className="btn sm" onClick={() => onEdit(node.uid, sub.uid)}>{editLabel}</button>
                </div>
                <LinesTable lines={sub.lines} caption={`Materials of ${sub.name || 'sub-item'}`} />
              </section>
            );
          })}

          <p className="muted small ov-foot num">
            {node.qty === '' ? 'Quantity not entered yet.' : <>{formatINR(nodeUnitCost(node))} per {(node.uom || 'unit').toLowerCase()} × {node.qty} = <strong>{formatINR(nodeCost(node))}</strong></>}
          </p>
        </div>
      )}
    </article>
  );
}

export function BomOverview({ tags, totals, locked, onEdit, onPrint }) {
  const nodes = useEditorStore((s) => s.nodes);
  const modelNo = useEditorStore((s) => s.modelNo);
  const expanded = useEditorStore((s) => s.expanded);
  const toggleExpanded = useEditorStore((s) => s.toggleExpanded);
  const setAllExpanded = useEditorStore((s) => s.setAllExpanded);
  const addNode = useEditorStore((s) => s.addNode);
  const editLabel = locked ? 'Open' : 'Edit';

  return (
    <section className="panel overview" aria-label="Full BOM view">
      <header className="overview-head">
        <div className="grow min0">
          <h2>Full BOM view</h2>
          <p className="muted small">Everything in {modelNo || 'this model'} on one page. Use {editLabel} to work on an item.</p>
        </div>
        <div className="row gap wrap">
          <button type="button" className="btn sm" onClick={() => setAllExpanded(true)}>Expand all</button>
          <button type="button" className="btn sm" onClick={() => setAllExpanded(false)}>Collapse all</button>
          <button type="button" className="btn sm primary" onClick={onPrint}>
            <Icon name="printer" size={14} /> Print BOM
          </button>
        </div>
      </header>

      <div className="ov-group">
        <div className="ov-group-head">
          <h3>Items <span className="muted">{nodes.length}</span></h3>
          {!locked && (
            <div className="row gap wrap">
              <button type="button" className="btn sm item-text" onClick={() => { addNode({ mode: 'fabricated' }); onEdit(null, null); }}>
                <Icon name="plus" size={14} strokeWidth={2.2} /> Add made in-house
              </button>
              <button type="button" className="btn sm boc-text" onClick={() => { addNode({ mode: 'bought_out', lines: [] }); onEdit(null, null); }}>
                <Icon name="plus" size={14} strokeWidth={2.2} /> Add bought-out
              </button>
            </div>
          )}
        </div>
        {nodes.length === 0 && <p className="ov-empty">No items yet.</p>}
        {nodes.map((n) => (
          <OverviewItem key={n.uid} node={n} tag={tags[n.uid]} open={!!expanded[n.uid]}
            onToggle={() => toggleExpanded(n.uid)} onEdit={onEdit} editLabel={editLabel} />
        ))}
      </div>

      <footer className="overview-foot">
        <span className="muted">
          {plural(totals.items, 'item', 'items')} ({totals.madeInHouse} made in-house, {totals.boughtOut} bought-out),{' '}
          {plural(totals.lineCount, 'material line', 'material lines')}, {plural(totals.pendingRates, 'rate', 'rates')} pending
        </span>
        <span>Est. machine cost <strong className="big-cost">{formatINR(totals.cost)}</strong></span>
      </footer>
    </section>
  );
}
