import { useMemo } from 'react';
import { useEditorStore } from '../../store/editorStore.js';
import { buildPrintHtml, printFileName } from '../../lib/printDocument.js';
import { DocumentPreview } from '../../components/DocumentPreview.jsx';

/** Print preview of the BOM sheet (what is on screen now, including unsaved changes). */
export function PrintPreview({ onClose }) {
  const dirty = useEditorStore((s) => s.dirty);
  const bom = useMemo(() => {
    const s = useEditorStore.getState();
    return {
      machineName: s.machineName, modelNo: s.modelNo, projectId: s.projectDigits ? `PRJ-${s.projectDigits}` : null,
      revision: s.revision, status: s.status, nodes: s.nodes
    };
  }, []);
  return (
    <DocumentPreview
      title="Print preview"
      subtitle={`${bom.modelNo || 'New model'}, laid out like the original BOM sheet.${dirty ? ' Includes your unsaved changes.' : ''}`}
      html={buildPrintHtml(bom, { withBar: false })}
      fileHtml={buildPrintHtml(bom, { withBar: true })}
      filename={printFileName(bom)}
      onClose={onClose}
    />
  );
}
