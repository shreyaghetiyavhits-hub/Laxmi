import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { useEditorStore } from '../../store/editorStore.js';
import { productMastersApi } from '../../api/productMasters.js';
import { toPayload, tagMap } from '../../lib/bom.js';
import { bomTotals } from '@shared/cost.js';
import { finalIssues } from '@shared/validation.js';
import { useLookups } from '../../hooks/useLookups.js';
import { useUnsavedWarning } from '../../hooks/useUnsavedWarning.js';
import { LookupLists } from '../../components/Lookups.jsx';
import { Icon } from '../../components/Icon.jsx';
import { ProductDetails } from './ProductDetails.jsx';
import { BomTree } from './BomTree.jsx';
import { NodeEditor } from './NodeEditor.jsx';
import { IssuesPanel } from './IssuesPanel.jsx';
import { BomOverview } from './BomOverview.jsx';
import { PrintPreview } from './PrintPreview.jsx';
import { PoDialog } from '../purchase-order/PoDialog.jsx';
import { startMachineReorder } from '../reorder/startMachineReorder.js';
import { SMART_REORDER, reordersApi } from '../../api/productMasters.js';
import { useConfirm } from '../../components/ConfirmProvider.jsx';

export function ProductMasterEditorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const store = useEditorStore();
  const confirm = useConfirm();
  const { nodes, status, revision, dirty } = store;

  const [loading, setLoading] = useState(Boolean(id));
  const [loadError, setLoadError] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null); // { kind: 'ok' | 'err', text, linkId? }
  const [issues, setIssues] = useState([]);
  const [savedCount, setSavedCount] = useState(0);
  const [printing, setPrinting] = useState(false);
  const [ordering, setOrdering] = useState(null); // BOM snapshot for Create PO
  const [preparing, setPreparing] = useState(false);
  const [view, setView] = useState('edit'); // 'edit' = tree + one item, 'overview' = Full BOM view
  const lookups = useLookups(savedCount);

  const locked = status === 'final';
  const tags = useMemo(() => tagMap(nodes), [nodes]);
  const totals = useMemo(() => bomTotals(nodes), [nodes]);

  useUnsavedWarning(dirty);

  // Load the document, or start a blank one for /new.
  useEffect(() => {
    // A message handed over by navigate(..., { state: { flash } }) survives the reload.
    setMessage(location.state?.flash ?? null);
    setIssues([]);
    if (!id) {
      useEditorStore.getState().startNew();
      setLoading(false);
      return undefined;
    }
    let alive = true;
    setLoading(true);
    setLoadError('');
    productMastersApi
      .get(id)
      .then((doc) => alive && useEditorStore.getState().loadDoc(doc))
      .catch((err) => alive && setLoadError(err.message))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function save(targetStatus) {
    const state = useEditorStore.getState();
    setMessage(null);

    if (state.projectDigits && state.projectDigits.length !== 4) {
      setMessage({ kind: 'err', text: 'Project ID needs 4 digits, or leave it blank.' });
      return;
    }
    if (!state.modelNo.trim()) {
      setMessage({ kind: 'err', text: 'Enter a model no before saving.' });
      return;
    }
    const payload = toPayload(state, targetStatus);
    if (targetStatus === 'final') {
      const found = finalIssues(payload);
      setIssues(found);
      if (found.length) return;
    } else {
      setIssues([]);
    }

    setSaving(true);
    try {
      const doc = state.id ? await productMastersApi.update(state.id, payload) : await productMastersApi.create(payload);
      useEditorStore.getState().loadDoc(doc);
      setSavedCount((c) => c + 1);
      const flash = {
        kind: 'ok',
        text: targetStatus === 'final' ? `Saved as final. ${doc.modelNo} R${doc.revision} is now locked.` : 'Draft saved.'
      };
      if (state.id) setMessage(flash);
      else navigate(`/product-master/${doc._id}`, { replace: true, state: { flash } });
    } catch (err) {
      if (err.issues?.length && err.status === 422) setIssues(err.issues);
      setMessage({ kind: 'err', text: err.message, linkId: err.existingId });
    } finally {
      setSaving(false);
    }
  }

  async function createRevision() {
    setSaving(true);
    setMessage(null);
    try {
      const doc = await productMastersApi.createRevision(store.id);
      navigate(`/product-master/${doc._id}`, {
        state: { flash: { kind: 'ok', text: `Revision R${doc.revision} created as a draft. You can edit it now.` } }
      });
    } catch (err) {
      setMessage({ kind: 'err', text: err.message, linkId: err.existingId });
    } finally {
      setSaving(false);
    }
  }

  /** Reorder copy: prepare its purchase orders (one per supplier) for Review and confirm. Nothing is generated here. */
  async function preparePurchaseOrders() {
    setPreparing(true);
    setMessage(null);
    try {
      if (useEditorStore.getState().dirty || !useEditorStore.getState().id) await save('draft');
      const s = useEditorStore.getState();
      if (s.dirty || !s.id) return; // save stopped with a message
      const open = ((await reordersApi.list({ status: 'draft' })).items || []).find((d) => d.source?.productMasterId === s.id);
      if (open) {
        const again = await confirm({
          title: `Purchase orders for ${s.modelNo} are already being prepared (${open.draftNo})`,
          message: 'Continue with them, or prepare them again from this machine as it is now? Preparing again replaces the earlier draft.',
          confirmLabel: 'Prepare again',
          cancelLabel: 'Continue'
        });
        if (!again) {
          navigate(`/reorder/${open._id}`);
          return;
        }
        await reordersApi.discard(open._id);
      }
      const draft = await reordersApi.create({ productMasterId: s.id, include: { BOC: true, OUT: true, IH: false, '': true }, copyMachine: false });
      navigate(`/reorder/${draft._id}`);
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    } finally {
      setPreparing(false);
    }
  }

  async function deleteDraft() {
    if (!store.id) return;
    const ok = await confirm({
      title: `Delete draft ${store.modelNo} R${store.revision}?`,
      message: 'The whole draft BOM will be deleted. Final revisions are not affected.',
      confirmLabel: 'Delete draft',
      danger: true
    });
    if (!ok) return;
    try {
      await productMastersApi.remove(store.id);
      useEditorStore.getState().startNew();
      navigate('/product-master');
    } catch (err) {
      setMessage({ kind: 'err', text: err.message });
    }
  }

  async function leave() {
    if (dirty) {
      const ok = await confirm({
        title: 'Leave without saving?',
        message: 'Your unsaved changes will be lost.',
        confirmLabel: 'Leave',
        cancelLabel: 'Stay',
        danger: true
      });
      if (!ok) return;
    }
    navigate('/product-master');
  }

  if (loading) return <div className="page"><p className="muted">Loading product master…</p></div>;
  if (loadError) {
    return (
      <div className="page">
        <p className="error-box" role="alert">{loadError}</p>
        <Link to="/product-master" className="btn">Back to product master</Link>
      </div>
    );
  }

  return (
    <div className="page">
      <LookupLists lookups={lookups} />

      <div className="page-head">
        <button type="button" className="ib bordered" aria-label="Back to product master" onClick={leave}><Icon name="back" /></button>
        <div className="grow min0">
          <p className="muted small">Product master / {store.id ? store.modelNo || 'Untitled' : 'New product'}</p>
          <h1 className="row gap center wrap">
            {store.id ? 'Edit product master' : 'Create product master'}
            <span className={`status ${status}`}>{locked ? 'Final' : 'Draft'} R{revision}</span>
            {dirty && <span className="unsaved">Unsaved changes</span>}
          </h1>
        </div>
        <div className="row gap wrap center">
          <button type="button" className="btn" onClick={() => setPrinting(true)} disabled={nodes.length === 0}>
            <Icon name="printer" size={16} /> Print BOM
          </button>
          {!store.reorderOf && (
          <button
            type="button"
            className="btn po-btn"
            disabled={nodes.length === 0}
            onClick={() => {
              const s = useEditorStore.getState();
              setOrdering({ id: s.id, modelNo: s.modelNo, machineName: s.machineName, nodes: s.nodes });
            }}
          >
            <Icon name="purchase" size={16} /> Create PO
          </button>
          )}
          {SMART_REORDER && store.id && !store.reorderOf && (
            <button type="button" className="btn reorder-btn" title="Make a full copy of this machine for a new order"
              onClick={() => (dirty
                ? setMessage({ kind: 'err', text: 'Save your changes first, then click Reorder.' })
                : startMachineReorder({ id: store.id, modelNo: store.modelNo, confirm, navigate, onError: (t) => setMessage({ kind: 'err', text: t }) }))}>
              <Icon name="history" size={16} /> Reorder
            </button>
          )}
          {locked ? (
            <button type="button" className="btn primary" onClick={createRevision} disabled={saving}>
              Create revision R{revision + 1}
            </button>
          ) : (
            <>
              {store.id && <button type="button" className="btn danger-text" onClick={deleteDraft} disabled={saving}>Delete draft</button>}
              <button type="button" className="btn" onClick={() => save('draft')} disabled={saving}>Save as draft</button>
              <button type="button" className="btn primary" onClick={() => save('final')} disabled={saving}>
                {saving ? 'Saving…' : 'Save product master'}
              </button>
            </>
          )}
        </div>
      </div>

      {message && (
        <div role="status" className={`msg ${message.kind}`}>
          <span className="grow">{message.text}</span>
          {message.linkId && <Link to={`/product-master/${message.linkId}`}>Open it</Link>}
          <button type="button" className="ib sm" aria-label="Dismiss message" onClick={() => setMessage(null)}><Icon name="close" size={16} /></button>
        </div>
      )}

      {SMART_REORDER && store.reorderOf && (
        <section className="reorder-banner" aria-label="Reorder">
          <div className="grow min0">
            <strong>Reorder of {store.reorderOf.modelNo}</strong>
            <p className="small">This is a full copy of {store.reorderOf.modelNo} for a new order. Change anything you need below; {store.reorderOf.modelNo} itself does not change. Then prepare the purchase orders, review them and confirm.</p>
          </div>
          <button type="button" className="btn primary" onClick={preparePurchaseOrders} disabled={preparing || nodes.length === 0}>
            <Icon name="purchase" size={16} /> {preparing ? 'Preparing…' : 'Prepare purchase orders'}
          </button>
        </section>
      )}

      {locked && (
        <div className="locked-note">
          <Icon name="lock" />
          <span>This revision is final, so it is read-only. Create a new revision to make changes. Earlier revisions stay unchanged.</span>
        </div>
      )}

      <IssuesPanel issues={issues} onClose={() => setIssues([])} />

      <fieldset className="plain" disabled={locked}>
        <ProductDetails totals={totals} />
      </fieldset>

      <div className="view-switch">
        <div role="group" aria-label="View" className="seg">
          <button type="button" aria-pressed={view === 'edit'} className={view === 'edit' ? 'on' : ''} onClick={() => setView('edit')}>
            <Icon name="edit" size={14} /> Edit one item
          </button>
          <button type="button" aria-pressed={view === 'overview'} className={view === 'overview' ? 'on' : ''} onClick={() => setView('overview')}>
            <Icon name="list" size={14} /> Full BOM view
          </button>
        </div>
        <span className="muted small">
          {view === 'edit' ? 'Tip: use the arrows in the tree, or Full BOM view, to see details without opening each item.' : 'Every item with its materials and sub-items, on one page.'}
        </span>
      </div>

      {view === 'edit' ? (
        <div className="workspace">
          <BomTree
            tags={tags}
            locked={locked}
            onOpenFull={() => {
              useEditorStore.getState().setAllExpanded(true);
              setView('overview');
            }}
          />
          <div className="editor">
            <NodeEditor tags={tags} locked={locked} />
          </div>
        </div>
      ) : (
        <BomOverview
          tags={tags}
          totals={totals}
          locked={locked}
          onPrint={() => setPrinting(true)}
          onEdit={(nodeUid, subUid) => {
            if (nodeUid) useEditorStore.getState().select(nodeUid, subUid);
            setView('edit');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}

      {printing && <PrintPreview onClose={() => setPrinting(false)} />}
      {ordering && (
        <PoDialog
          bom={ordering}
          tags={tagMap(ordering.nodes)}
          onClose={() => setOrdering(null)}
          onSaved={(doc) => setMessage({ kind: 'ok', text: `PO ${doc.poNo} saved for ${doc.vendor.name}. Find it any time under Purchase orders (cart icon on the left).` })}
        />
      )}
    </div>
  );
}
