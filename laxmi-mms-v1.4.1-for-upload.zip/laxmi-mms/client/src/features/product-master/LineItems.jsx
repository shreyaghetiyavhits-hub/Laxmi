import { useEditorStore } from '../../store/editorStore.js';
import { LINE_UOMS, SOURCES } from '@shared/constants.js';
import { lineTotal, isPendingRate } from '@shared/cost.js';
import { formatINR, cleanDecimal } from '../../lib/format.js';
import { Icon } from '../../components/Icon.jsx';

export function LineItems({ nodeUid, subUid, lines, tag }) {
  const addLine = useEditorStore((s) => s.addLine);
  const updateLine = useEditorStore((s) => s.updateLine);
  const removeLine = useEditorStore((s) => s.removeLine);
  const set = (lineUid, field) => (e) => {
    const raw = e.target.value;
    updateLine(nodeUid, subUid, lineUid, { [field]: field === 'qty' || field === 'rate' ? cleanDecimal(raw) : raw });
  };

  return (
    <section aria-label="Materials">
      <div className="section-head">
        <h3>Materials <span className="muted">{lines.length}</span></h3>
        <button type="button" className="btn sm" onClick={() => addLine(nodeUid, subUid)}>
          <Icon name="plus" size={14} strokeWidth={2.2} /> Add material
        </button>
      </div>

      {lines.length === 0 ? (
        <p className="empty-box">No materials yet. Add the materials and bought-out parts this item needs.</p>
      ) : (
        <div className="scroll-x">
          <div className="lines">
            <div className="l1 lines-head" aria-hidden="true">
              <span>#</span><span>Material</span><span>Source</span><span className="r">Qty</span><span>Unit</span>
              <span className="r">Rate (₹)</span><span className="r">Total</span><span />
            </div>
            {lines.map((line, i) => {
              const n = i + 1;
              return (
                <div key={line.uid} className="line-card" role="group" aria-label={`Line ${n} of ${tag}`}>
                  <div className="l1">
                    <span className="line-no">{n}</span>
                    <input className="f sm" list="dl-materials" aria-label={`Line ${n} material`} placeholder="Select or type material"
                      value={line.material} onChange={set(line.uid, 'material')} />
                    <select className={`f sm ${line.source ? '' : 'unset'}`} aria-label={`Line ${n} source`} value={line.source} onChange={set(line.uid, 'source')}>
                      <option value="">Select…</option>
                      {SOURCES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                    </select>
                    <input className="f sm num" inputMode="decimal" placeholder="Qty" aria-label={`Line ${n} quantity`} value={line.qty} onChange={set(line.uid, 'qty')} />
                    <select className={`f sm ${line.uom ? '' : 'unset'}`} aria-label={`Line ${n} unit`} value={line.uom} onChange={set(line.uid, 'uom')}>
                      <option value="">Unit…</option>
                      {LINE_UOMS.map((u) => <option key={u}>{u}</option>)}
                    </select>
                    <input className={`f sm num ${isPendingRate(line.rate) ? 'pending' : ''}`} inputMode="decimal" placeholder="0.00"
                      aria-label={`Line ${n} rate in rupees`} value={line.rate} onChange={set(line.uid, 'rate')} />
                    <span className="r strong num">{isPendingRate(line.rate) ? '—' : formatINR(lineTotal(line))}</span>
                    <button type="button" className="ib sm danger" aria-label={`Remove line ${n}`} onClick={() => removeLine(nodeUid, subUid, line.uid)}>
                      <Icon name="close" size={16} />
                    </button>
                  </div>
                  <div className="l2">
                    <span />
                    <input className="f sm soft" aria-label={`Line ${n} item code or special details`} placeholder="Code or details, e.g. 8 LH 1"
                      value={line.spec} onChange={set(line.uid, 'spec')} />
                    <input className="f sm soft" aria-label={`Line ${n} cutting size`} placeholder="Cutting size"
                      value={line.cutSize} onChange={set(line.uid, 'cutSize')} />
                    <input className="f sm soft" list="dl-processes" aria-label={`Line ${n} process`} placeholder="Process, e.g. Laser cutting"
                      value={line.process} onChange={set(line.uid, 'process')} />
                    <input className="f sm soft" list="dl-vendors" aria-label={`Line ${n} vendor`} placeholder="Vendor (optional)"
                      value={line.vendor} onChange={set(line.uid, 'vendor')} />
                    <span />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
}
