import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { purchaseOrdersApi, reordersApi, ordersApi, SMART_REORDER } from '../../api/productMasters.js';
import { buildPoHtml, poDate, poFileName } from '../../lib/poDocument.js';
import { formatINR, formatDate, plural } from '../../lib/format.js';
import { DocumentPreview } from '../../components/DocumentPreview.jsx';
import { useConfirm } from '../../components/ConfirmProvider.jsx';
import { Icon } from '../../components/Icon.jsx';
import { PoDialog } from './PoDialog.jsx';

const DRAFT_STATUS = { draft: 'Draft, not generated', generated: 'Generated', discarded: 'Discarded', generating: 'Generating' };

export function PurchaseOrdersPage() {
  const confirm = useConfirm();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const tab = SMART_REORDER ? params.get('tab') || 'pos' : 'pos';
  const setTab = (t) => setParams(t === 'pos' ? {} : { tab: t });
  const [q, setQ] = useState('');
  const [state, setState] = useState({ loading: true, error: '', items: [] });
  const [orders, setOrders] = useState([]);
  const [drafts, setDrafts] = useState([]);
  const [refresh, setRefresh] = useState(0);
  const [viewing, setViewing] = useState(null);
  const [editing, setEditing] = useState(null);
  const [message, setMessage] = useState(null);
  const [selected, setSelected] = useState(() => new Set());
  const [starting, setStarting] = useState(false);

  useEffect(() => {
    let alive = true;
    const t = setTimeout(() => {
      purchaseOrdersApi
        .list({ q })
        .then((d) => alive && setState({ loading: false, error: '', items: d.items }))
        .catch((e) => alive && setState({ loading: false, error: e.message, items: [] }));
    }, 200);
    return () => { alive = false; clearTimeout(t); };
  }, [q, refresh]);

  useEffect(() => {
    if (!SMART_REORDER) return;
    ordersApi.list().then((r) => setOrders(r.items || [])).catch(() => {});
    reordersApi.list().then((r) => setDrafts(r.items || [])).catch(() => {});
  }, [refresh]);

  const openDrafts = drafts.filter((d) => d.status === 'draft');

  const open = async (id, as) => {
    try {
      const doc = await purchaseOrdersApi.get(id);
      if (as === 'view') setViewing(doc);
      else setEditing(doc);
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    }
  };

  const remove = async (it) => {
    const ok = await confirm({ title: `Delete PO ${it.poNo}?`, message: `The purchase order to ${it.vendor?.name || 'this vendor'} will be deleted. This cannot be undone.`, confirmLabel: 'Delete PO', danger: true });
    if (!ok) return;
    try {
      await purchaseOrdersApi.remove(it._id);
      setMessage({ kind: 'ok', text: `PO ${it.poNo} deleted.` });
      setRefresh((r) => r + 1);
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    }
  };

  /** Reorder only PREPARES a draft. Purchase orders are made later, after Review and confirm. */
  async function startReorder(body, label) {
    if (starting) return;
    const existing = openDrafts.find((d) => (body.orderId ? d.source?.orderId === body.orderId : body.poIds.length === d.source?.poIds?.length && body.poIds.every((x) => d.source.poIds.includes(x))));
    if (existing) {
      const ok = await confirm({
        title: `${label} already has an open draft (${existing.draftNo})`,
        message: 'Continue that draft, or prepare a new one?',
        confirmLabel: 'Prepare a new draft',
        cancelLabel: 'Open existing draft'
      });
      if (!ok) {
        navigate(`/reorder/${existing._id}`);
        return;
      }
    }
    setStarting(true);
    try {
      const draft = await reordersApi.create(body);
      navigate(`/reorder/${draft._id}`);
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
      setStarting(false);
    }
  }

  const toggle = (id) => setSelected((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  async function discardDraft(d) {
    const ok = await confirm({ title: `Discard draft ${d.draftNo}?`, message: 'No purchase order will be created or changed.', confirmLabel: 'Discard draft', danger: true });
    if (!ok) return;
    try {
      await reordersApi.discard(d._id);
      setRefresh((r) => r + 1);
    } catch (e) {
      setMessage({ kind: 'err', text: e.message });
    }
  }

  return (
    <div className="page">
      <div className="page-head">
        <div className="grow">
          <p className="muted small">Dashboard / Purchase orders</p>
          <h1>Purchase orders</h1>
        </div>
        <button type="button" className="btn primary" onClick={() => setEditing('new')}><Icon name="plus" size={16} strokeWidth={2.2} /> New PO</button>
      </div>

      {message && (
        <div role="status" className={`msg ${message.kind}`}>
          <span className="grow">{message.text}</span>
          <button type="button" className="ib sm" aria-label="Dismiss message" onClick={() => setMessage(null)}><Icon name="close" size={16} /></button>
        </div>
      )}

      {SMART_REORDER && (
        <div role="tablist" aria-label="Purchase sections" className="tabs">
          {[['pos', `Purchase orders (${state.items.length})`], ['orders', `Orders (${orders.length})`], ['drafts', `Reorder drafts${openDrafts.length ? ` (${openDrafts.length} open)` : ''}`]].map(([key, label]) => (
            <button key={key} type="button" role="tab" aria-selected={tab === key} className={tab === key ? 'on' : ''} onClick={() => setTab(key)}>{label}</button>
          ))}
        </div>
      )}

      {tab === 'pos' && (
        <>
          <p className="muted small">
            {SMART_REORDER
              ? <>To order the same again, click <strong>Reorder</strong> on a PO, or tick several POs and click <strong>Reorder selected</strong>. For a whole machine, click <strong>Reorder</strong> in Product master. Nothing is generated until you review and confirm.</>
              : <>Tip: to order materials from a BOM, open the BOM and click <strong>Create PO</strong>.</>}
          </p>
          <div className="toolbar">
            <div className="search">
              <label htmlFor="po-q" className="sr-only">Search by PO no, vendor or model</label>
              <Icon name="search" size={16} />
              <input id="po-q" className="f" placeholder="Search PO no, vendor or model" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            {SMART_REORDER && selected.size > 0 && (
              <>
                <button type="button" className="btn primary" disabled={starting} onClick={() => startReorder({ poIds: [...selected] }, `${plural(selected.size, 'PO', 'POs')}`)}>
                  <Icon name="history" size={16} /> Reorder selected ({selected.size})
                </button>
                <button type="button" className="btn" onClick={() => setSelected(new Set())}>Clear selection</button>
              </>
            )}
          </div>

          <div className="panel table-wrap">
            {state.error && <p className="error-box" role="alert">{state.error}</p>}
            {!state.error && !state.loading && state.items.length === 0 && (
              <div className="empty-list"><h2>No purchase orders yet</h2><p className="muted">Open a BOM and click Create PO, or use New PO.</p></div>
            )}
            {state.items.length > 0 && (
              <div className="scroll-x">
                <table className="table">
                  <thead>
                    <tr>{SMART_REORDER && <th className="sel"><span className="sr-only">Select</span></th>}<th>P.O. No</th><th>Date</th><th>Vendor</th><th>From</th><th className="r">Rows</th><th className="r">G. Total</th><th className="r">Actions</th></tr>
                  </thead>
                  <tbody>
                    {state.items.map((it) => (
                      <tr key={it._id} className={selected.has(it._id) ? 'sel-row' : ''}>
                        {SMART_REORDER && <td className="sel"><input type="checkbox" aria-label={`Select PO ${it.poNo}`} checked={selected.has(it._id)} onChange={() => toggle(it._id)} /></td>}
                        <td className="strong">
                          {it.poNo}
                          {it.reorder?.sourcePoNo && <div className="muted small reorder-of">Reorder of PO {it.reorder.sourcePoNo}</div>}
                        </td>
                        <td>{poDate(it.date)}</td>
                        <td>{it.vendorId ? <Link to={`/vendors/${it.vendorId}`}>{it.vendor?.name}</Link> : it.vendor?.name}</td>
                        <td>{it.modelNo || <span className="muted">—</span>}</td>
                        <td className="r num">{it.lineCount ?? it.lines?.length ?? ''}</td>
                        <td className="r num strong">{formatINR(it.totals?.grandTotal)}</td>
                        <td className="r nowrap">
                          <button type="button" className="btn sm" onClick={() => open(it._id, 'view')}><Icon name="printer" size={14} /> View</button>{' '}
                          {SMART_REORDER && <><button type="button" className="btn sm reorder-btn" disabled={starting} onClick={() => startReorder({ poIds: [it._id] }, `PO ${it.poNo}`)}><Icon name="history" size={14} /> Reorder</button>{' '}</>}
                          <button type="button" className="btn sm" onClick={() => open(it._id, 'edit')}><Icon name="edit" size={14} /> Edit</button>{' '}
                          <button type="button" className="ib sm danger" aria-label={`Delete PO ${it.poNo}`} onClick={() => remove(it)}><Icon name="trash" size={16} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {state.loading && !state.items.length && !state.error && <p className="muted pad">Loading…</p>}
          </div>
        </>
      )}

      {tab === 'orders' && (
        <div className="panel table-wrap">
          {orders.length === 0 ? (
            <div className="empty-list"><h2>No orders yet</h2><p className="muted">An order is created each time a reorder is generated. Start with <strong>Reorder</strong> on a purchase order.</p></div>
          ) : (
            <div className="scroll-x">
              <table className="table">
                <thead><tr><th>Order</th><th>Date</th><th>Model</th><th>Purchase orders</th><th>Reordered from</th><th className="r">Total</th><th className="r">Actions</th></tr></thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o._id}>
                      <td className="strong">{o.orderNo}{o.projectId && <div className="muted small">{o.projectId}</div>}</td>
                      <td>{poDate(o.date)}</td>
                      <td>{o.modelNo || <span className="muted">—</span>}</td>
                      <td>{o.poIds.map((pid, i) => <button key={pid} type="button" className="linkish po-link" onClick={() => open(pid, 'view')}>PO {o.poNos.at(i)}</button>)}</td>
                      <td className="muted">{o.reorderedFrom?.reorderOfModelNo ? `Reorder of ${o.reorderedFrom.reorderOfModelNo} (${o.reorderedFrom.modelNo})` : o.reorderedFrom?.modelNo ? `Machine ${o.reorderedFrom.modelNo}` : o.reorderedFrom?.orderNo ? `Order ${o.reorderedFrom.orderNo}` : o.reorderedFrom?.poNos?.length ? `PO ${o.reorderedFrom.poNos.join(', ')}` : '—'}</td>
                      <td className="r num strong">{o.total !== undefined ? formatINR(o.total) : '—'}</td>
                      <td className="r"><button type="button" className="btn sm reorder-btn" disabled={starting} onClick={() => startReorder({ orderId: o._id }, `Order ${o.orderNo}`)}><Icon name="history" size={14} /> Reorder</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === 'drafts' && (
        <div className="panel table-wrap">
          {drafts.length === 0 ? (
            <div className="empty-list"><h2>No reorder drafts</h2><p className="muted">Click <strong>Reorder</strong> on a purchase order or an order to prepare one.</p></div>
          ) : (
            <div className="scroll-x">
              <table className="table">
                <thead><tr><th>Draft</th><th>From</th><th>Status</th><th className="r">POs</th><th className="r">Rows</th><th>Result</th><th>Updated</th><th className="r">Actions</th></tr></thead>
                <tbody>
                  {drafts.map((d) => (
                    <tr key={d._id}>
                      <td className="strong">{d.draftNo}</td>
                      <td>{d.source?.kind === 'bom' ? (d.source.reorderOfModelNo ? `Reorder of ${d.source.reorderOfModelNo} (${d.source.modelNo})` : `Machine ${d.source.modelNo}`) : d.source?.orderNo ? `Order ${d.source.orderNo}` : `PO ${(d.source?.poNos || []).join(', ')}`}</td>
                      <td><span className={`rstatus ${d.status}`}>{DRAFT_STATUS[d.status]}</span></td>
                      <td className="r num">{d.poCount ?? '—'}</td>
                      <td className="r num">{d.rowCount ?? '—'}</td>
                      <td>{d.status === 'generated' ? `PO ${d.generated.poNos.join(', ')}` : <span className="muted">—</span>}</td>
                      <td className="muted">{formatDate(d.updatedAt)}</td>
                      <td className="r nowrap">
                        <Link to={`/reorder/${d._id}`} className="btn sm">{d.status === 'draft' ? 'Continue' : 'Open'}</Link>{' '}
                        {d.status === 'draft' && <button type="button" className="btn sm danger-text" onClick={() => discardDraft(d)}>Discard</button>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {viewing && (
        <DocumentPreview title={`Purchase order ${viewing.poNo}`} subtitle={`${viewing.vendor?.name || ''}, ${poDate(viewing.date)}${viewing.reorder?.sourcePoNo ? ` · reorder of PO ${viewing.reorder.sourcePoNo}` : ''}`}
          html={buildPoHtml(viewing, { withBar: false })} fileHtml={buildPoHtml(viewing, { withBar: true })} filename={poFileName(viewing)} onClose={() => setViewing(null)} />
      )}
      {editing && (
        <PoDialog existing={editing === 'new' ? undefined : editing} onClose={() => { setEditing(null); setRefresh((r) => r + 1); }} onSaved={() => setRefresh((r) => r + 1)} />
      )}
    </div>
  );
}
