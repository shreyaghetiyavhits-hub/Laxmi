import { useEffect, useMemo, useRef, useState } from 'react';
import { purchaseOrdersApi, vendorsApi, vendorMaterialsApi } from '../../api/productMasters.js';
import { VendorFormDialog } from '../vendors/VendorFormDialog.jsx';
import { purchaseCandidates, sameVendor } from '../../lib/poCandidates.js';
import { buildPoHtml, poFileName } from '../../lib/poDocument.js';
import { printFrame, downloadHtml } from '../../lib/docActions.js';
import { uid } from '../../lib/bom.js';
import { cleanDecimal, formatINR, plural } from '../../lib/format.js';
import { sourceLabel } from '../../lib/labels.js';
import { computePo, round2 } from '@shared/po.js';
import { COMPANY, STANDARD_GST_PCT, GST_RATES } from '@shared/company.js';
import { resolveState, stateFromGstin } from '@shared/gstStates.js';
import { StateSelect } from '../../components/StateSelect.jsx';
import { toNumber, isPendingRate } from '@shared/cost.js';
import { useConfirm } from '../../components/ConfirmProvider.jsx';
import { Icon } from '../../components/Icon.jsx';
import { IS_DEMO } from '../../api/productMasters.js';

const UNITS = ['NOS', 'SET', 'PAIR', 'FT', 'MM', 'M', 'KG', 'SHEET'];
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const isBlank = (v) => v === '' || v === null || v === undefined;
const pickState = (v) => { const r = resolveState(v); return { state: r.state, stateCode: r.stateCode }; };
const str = (v) => (v === null || v === undefined ? '' : String(v));

// A new PO starts blank: date, vendor and rows are entered by the user. GST rate on a row comes from the
// vendor's material list or the company standard rate; the vendor's state decides CGST + SGST or IGST.
function blankPo() {
  return {
    poNo: '', date: '', refNo: '', refDate: '', kindAttn: '',
    vendorId: null,
    vendor: { name: '', address: '', state: '', stateCode: '', gstin: '' },
    lines: [], paymentTerms: '', remark: '', terms: ''
  };
}

function fromSaved(doc) {
  return {
    ...blankPo(),
    ...doc,
    vendorId: doc.vendorId || null,
    vendor: { ...blankPo().vendor, ...doc.vendor },
    lines: doc.lines.map((l) => ({
      ...l, key: l.source?.lineUid ? `l:${l.source.lineUid}` : l.source?.itemUid ? `i:${l.source.itemUid}` : '',
      qty: str(l.qty), rate: str(l.rate), discPct: str(l.discPct), gstPct: str(l.gstPct), gstFrom: '', autoQty: false,
      vendorMaterialId: l.vendorMaterialId || '', material: '', rateFrom: ''
    }))
  };
}

function toPayload(po, context) {
  return {
    poNo: po.poNo.trim(),
    date: po.date,
    refNo: po.refNo,
    refDate: po.refDate,
    kindAttn: po.kindAttn,
    vendorId: po.vendorId || null,
    vendor: { ...po.vendor, gstin: po.vendor.gstin.toUpperCase() },
    productMaster: context.productMaster ?? null,
    modelNo: context.modelNo ?? '',
    machines: null, // not asked any more: quantities come straight from the BOM
    // Blank numbers go out as null (or '' for required ones, which the checks stop first). Never 0 or 18 by default.
    lines: po.lines.map((l) => ({
      uid: l.uid, description: l.description.trim(), hsn: l.hsn, qty: isBlank(l.qty) ? '' : toNumber(l.qty), uom: l.uom,
      rate: isBlank(l.rate) ? '' : toNumber(l.rate), discPct: isBlank(l.discPct) ? null : toNumber(l.discPct),
      gstPct: isBlank(l.gstPct) ? '' : toNumber(l.gstPct), vendorMaterialId: l.vendorMaterialId || null, source: l.source || {}
    })),
    paymentTerms: po.paymentTerms,
    remark: po.remark,
    terms: po.terms
  };
}

function checkPo(po) {
  const issues = [];
  if (!po.date) issues.push('Enter the PO date.');
  if (!po.vendor.name.trim()) issues.push('Enter the vendor name.');
  if (!resolveState(po.vendor).stateCode) issues.push('Choose the vendor’s state. It decides CGST + SGST (Gujarat) or IGST (other states).');
  if (!po.lines.length) issues.push('Add at least one row to order.');
  po.lines.forEach((l, i) => {
    const row = `Row ${i + 1}${l.description.trim() ? ` (${l.description.trim()})` : ''}`;
    if (!l.description.trim()) issues.push(`Row ${i + 1} needs a description.`);
    if (isBlank(l.qty) || !(toNumber(l.qty) > 0)) issues.push(`${row}: enter the quantity.`);
    if (isBlank(l.rate)) issues.push(`${row}: enter the rate.`);
    if (isBlank(l.gstPct)) issues.push(`${row}: choose the GST rate.`);
  });
  return issues;
}

const STEPS = [
  { no: 1, label: 'Choose items' },
  { no: 2, label: 'PO details' },
  { no: 3, label: 'Preview & save' }
];

/**
 * Create or edit a purchase order.
 * - From a BOM: pass `bom` ({ id, modelNo, machineName, nodes }) and `tags`; starts at step 1.
 * - Edit a saved PO: pass `existing`; starts at step 2.
 * - Blank PO: pass neither; starts at step 2.
 */
export function PoDialog({ bom, tags, existing, presetVendorId, onClose, onSaved }) {
  const confirm = useConfirm();
  const dialogRef = useRef(null);
  const frameRef = useRef(null);
  const hasBom = Boolean(bom);

  const [step, setStep] = useState(hasBom && !existing ? 1 : 2);
  const [po, setPo] = useState(() => (existing ? fromSaved(existing) : blankPo()));
  const [vendors, setVendors] = useState([]); // from the Vendor master
  const [vendorForm, setVendorForm] = useState(null); // { vendor } to edit, or { initial } to add
  const [rateList, setRateList] = useState([]); // the chosen vendor's materials (not inactive)
  const [nextNo, setNextNo] = useState('');
  const [filter, setFilter] = useState('purchase');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(() => new Set());
  const [issues, setIssues] = useState([]);
  const [saved, setSaved] = useState(existing || null);
  const [changed, setChanged] = useState(false); // edits not yet saved
  const [saving, setSaving] = useState(false);
  const [note, setNote] = useState(null);

  const candidates = useMemo(() => (hasBom ? purchaseCandidates(bom.nodes, tags) : []), [hasBom, bom, tags]);
  const context = { productMaster: bom?.id ?? existing?.productMaster ?? null, modelNo: bom?.modelNo ?? existing?.modelNo ?? '' };

  useEffect(() => {
    const d = dialogRef.current;
    if (d && typeof d.showModal === 'function' && !d.open) d.showModal();
    loadVendors();
    purchaseOrdersApi.nextNumber().then((r) => setNextNo(r.poNo)).catch(() => {});
  }, []);

  function loadVendors() {
    return vendorsApi.list().then((r) => {
      const list = (r.items || []).filter((v) => v.status !== 'inactive');
      setVendors(list);
      if (presetVendorId && !po.vendorId) {
        const v = list.find((x) => x._id === presetVendorId);
        if (v) applyVendorName(v.name, list);
      }
      return list;
    }).catch(() => []);
  }

  // The chosen vendor's material list: used to link PO rows and fill in their rates.
  useEffect(() => {
    if (!po.vendorId) {
      setRateList([]);
      return;
    }
    let alive = true;
    vendorMaterialsApi.list(po.vendorId)
      .then((r) => alive && setRateList((r.items || []).filter((m) => m.status !== 'inactive')))
      .catch(() => alive && setRateList([]));
    return () => { alive = false; };
  }, [po.vendorId]);

  const findInRateList = (name, list = rateList) =>
    list.find((m) => String(name || '').trim() !== '' && m.material.trim().toLowerCase() === String(name).trim().toLowerCase());

  /** Link a row to a rate-list material. Fills rate, unit and description only where they are still blank. */
  const linkRow = (row, m) => {
    if (!m) return { ...row, vendorMaterialId: '', rateFrom: '' };
    const fillRate = isBlank(row.rate) && m.current;
    const useListGst = row.gstFrom !== 'user' && !isBlank(m.gstPct); // a GST rate typed on the row is kept
    return {
      ...row,
      ...(useListGst ? { gstPct: str(m.gstPct), gstFrom: 'list' } : {}),
      vendorMaterialId: m._id,
      description: row.description || [m.material, m.specification].filter(Boolean).join(' '),
      uom: row.uom || m.unit || '',
      rate: fillRate ? str(m.current.rate) : row.rate,
      rateFrom: fillRate ? `${m.current.source === 'po' ? `last PO ${m.current.poNo}` : 'rate list'}, ${m.current.at}` : row.rateFrom || ''
    };
  };

  // When the rate list arrives, link BOM rows whose material name matches (only rows not linked yet).
  useEffect(() => {
    if (!rateList.length) return;
    setPo((p) => ({ ...p, lines: p.lines.map((l) => (l.vendorMaterialId || !l.material ? l : (findInRateList(l.material) ? linkRow(l, findInRateList(l.material)) : l))) }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rateList]);

  const vendorNames = useMemo(() => vendors.map((v) => v.name).sort((a, b) => a.localeCompare(b)), [vendors]);

  // If a name was typed before the Vendor master finished loading, link it as soon as the list arrives.
  useEffect(() => {
    if (!po.vendorId && po.vendor.name.trim() && vendors.some((v) => sameVendor(v.name, po.vendor.name))) {
      applyVendorName(po.vendor.name, vendors);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vendors]);
  const linkedVendor = vendors.find((v) => v._id === po.vendorId) || null;
  const typedNotInMaster = po.vendor.name.trim() !== '' && !po.vendorId;

  const edit = (fn) => {
    setPo(fn);
    setChanged(true);
    setNote(null);
  };

  /** Picking a vendor from the Vendor master fills in all its details automatically. */
  function applyVendorName(name, list = vendors) {
    const known = list.find((v) => sameVendor(v.name, name));
    edit((p) => {
      if (known) {
        const sameAsBefore = p.vendorId === known._id;
        return {
          ...p,
          lines: sameAsBefore ? p.lines : p.lines.map((l) => ({ ...l, vendorMaterialId: '', rateFrom: '' })),
          vendorId: known._id,
          vendor: { name: known.name, address: known.address || '', gstin: known.gstin || '', ...pickState(known) },
          kindAttn: known.contactPerson || '',
          paymentTerms: known.paymentTerms || ''
        };
      }
      // Typed a name that is not in the master: if we were linked to a vendor before, drop its details.
      if (p.vendorId) {
        return { ...p, vendorId: null, lines: p.lines.map((l) => ({ ...l, vendorMaterialId: '', rateFrom: '' })), vendor: { name, address: '', state: '', stateCode: '', gstin: '' }, kindAttn: '', paymentTerms: '' };
      }
      return { ...p, vendor: { ...p.vendor, name } };
    });
    const matches = candidates.filter((c) => sameVendor(c.vendor, name));
    if (matches.length) {
      setSelected(new Set(matches.map((c) => c.key)));
      setFilter('vendor');
    }
  }

  // ---------- Step 1 ----------
  const vendorMatches = candidates.filter((c) => sameVendor(c.vendor, po.vendor.name)).length;
  const needle = search.trim().toLowerCase();
  const visible = candidates.filter((c) => {
    const inFilter = filter === 'all' ? true : filter === 'vendor' ? sameVendor(c.vendor, po.vendor.name) : c.source === 'BOC' || c.source === 'OUT';
    const inSearch = !needle || `${c.description} ${c.where} ${c.vendor}`.toLowerCase().includes(needle);
    return (inFilter || selected.has(c.key)) && inSearch;
  });


  function toggle(key) {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
    setChanged(true);
  }

  function goToDetails() {
    edit((p) => {
      const old = new Map(p.lines.filter((l) => l.key).map((l) => [l.key, l]));
      const fromBom = candidates
        .filter((c) => selected.has(c.key))
        .map((c) => {
          const autoQty = c.qtyPerMachine === null ? '' : str(round2(c.qtyPerMachine)); // quantity as in the BOM
          const prev = old.get(c.key);
          if (prev) return prev.autoQty ? { ...prev, qty: autoQty } : prev;
          const row = {
            uid: uid(), key: c.key, material: c.material, description: c.description, hsn: '', qty: autoQty, autoQty: true,
            uom: String(c.uom || '').toUpperCase(), rate: isPendingRate(c.rate) ? '' : str(c.rate), discPct: '',
            gstPct: str(STANDARD_GST_PCT), gstFrom: 'standard',
            vendorMaterialId: '', rateFrom: isPendingRate(c.rate) ? '' : 'BOM rate',
            source: { itemUid: c.itemUid, lineUid: c.lineUid, label: c.where }
          };
          const listed = findInRateList(c.material); // same material in the vendor's list?
          return listed ? linkRow(row, listed) : row;
        });
      return { ...p, lines: [...fromBom, ...p.lines.filter((l) => !l.key)] };
    });
    setIssues([]);
    setStep(2);
  }

  // ---------- Step 2 ----------
  const setField = (field) => (e) => edit((p) => ({ ...p, [field]: e.target.value }));
  const setVendor = (field) => (e) => {
    let value = e.target.value;
    if (field === 'gstin') {
      value = value.toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 15);
      // No state chosen yet? The GSTIN's first 2 digits tell us.
      edit((p) => {
        const s = !resolveState(p.vendor).stateCode && stateFromGstin(value);
        return { ...p, vendor: { ...p.vendor, gstin: value, ...(s ? { state: s.name, stateCode: s.code } : {}) } };
      });
      return;
    }
    edit((p) => ({ ...p, vendor: { ...p.vendor, [field]: value } }));
  };
  const setLine = (lineUid, field) => (e) => {
    const raw = e.target.value;
    const value = ['qty', 'rate', 'discPct', 'gstPct'].includes(field) ? cleanDecimal(raw) : raw;
    edit((p) => ({ ...p, lines: p.lines.map((l) => (l.uid === lineUid ? { ...l, [field]: value, ...(field === 'qty' ? { autoQty: false } : {}), ...(field === 'rate' ? { rateFrom: '' } : {}), ...(field === 'gstPct' ? { gstFrom: 'user' } : {}) } : l)) }));
  };
  const setLineMaterial = (lineUid) => (e) => {
    const m = rateList.find((x) => x._id === e.target.value);
    edit((p) => ({ ...p, lines: p.lines.map((l) => (l.uid === lineUid ? linkRow(l, m) : l)) }));
  };
  const addRow = () =>
    edit((p) => ({
      ...p,
      lines: [...p.lines, { uid: uid(), key: '', material: '', description: '', hsn: '', qty: '', uom: '', rate: '', discPct: '', gstPct: str(STANDARD_GST_PCT), gstFrom: 'standard', vendorMaterialId: '', rateFrom: '', source: {} }]
    }));
  const removeRow = (lineUid) => {
    edit((p) => ({ ...p, lines: p.lines.filter((l) => l.uid !== lineUid) }));
    const row = po.lines.find((l) => l.uid === lineUid);
    if (row?.key) setSelected((s) => { const n = new Set(s); n.delete(row.key); return n; });
  };

  const payload = toPayload(po, context);
  const totals = computePo(payload);

  function goToPreview() {
    const found = checkPo(po);
    setIssues(found);
    if (!found.length) setStep(3);
  }

  // ---------- Step 3 ----------
  const shownNo = saved && !changed ? saved.poNo : po.poNo.trim() || nextNo;
  const previewHtml = buildPoHtml({ ...payload, poNo: shownNo }, { withBar: false, draft: !saved || changed });

  async function save() {
    const found = checkPo(po);
    if (found.length) {
      setIssues(found);
      setStep(2);
      return;
    }
    setSaving(true);
    setNote(null);
    try {
      const doc = saved ? await purchaseOrdersApi.update(saved._id, payload) : await purchaseOrdersApi.create(payload);
      setSaved(doc);
      setPo((p) => ({ ...p, poNo: doc.poNo }));
      setChanged(false);
      setNote({ kind: 'ok', text: `Saved as PO ${doc.poNo}. You can print or download it now. It is also listed under Purchase orders.` });
      onSaved?.(doc);
    } catch (err) {
      setNote({ kind: 'err', text: err.message + (err.issues?.length ? ` ${err.issues.map((i) => i.message).join('. ')}.` : '') });
    } finally {
      setSaving(false);
    }
  }

  function print() {
    if (!printFrame(frameRef.current)) {
      setNote({ kind: 'info', text: 'If no print window opened, click Download, open the file, then click “Print / Save as PDF”.' });
    }
  }

  async function download() {
    const doc = { ...payload, poNo: shownNo };
    const result = await downloadHtml(poFileName(doc), buildPoHtml(doc, { withBar: true, draft: !saved || changed }));
    setNote({ kind: result.ok ? 'ok' : 'info', text: result.message });
  }

  async function close() {
    if (changed) {
      const ok = await confirm({
        title: saved ? 'Close without saving your changes?' : 'Close without saving this PO?',
        message: saved ? `PO ${saved.poNo} keeps its last saved version.` : 'The PO has not been saved yet, so it will be lost.',
        confirmLabel: 'Close',
        cancelLabel: 'Keep working',
        danger: true
      });
      if (!ok) return;
    }
    onClose();
  }

  const canGo = (no) => no === 1 ? hasBom : no === 2 ? true : checkPo(po).length === 0;
  const title = existing ? `Edit PO ${existing.poNo}` : 'Create purchase order';

  return (
    <dialog ref={dialogRef} className="po-dialog" aria-label={title} onCancel={(e) => { e.preventDefault(); close(); }}>
      <header className="po-head">
        <div className="grow min0">
          <h2>{title}</h2>
          <p className="muted small">{hasBom ? `From ${bom.modelNo || 'this BOM'}` : existing?.modelNo ? `From ${existing.modelNo}` : 'Rows typed in by hand'}</p>
        </div>
        <ol className="po-steps" aria-label="Steps">
          {STEPS.filter((s) => hasBom || s.no !== 1).map((s) => (
            <li key={s.no}>
              <button type="button" className={step === s.no ? 'on' : step > s.no ? 'done' : ''} aria-current={step === s.no ? 'step' : undefined}
                disabled={!canGo(s.no)} onClick={() => (s.no === 2 && step === 1 ? goToDetails() : s.no === 3 ? goToPreview() : setStep(s.no))}>
                <span className="dot">{step > s.no ? '✓' : hasBom ? s.no : s.no - 1}</span>{s.label}
              </button>
            </li>
          ))}
        </ol>
        <button type="button" className="ib" aria-label="Close" onClick={close}><Icon name="close" /></button>
      </header>

      <div className="po-body">
        {step === 1 && (
          <div className="po-step">
            {issues.length > 0 && step === 1 && (
              <div className="issues" role="alert">
                <div className="issues-head"><Icon name="alert" /><strong>{issues.join(' ')}</strong></div>
              </div>
            )}
            <div className="po-row">
              <div className="po-vendor-pick">
                <label className="lbl" htmlFor="po-vendor">1. Who are you ordering from?</label>
                <input id="po-vendor" className="f" list="po-vendors" placeholder="Type or pick a vendor" value={po.vendor.name}
                  onChange={(e) => applyVendorName(e.target.value)} />
                <datalist id="po-vendors">{vendorNames.map((v) => <option key={v} value={v} />)}</datalist>
                <VendorStatus po={po} linked={linkedVendor} notInMaster={typedNotInMaster} onAdd={() => setVendorForm({ initial: { name: po.vendor.name } })}
                  onEdit={() => setVendorForm({ vendor: linkedVendor })} />
                <p className="help">{po.vendor.name ? (vendorMatches ? `${plural(vendorMatches, 'item in this BOM is', 'items in this BOM are')} assigned to this vendor and ticked for you.` : 'No items in this BOM name this vendor. Tick the ones you want below.') : 'Pick a vendor from the Vendor master. Its details fill in automatically, and its items in this BOM are ticked.'}</p>
              </div>
            </div>

            <div className="po-row center wrap">
              <span className="lbl" style={{ margin: 0 }}>2. Tick what to order</span>
              <div role="group" aria-label="Show" className="seg">
                <button type="button" aria-pressed={filter === 'vendor'} className={filter === 'vendor' ? 'on' : ''} disabled={!vendorMatches} onClick={() => setFilter('vendor')}>This vendor ({vendorMatches})</button>
                <button type="button" aria-pressed={filter === 'purchase'} className={filter === 'purchase' ? 'on' : ''} onClick={() => setFilter('purchase')}>Bought-out &amp; outsource</button>
                <button type="button" aria-pressed={filter === 'all'} className={filter === 'all' ? 'on' : ''} onClick={() => setFilter('all')}>All materials ({candidates.length})</button>
              </div>
              <div className="search grow">
                <label htmlFor="po-search" className="sr-only">Search materials</label>
                <Icon name="search" size={16} />
                <input id="po-search" className="f" placeholder="Search, e.g. knob" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
            </div>

            <div className="po-pick panel">
              <div className="po-pick-head">
                <span className="strong">{selected.size} selected</span>
                <button type="button" className="linkish small" onClick={() => setSelected(new Set([...selected, ...visible.map((c) => c.key)]))} disabled={!visible.length}>Tick all shown</button>
                <button type="button" className="linkish small" onClick={() => setSelected(new Set())} disabled={!selected.size}>Clear</button>
              </div>
              {visible.length === 0 ? (
                <p className="muted pad">{candidates.length ? 'Nothing matches. Try “All materials” or clear the search.' : 'This BOM has no materials or bought-out items yet.'}</p>
              ) : (
                <ul className="po-cands">
                  {visible.map((c) => {
                    const on = selected.has(c.key);
                    return (
                      <li key={c.key}>
                        <label className={`po-cand ${on ? 'on' : ''}`}>
                          <input type="checkbox" checked={on} onChange={() => toggle(c.key)} />
                          <span className="grow min0">
                            <span className="strong-ish block ellipsis">{c.description}</span>
                            <span className="muted small block ellipsis">{c.where}</span>
                          </span>
                          <span className={`src ${c.source}`}>{sourceLabel(c.source)}</span>
                          <span className="small muted vend ellipsis">{c.vendor || 'No vendor'}</span>
                          <span className="num qty">{c.qtyPerMachine === null ? <span className="pending-text small">Qty not in BOM</span> : `${c.qtyPerMachine} ${c.uom || ''}`}</span>
                          <span className="num small rate">{isPendingRate(c.rate) ? <span className="pending-text">No rate</span> : formatINR(toNumber(c.rate))}</span>
                        </label>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="po-step">
            {issues.length > 0 && (
              <div className="issues" role="alert">
                <div className="issues-head"><Icon name="alert" /><strong>Please fix these first:</strong></div>
                <ul>{issues.map((t) => <li key={t}>{t}</li>)}</ul>
              </div>
            )}

            <div className="po-grid">
              <section className="panel po-card" aria-label="PO details">
                <h3>PO details</h3>
                <div className="g2">
                  <div>
                    <label className="lbl" htmlFor="po-no">P.O. No</label>
                    <input id="po-no" className="f" placeholder={nextNo ? `Automatic: ${nextNo}` : 'Automatic'} value={po.poNo} onChange={setField('poNo')} />
                  </div>
                  <div>
                    <label className="lbl" htmlFor="po-date">Date <span className="req">*</span></label>
                    <div className="row gap">
                      <input id="po-date" className="f" type="date" value={po.date} onChange={setField('date')} />
                      <button type="button" className="btn sm" onClick={() => edit((p) => ({ ...p, date: today() }))}>Today</button>
                    </div>
                  </div>
                  <div>
                    <label className="lbl" htmlFor="po-ref">Ref. No</label>
                    <input id="po-ref" className="f" placeholder="e.g. EKTA RR" value={po.refNo} onChange={setField('refNo')} />
                  </div>
                  <div>
                    <label className="lbl" htmlFor="po-refdate">Ref. date</label>
                    <input id="po-refdate" className="f" type="date" value={po.refDate} onChange={setField('refDate')} />
                  </div>
                  <div className="span2">
                    <label className="lbl" htmlFor="po-attn">Kind Attn.</label>
                    <input id="po-attn" className="f" placeholder="Contact person (optional)" value={po.kindAttn} onChange={setField('kindAttn')} />
                  </div>
                </div>
              </section>

              <section className="panel po-card" aria-label="Vendor">
                <h3>Vendor (To)</h3>
                <VendorStatus po={po} linked={linkedVendor} notInMaster={typedNotInMaster} onAdd={() => setVendorForm({ initial: { ...po.vendor } })}
                  onEdit={() => setVendorForm({ vendor: linkedVendor })} />
                <div className="g2">
                  <div className="span2">
                    <label className="lbl" htmlFor="po-vname">Vendor name <span className="req">*</span></label>
                    <input id="po-vname" className="f" list="po-vendors-2" value={po.vendor.name} onChange={(e) => applyVendorName(e.target.value)} />
                    <datalist id="po-vendors-2">{vendorNames.map((v) => <option key={v} value={v} />)}</datalist>
                  </div>
                  <div className="span2">
                    <label className="lbl" htmlFor="po-vaddr">Address</label>
                    <textarea id="po-vaddr" className="f ta" rows={2} value={po.vendor.address} onChange={setVendor('address')} />
                  </div>
                  <div className="span2">
                    <label className="lbl" htmlFor="po-vstate">State <span className="req">*</span></label>
                    <StateSelect id="po-vstate" value={po.vendor.state} onChange={(st) => edit((p) => ({ ...p, vendor: { ...p.vendor, ...st } }))} required />
                  </div>
                  <div className="span2">
                    <label className="lbl" htmlFor="po-vgst">Vendor GSTIN</label>
                    <input id="po-vgst" className="f" placeholder="15 characters" value={po.vendor.gstin} onChange={setVendor('gstin')} />
                  </div>
                </div>
                <p className={resolveState(po.vendor).stateCode ? 'help' : 'help pending-text'}>
                  {resolveState(po.vendor).stateCode
                    ? totals.intra ? `${resolveState(po.vendor).state} is our own state: GST is split into CGST + SGST.` : `${resolveState(po.vendor).state} is another state: IGST is charged.`
                    : 'Choose the state. Gujarat → CGST + SGST, other states → IGST.'}
                </p>
              </section>
            </div>

            <section className="panel po-card" aria-label="Rows to order">
              <div className="section-head">
                <div>
                  <h3>Rows to order <span className="muted">{po.lines.length}</span></h3>
                  <p className="muted small">GST rate comes from the vendor’s material list, otherwise the standard {STANDARD_GST_PCT}%. Change it on a row if that item has a different rate.</p>
                </div>
                <button type="button" className="btn sm" onClick={addRow}><Icon name="plus" size={14} strokeWidth={2.2} /> Add row</button>
              </div>
              {po.lines.length === 0 ? (
                <p className="empty-box">No rows yet. {hasBom ? 'Go back to tick items from the BOM, or ' : ''}use Add row.</p>
              ) : (
                <div className="scroll-x">
                  <table className="po-lines">
                    <colgroup>
                      <col style={{ width: 36 }} /><col /><col style={{ width: 90 }} /><col style={{ width: 84 }} /><col style={{ width: 92 }} />
                      <col style={{ width: 100 }} /><col style={{ width: 70 }} /><col style={{ width: 70 }} /><col style={{ width: 110 }} /><col style={{ width: 40 }} />
                    </colgroup>
                    <thead>
                      <tr><th>#</th><th>Description</th><th>HSN</th><th className="r">Qty</th><th>Unit</th><th className="r">Rate (₹)</th><th className="r">Disc %</th><th className="r">GST %</th><th className="r">Amount</th><th /></tr>
                    </thead>
                    <tbody>
                      {totals.lines.map((l, i) => {
                        const row = po.lines[i];
                        return (
                          <tr key={row.uid}>
                            <td className="muted">{i + 1}</td>
                            <td>
                              <input className="f sm" aria-label={`Row ${i + 1} description`} value={row.description} onChange={setLine(row.uid, 'description')} />
                              {po.vendorId && (
                                <select className={`f sm rate-link ${row.vendorMaterialId ? 'linked' : 'unset'}`} aria-label={`Row ${i + 1}: vendor's material`}
                                  value={row.vendorMaterialId || ''} onChange={setLineMaterial(row.uid)}>
                                  <option value="">{rateList.length ? 'Link to vendor’s material list…' : 'Vendor has no material list yet'}</option>
                                  {rateList.map((m) => (
                                    <option key={m._id} value={m._id}>{m.material}{m.specification ? ` (${m.specification})` : ''}{m.current ? `: ₹${m.current.rate}` : ''}</option>
                                  ))}
                                </select>
                              )}
                              {row.source?.label && <div className="muted small ellipsis" title={row.source.label}>From {row.source.label}</div>}
                            </td>
                            <td><input className="f sm" aria-label={`Row ${i + 1} HSN code`} value={row.hsn} onChange={setLine(row.uid, 'hsn')} /></td>
                            <td><input className={`f sm num ${row.qty === '' ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Qty" aria-label={`Row ${i + 1} quantity`} value={row.qty} onChange={setLine(row.uid, 'qty')} /></td>
                            <td>
                              <input className="f sm" list="po-units" placeholder="Unit" aria-label={`Row ${i + 1} unit`} value={row.uom} onChange={setLine(row.uid, 'uom')} />
                            </td>
                            <td>
                              <input className={`f sm num ${row.rate === '' ? 'unset-input' : ''}`} inputMode="decimal" placeholder="Rate" aria-label={`Row ${i + 1} rate`} value={row.rate} onChange={setLine(row.uid, 'rate')} />
                              {row.rateFrom && <div className="muted small rate-from" title={`Rate from ${row.rateFrom}`}>{row.rateFrom.startsWith('BOM') ? 'from BOM' : 'from vendor list'}</div>}
                            </td>
                            <td><input className="f sm num" inputMode="decimal" placeholder="0" aria-label={`Row ${i + 1} discount percent`} value={row.discPct} onChange={setLine(row.uid, 'discPct')} /></td>
                            <td>
                              <select className={`f sm ${row.gstPct === '' ? 'unset' : ''}`} aria-label={`Row ${i + 1} GST percent`} value={row.gstPct} onChange={setLine(row.uid, 'gstPct')}>
                                <option value="">GST…</option>
                                {[...new Set([...GST_RATES.map(String), ...(row.gstPct !== '' ? [row.gstPct] : [])])].map((g) => <option key={g} value={g}>{g}%</option>)}
                              </select>
                              {row.gstFrom && row.gstFrom !== 'user' && <div className="muted small rate-from">{row.gstFrom === 'list' ? 'from vendor list' : 'standard'}</div>}
                            </td>
                            <td className="r num strong">{formatINR(l.amount)}</td>
                            <td><button type="button" className="ib sm danger" aria-label={`Remove row ${i + 1}`} onClick={() => removeRow(row.uid)}><Icon name="close" size={16} /></button></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <datalist id="po-units">{UNITS.map((u) => <option key={u} value={u} />)}</datalist>
                </div>
              )}

              <div className="po-totals">
                <dl>
                  <div><dt>Amount before tax</dt><dd>{formatINR(totals.taxable)}</dd></div>
                  {totals.intra ? (
                    <>
                      <div><dt>CGST</dt><dd>{formatINR(totals.cgst)}</dd></div>
                      <div><dt>SGST</dt><dd>{formatINR(totals.sgst)}</dd></div>
                    </>
                  ) : (
                    <div><dt>IGST</dt><dd>{formatINR(totals.igst)}</dd></div>
                  )}
                  <div><dt>Round off</dt><dd>{formatINR(totals.roundOff)}</dd></div>
                  <div className="gt"><dt>Grand total</dt><dd>{formatINR(totals.grandTotal)}</dd></div>
                </dl>
                <p className="small muted">Rupees {totals.words.toLowerCase()}</p>
              </div>
            </section>

            <section className="panel po-card" aria-label="Terms">
              <div className="g3">
                <div>
                  <label className="lbl" htmlFor="po-pay">Payment terms (days)</label>
                  <input id="po-pay" className="f" placeholder="e.g. 30" value={po.paymentTerms} onChange={setField('paymentTerms')} />
                </div>
                <div className="span2">
                  <label className="lbl" htmlFor="po-remark">Remark</label>
                  <input id="po-remark" className="f" value={po.remark} onChange={setField('remark')} />
                </div>
                <div className="span3">
                  <label className="lbl" htmlFor="po-terms">Terms &amp; conditions</label>
                  <textarea id="po-terms" className="f ta" rows={2} value={po.terms} onChange={setField('terms')} />
                </div>
              </div>
            </section>
          </div>
        )}

        {step === 3 && (
          <div className="po-step po-preview">
            <div className="po-row center wrap">
              <div className="grow small">
                {saved && !changed
                  ? <span className="status final">Saved as PO {saved.poNo}</span>
                  : <span className="status draft">{saved ? 'Changes not saved yet' : 'Not saved yet'}</span>}
                <span className="muted"> &nbsp;Grand total {formatINR(totals.grandTotal)}, {plural(po.lines.length, 'row', 'rows')}</span>
              </div>
              <button type="button" className="btn" onClick={download}><Icon name="download" size={16} /> Download</button>
              <button type="button" className="btn" onClick={print}><Icon name="printer" size={16} /> Print</button>
              <button type="button" className="btn primary" onClick={save} disabled={saving || (saved && !changed)}>
                {saving ? 'Saving…' : saved && !changed ? 'Saved' : saved ? 'Save changes' : 'Save PO'}
              </button>
            </div>
            {(note || IS_DEMO) && (
              <p className={`print-note ${note?.kind || 'info'}`} role="status">
                {note ? note.text : 'In this demo, your browser may block Print. If it does, use Download, open the file and print from there.'}
              </p>
            )}
            <iframe ref={frameRef} className="po-frame" title="Purchase order preview" srcDoc={previewHtml} />
          </div>
        )}
      </div>

      <footer className="po-foot">
        {step > (hasBom ? 1 : 2) ? (
          <button type="button" className="btn" onClick={() => setStep(step - 1)}><Icon name="back" size={14} /> Back</button>
        ) : <span />}
        <span className="muted small">{step === 1 ? `${selected.size} selected` : step === 2 ? `Grand total ${formatINR(totals.grandTotal)}` : ''}</span>
        {step === 1 && <button type="button" className="btn primary" onClick={goToDetails}>Next: PO details</button>}
        {step === 2 && <button type="button" className="btn primary" onClick={goToPreview}>Next: preview</button>}
        {step === 3 && <button type="button" className="btn" onClick={close}>{saved && !changed ? 'Done' : 'Close'}</button>}
      </footer>

      {vendorForm && (
        <VendorFormDialog
          vendor={vendorForm.vendor}
          initial={vendorForm.initial}
          onClose={() => setVendorForm(null)}
          onSaved={async (doc) => {
            setVendorForm(null);
            const list = await loadVendors();
            applyVendorName(doc.name, list.some((v) => v._id === doc._id) ? list : [...list, doc]);
          }}
        />
      )}
    </dialog>
  );
}

/** Shows whether the PO vendor comes from the Vendor master, with Add / Edit shortcuts. */
function VendorStatus({ po, linked, notInMaster, onAdd, onEdit }) {
  if (linked) {
    return (
      <p className="vendor-link ok">
        <Icon name="vendors" size={14} /> Filled from Vendor master ({linked.code}).
        <button type="button" className="linkish small" onClick={onEdit}>Edit vendor details</button>
      </p>
    );
  }
  if (notInMaster) {
    return (
      <p className="vendor-link warn">
        “{po.vendor.name}” is not in the Vendor master yet.
        <button type="button" className="linkish small" onClick={onAdd}>Add it to Vendor master</button>
      </p>
    );
  }
  return null;
}
