import { create } from 'zustand';
import { newNode, newSubAssembly, newLine, cloneNode, fromApi } from '../lib/bom.js';

const empty = () => ({
  id: null,
  machineName: '',
  modelNo: '',
  projectDigits: '',
  revision: 0,
  status: 'draft',
  updatedAt: null,
  reorderOf: null, // set on a Reorder copy: { productMasterId, modelNo, revision, at }
  nodes: [],
  selected: { nodeUid: null, subUid: null },
  expanded: {}, // nodeUid → true when its details are shown (tree and Full BOM view)
  dirty: false
});

// Small helpers that return a new nodes array with one thing changed.
const mapNode = (nodes, nodeUid, fn) => nodes.map((n) => (n.uid === nodeUid ? fn(n) : n));
const mapSub = (node, subUid, fn) => ({ ...node, subAssemblies: node.subAssemblies.map((s) => (s.uid === subUid ? fn(s) : s)) });
const mapLines = (nodes, nodeUid, subUid, fn) =>
  mapNode(nodes, nodeUid, (n) => (subUid ? mapSub(n, subUid, (s) => ({ ...s, lines: fn(s.lines) })) : { ...n, lines: fn(n.lines) }));

export const useEditorStore = create((set, get) => {
  const edit = (fn) => set((s) => ({ ...fn(s), dirty: true }));

  return {
    ...empty(),

    startNew: () => set(empty()),

    loadDoc: (doc) => {
      const data = fromApi(doc);
      const keep = get().selected;
      const stillThere = data.nodes.find((n) => n.uid === keep.nodeUid);
      set({
        ...data,
        expanded: get().id === data.id ? get().expanded : {},
        dirty: false,
        selected: stillThere ? keep : { nodeUid: data.nodes[0]?.uid ?? null, subUid: null }
      });
    },

    setField: (field, value) => edit(() => ({ [field]: value })),

    // Opening a sub-item also opens its parent in the tree, so it stays visible.
    select: (nodeUid, subUid = null) =>
      set((s) => ({
        selected: { nodeUid, subUid },
        expanded: subUid ? { ...s.expanded, [nodeUid]: true } : s.expanded
      })),

    // Expanding is a view setting, so it does not mark the BOM as changed.
    toggleExpanded: (nodeUid) => set((s) => ({ expanded: { ...s.expanded, [nodeUid]: !s.expanded[nodeUid] } })),
    setAllExpanded: (open) =>
      set((s) => ({ expanded: open ? Object.fromEntries(s.nodes.map((n) => [n.uid, true])) : {} })),

    addNode: (overrides) => {
      const node = newNode(overrides);
      edit((s) => ({ nodes: [...s.nodes, node], selected: { nodeUid: node.uid, subUid: null } }));
    },

    updateNode: (nodeUid, patch) => edit((s) => ({ nodes: mapNode(s.nodes, nodeUid, (n) => ({ ...n, ...patch })) })),

    removeNode: (nodeUid) =>
      edit((s) => {
        const i = s.nodes.findIndex((n) => n.uid === nodeUid);
        const nodes = s.nodes.filter((n) => n.uid !== nodeUid);
        const next = nodes[Math.min(i, nodes.length - 1)];
        return { nodes, selected: { nodeUid: next?.uid ?? null, subUid: null } };
      }),

    duplicateNode: (nodeUid) =>
      edit((s) => {
        const i = s.nodes.findIndex((n) => n.uid === nodeUid);
        if (i < 0) return {};
        const copy = cloneNode(s.nodes[i]);
        const nodes = [...s.nodes];
        nodes.splice(i + 1, 0, copy);
        return { nodes, selected: { nodeUid: copy.uid, subUid: null } };
      }),

    addSub: (nodeUid) => {
      const sub = newSubAssembly();
      edit((s) => ({
        nodes: mapNode(s.nodes, nodeUid, (n) => ({ ...n, subAssemblies: [...n.subAssemblies, sub] })),
        selected: { nodeUid, subUid: sub.uid },
        expanded: { ...s.expanded, [nodeUid]: true }
      }));
    },

    updateSub: (nodeUid, subUid, patch) =>
      edit((s) => ({ nodes: mapNode(s.nodes, nodeUid, (n) => mapSub(n, subUid, (x) => ({ ...x, ...patch }))) })),

    removeSub: (nodeUid, subUid) =>
      edit((s) => ({
        nodes: mapNode(s.nodes, nodeUid, (n) => ({ ...n, subAssemblies: n.subAssemblies.filter((x) => x.uid !== subUid) })),
        selected: { nodeUid, subUid: null }
      })),

    addLine: (nodeUid, subUid = null) => edit((s) => ({ nodes: mapLines(s.nodes, nodeUid, subUid, (ls) => [...ls, newLine()]) })),

    updateLine: (nodeUid, subUid, lineUid, patch) =>
      edit((s) => ({ nodes: mapLines(s.nodes, nodeUid, subUid, (ls) => ls.map((l) => (l.uid === lineUid ? { ...l, ...patch } : l))) })),

    removeLine: (nodeUid, subUid, lineUid) =>
      edit((s) => ({ nodes: mapLines(s.nodes, nodeUid, subUid, (ls) => ls.filter((l) => l.uid !== lineUid)) }))
  };
});
