// Browser-only stand-in for the API, used by `npm run build:demo`.
// It follows the same rules as the server (drafts, final checks, locking,
// revisions) and keeps data in this browser's localStorage.

import { ApiError } from './http.js';
import { bomTotals } from '@shared/cost.js';
import { finalIssues } from '@shared/validation.js';
import { PROJECT_ID_PATTERN } from '@shared/constants.js';
import { buildLbsl80Nodes, SAMPLE_MACHINE, DEFAULT_LOOKUPS } from '@shared/sampleBom.js';
import { uid } from '../lib/bom.js';
import { computePo, nextPoNumber } from '@shared/po.js';
import { latestEntry, priceStats, vendorPurchaseSummary } from '@shared/priceHistory.js';
import { resolveState } from '@shared/gstStates.js';
import { buildReorderDraft, buildReorderDraftFromBom, checkReorderDraft, posFromDraft, derivePosFromMachine, nextReorderModelNo } from '@shared/reorder.js';

const KEY = 'laxmi-bom-demo-items-v1'; // separate from the original Version 2 demo
let memory = null; // used if localStorage is blocked

const now = () => new Date().toISOString();
const clone = (v) => JSON.parse(JSON.stringify(v));
const fail = (status, message, extra = {}) => {
  throw new ApiError(status, { message, ...extra });
};

function seedDocs() {
  const doc = {
    _id: 'pm-lbsl-80',
    ...SAMPLE_MACHINE,
    projectId: null,
    revision: 0,
    status: 'draft',
    previousRevision: null,
    finalizedAt: null,
    nodes: buildLbsl80Nodes(uid),
    createdAt: now(),
    updatedAt: now()
  };
  doc.totals = bomTotals(doc.nodes);
  return [doc];
}

function read() {
  if (memory) return memory;
  try {
    const raw = localStorage.getItem(KEY);
    memory = raw ? JSON.parse(raw) : seedDocs();
  } catch {
    memory = seedDocs();
  }
  return memory;
}

function write(docs) {
  memory = docs;
  try {
    localStorage.setItem(KEY, JSON.stringify(docs));
  } catch {
    /* storage full or blocked: keep working in memory */
  }
}

function check(payload) {
  if (!String(payload.modelNo || '').trim()) fail(400, 'Some fields are not valid.', { issues: [{ path: 'modelNo', message: 'Model no is required' }] });
  if (payload.projectId && !PROJECT_ID_PATTERN.test(payload.projectId)) {
    fail(400, 'Some fields are not valid.', { issues: [{ path: 'projectId', message: 'Project ID must look like PRJ-0000' }] });
  }
  if (payload.status === 'final') {
    const issues = finalIssues(payload);
    if (issues.length) fail(422, 'Fix these items before saving as final, or save as a draft.', { issues });
  }
}

function stamp(doc, payload) {
  const next = { ...doc, ...clone(payload), modelNo: payload.modelNo.trim(), updatedAt: now() };
  next.totals = bomTotals(next.nodes);
  if (next.status === 'final' && !next.finalizedAt) next.finalizedAt = now();
  return next;
}

const tick = () => new Promise((r) => setTimeout(r, 120));

export const demoProductMastersApi = {
  async list({ q, status } = {}) {
    await tick();
    const needle = (q || '').trim().toLowerCase();
    const items = read()
      .filter((d) => !status || d.status === status)
      .filter((d) => !needle || [d.modelNo, d.machineName, d.projectId].some((v) => String(v || '').toLowerCase().includes(needle)))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(({ nodes, ...summary }) => summary);
    return { items: clone(items) };
  },

  async get(id) {
    await tick();
    const doc = read().find((d) => d._id === id);
    if (!doc) fail(404, 'Product master not found.');
    return clone(doc);
  },

  async create(payload) {
    await tick();
    check(payload);
    const docs = read();
    const existing = docs.find((d) => d.modelNo === payload.modelNo.trim());
    if (existing) {
      fail(409, `A BOM for model ${existing.modelNo} already exists. Open it and create a new revision instead.`, { existingId: existing._id });
    }
    const doc = stamp({ _id: `pm-${uid()}`, revision: 0, previousRevision: null, finalizedAt: null, createdAt: now() }, payload);
    write([...docs, doc]);
    return clone(doc);
  },

  async update(id, payload) {
    await tick();
    const docs = read();
    const doc = docs.find((d) => d._id === id);
    if (!doc) fail(404, 'Product master not found.');
    if (doc.status === 'final') fail(409, `R${doc.revision} is final and locked. Create a new revision to change it.`, { code: 'FINAL_LOCKED' });
    check(payload);
    const clash = docs.find((d) => d._id !== id && d.modelNo === payload.modelNo.trim());
    if (clash && clash.modelNo !== doc.modelNo) fail(409, `Model no ${clash.modelNo} is already used by another BOM.`);
    const next = stamp(doc, payload);
    write(docs.map((d) => (d._id === id ? next : d)));
    return clone(next);
  },

  async remove(id) {
    await tick();
    const docs = read();
    const doc = docs.find((d) => d._id === id);
    if (!doc) fail(404, 'Product master not found.');
    if (doc.status === 'final') fail(409, 'Final BOMs cannot be deleted.');
    write(docs.filter((d) => d._id !== id));
    return null;
  },

  /** Reorder: a full, editable copy of the machine as a NEW Product master ("LBSL 80-RO1"). Nothing else changes. */
  async reorder(id) {
    await tick();
    const docs = read();
    const source = docs.find((d) => d._id === id);
    if (!source) fail(404, 'Product master not found.');
    const doc = {
      ...clone(source), _id: `pm-${uid()}`, modelNo: nextReorderModelNo(source.modelNo, docs.map((d) => d.modelNo)), projectId: null,
      revision: 0, status: 'draft', previousRevision: null, finalizedAt: null, createdAt: now(), updatedAt: now(),
      reorderOf: { productMasterId: source._id, modelNo: source.modelNo, revision: source.revision, at: now() }
    };
    write([...docs, doc]);
    return clone(doc);
  },

  async createRevision(id) {
    await tick();
    const docs = read();
    const source = docs.find((d) => d._id === id);
    if (!source) fail(404, 'Product master not found.');
    const draft = docs.find((d) => d.modelNo === source.modelNo && d.status === 'draft');
    if (draft) fail(409, `Model ${source.modelNo} already has a draft revision. Finish or delete it first.`, { existingId: draft._id });
    const latest = Math.max(...docs.filter((d) => d.modelNo === source.modelNo).map((d) => d.revision));
    const doc = {
      ...clone(source),
      _id: `pm-${uid()}`,
      status: 'draft',
      revision: latest + 1,
      previousRevision: source._id,
      finalizedAt: null,
      createdAt: now(),
      updatedAt: now()
    };
    write([...docs, doc]);
    return clone(doc);
  },

  /** Demo only: wipe local data and reload the LBSL 80 sample. */
  reset() {
    write(seedDocs());
  }
};

export const demoLookupsApi = {
  async get() {
    const docs = read();
    const out = { materials: [], parts: [], vendors: [], processes: [] };
    for (const d of docs) {
      for (const n of d.nodes) {
        out.parts.push(n.name);
        out.vendors.push(n.vendor);
        for (const s of n.subAssemblies || []) out.parts.push(s.name);
        for (const l of [...n.lines, ...(n.subAssemblies || []).flatMap((s) => s.lines)]) {
          out.materials.push(l.material);
          out.vendors.push(l.vendor);
          out.processes.push(l.process);
        }
      }
    }
    const merge = (a, b) => [...new Set([...a, ...b].map((v) => String(v || '').trim()).filter(Boolean))].sort((x, y) => x.localeCompare(y));
    return {
      materials: merge(DEFAULT_LOOKUPS.materials, out.materials),
      parts: merge(DEFAULT_LOOKUPS.parts, out.parts),
      vendors: merge(readVendors().filter((v) => v.status !== 'inactive').map((v) => v.name), out.vendors),
      processes: merge(DEFAULT_LOOKUPS.processes, out.processes)
    };
  }
};

// ---------- Purchase orders (demo) ----------

const PO_KEY = 'laxmi-po-demo-v1';
let poMemory = null;

function seedPos() {
  const line = (description, qty, uom, rate, vendorMaterialId) => ({ uid: uid(), description, hsn: '', qty, uom, rate, discPct: null, gstPct: 18, vendorMaterialId, source: {} }); // as printed on PO 0085
  const po = {
    _id: 'po-0085',
    poNo: '0085',
    date: '2026-04-24',
    refNo: 'EKTA RR',
    refDate: '',
    kindAttn: '',
    vendorId: 'vendor-v0001',
    vendor: {
      name: 'VISHWAKARMA DIES & TOOLS INDUSTRIES',
      address: 'PLOT NO 5/34, PHASE-1, OPP. MARUTI\nESTATE, GIDC, VATVA, AHMEDABAD.',
      state: 'GUJARAT',
      stateCode: '24',
      gstin: ''
    },
    productMaster: null,
    modelNo: '',
    machines: 1,
    lines: [
      line('SPROKET 17 T X 24 HOLE X 1/4 KEYWAY', 2, 'NOS', 575, 'vm-85-1'),
      line('SPROKET 17T X 24 HOLE', 2, 'NOS', 550, 'vm-85-2'),
      line('GREEN STRIP 1250 X 25 X 12MM 3MM SLOT', 3, 'NOS', 425, 'vm-85-3'),
      line('BELT SS 304 3.5', 16, 'FT', 415, 'vm-85-4'),
      line('RETURN ROLLER', 4, 'NOS', 100, 'vm-85-5'),
      line('KNOB', 25, 'NOS', 108, 'vm-85-6')
    ],
    paymentTerms: '',
    remark: '',
    terms: '',
    createdAt: '2026-04-24T10:00:00.000Z',
    updatedAt: '2026-04-24T10:00:00.000Z'
  };
  return [withPoTotals(po)];
}

function withPoTotals(po) {
  const t = computePo(po);
  return { ...po, totals: { totalQty: t.totalQty, taxable: t.taxable, cgst: t.cgst, sgst: t.sgst, igst: t.igst, roundOff: t.roundOff, grandTotal: t.grandTotal } };
}

function readPos() {
  if (poMemory) return poMemory;
  try {
    const raw = localStorage.getItem(PO_KEY);
    poMemory = raw ? JSON.parse(raw) : seedPos();
  } catch {
    poMemory = seedPos();
  }
  return poMemory;
}

function writePos(list) {
  poMemory = list;
  try {
    localStorage.setItem(PO_KEY, JSON.stringify(list));
  } catch {
    /* keep in memory */
  }
}

function checkPo(po) {
  const issues = [];
  if (!/^\d{4}-\d{2}-\d{2}$/.test(po.date || '')) issues.push({ path: 'date', message: 'PO date is required' });
  if (!String(po.vendor?.name || '').trim()) issues.push({ path: 'vendor.name', message: 'Vendor name is required' });
  if (!resolveState(po.vendor || {}).stateCode) issues.push({ path: 'vendor.state', message: 'Choose the vendor’s state' });
  if (!po.lines?.length) issues.push({ path: 'lines', message: 'Add at least one row' });
  (po.lines || []).forEach((l, i) => {
    if (!String(l.description || '').trim()) issues.push({ path: `lines.${i}`, message: `Row ${i + 1} needs a description` });
    if (l.qty === null || l.qty === '' || !(Number(l.qty) > 0)) issues.push({ path: `lines.${i}`, message: `Row ${i + 1}: quantity is required` });
    if (l.rate === null || l.rate === '' || l.rate === undefined) issues.push({ path: `lines.${i}`, message: `Row ${i + 1}: rate is required` });
    if (l.gstPct === null || l.gstPct === '' || l.gstPct === undefined) issues.push({ path: `lines.${i}`, message: `Row ${i + 1}: GST % is required` });
  });
  if (issues.length) fail(400, 'Some fields are not valid.', { issues });
}

export const demoPurchaseOrdersApi = {
  async list({ q } = {}) {
    await tick();
    const needle = (q || '').trim().toLowerCase();
    const items = readPos()
      .filter((p) => !needle || [p.poNo, p.vendor?.name, p.modelNo].some((v) => String(v || '').toLowerCase().includes(needle)))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(({ lines, ...summary }) => ({ ...summary, lineCount: lines.length }));
    return { items: clone(items) };
  },
  async get(id) {
    await tick();
    const po = readPos().find((p) => p._id === id);
    if (!po) fail(404, 'Purchase order not found.');
    return clone(po);
  },
  async nextNumber() {
    return { poNo: nextPoNumber(readPos().map((p) => p.poNo)) };
  },
  async create(payload) {
    await tick();
    checkPo(payload);
    const list = readPos();
    const poNo = String(payload.poNo || '').trim() || nextPoNumber(list.map((p) => p.poNo));
    if (list.some((p) => p.poNo === poNo)) {
      fail(409, `PO No ${poNo} is already used. Leave it blank to get the next number.`, { nextPoNo: nextPoNumber(list.map((p) => p.poNo)) });
    }
    const vendor = { ...payload.vendor, ...(() => { const r = resolveState(payload.vendor); return { state: r.state, stateCode: r.stateCode }; })() };
    const po = withPoTotals({ ...clone(payload), vendor, poNo, _id: `po-${uid()}`, createdAt: now(), updatedAt: now() });
    writePos([...list, po]);
    syncDemoPriceHistory(po);
    return clone(po);
  },
  async update(id, payload) {
    await tick();
    checkPo(payload);
    const list = readPos();
    const old = list.find((p) => p._id === id);
    if (!old) fail(404, 'Purchase order not found.');
    const poNo = String(payload.poNo || '').trim() || old.poNo;
    if (list.some((p) => p._id !== id && p.poNo === poNo)) fail(409, `PO No ${poNo} is already used.`);
    const vendor = { ...payload.vendor, ...(() => { const r = resolveState(payload.vendor); return { state: r.state, stateCode: r.stateCode }; })() };
    const po = withPoTotals({ ...old, ...clone(payload), vendor, poNo, updatedAt: now() });
    writePos(list.map((p) => (p._id === id ? po : p)));
    syncDemoPriceHistory(po);
    return clone(po);
  },
  async remove(id) {
    await tick();
    writePos(readPos().filter((p) => p._id !== id));
    writeMaterials(readMaterials().map((m) => ({ ...m, history: m.history.filter((h) => h.poId !== id) })));
    return null;
  },
  reset() {
    writePos(seedPos());
  }
};

// ---------- Vendor master (demo) ----------
const VENDOR_KEY = 'laxmi-vendors-demo-v1';
let vendorMemory = null;

function seedVendors() {
  // Only details found in the client's documents. Everything else is left blank.
  return [
    {
      _id: 'vendor-v0001', code: 'V0001', name: 'VISHWAKARMA DIES & TOOLS INDUSTRIES', contactPerson: '', email: '', mobile: '',
      address: 'PLOT NO 5/34, PHASE-1, OPP. MARUTI\nESTATE, GIDC, VATVA, AHMEDABAD.', state: 'GUJARAT', stateCode: '24', gstin: '',
      category: '', materialsSupplied: '', preferred: '', leadTimeDays: null, paymentTerms: '', status: '', remarks: 'From PO 0085',
      createdAt: '2026-04-24T10:00:00.000Z', updatedAt: '2026-04-24T10:00:00.000Z'
    },
    {
      _id: 'vendor-v0002', code: 'V0002', name: 'Gracefull', contactPerson: '', email: '', mobile: '', address: '', state: '', stateCode: '',
      gstin: '', category: '', materialsSupplied: '', preferred: '', leadTimeDays: null, paymentTerms: '', status: '',
      remarks: 'From the LBSL 80 BOM', createdAt: '2026-04-24T10:00:00.000Z', updatedAt: '2026-04-24T10:00:00.000Z'
    }
  ];
}

function readVendors() {
  if (vendorMemory) return vendorMemory;
  try {
    const raw = localStorage.getItem(VENDOR_KEY);
    vendorMemory = raw ? JSON.parse(raw) : seedVendors();
  } catch {
    vendorMemory = seedVendors();
  }
  return vendorMemory;
}

function writeVendors(list) {
  vendorMemory = list;
  try {
    localStorage.setItem(VENDOR_KEY, JSON.stringify(list));
  } catch {
    /* keep in memory */
  }
}

const nextVendorCode = (list) => `V${nextPoNumber(list.map((v) => v.code))}`;

function checkVendor(v, list, id) {
  const issues = [];
  if (!String(v.name || '').trim()) issues.push({ path: 'name', message: 'Vendor name is required' });
  if (v.status !== 'active' && v.status !== 'inactive') issues.push({ path: 'status', message: 'Choose a status: Active or Inactive' });
  if (v.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) issues.push({ path: 'email', message: 'Enter a valid email' });
  const st = resolveState(v);
  if (st.gstinMismatch) issues.push({ path: 'gstin', message: `GSTIN starts with ${st.gstinMismatch.code} (${st.gstinMismatch.name}) but the state chosen is ${st.state}` });
  if (v.gstin && !/^[0-9A-Z]{15}$/.test(String(v.gstin).toUpperCase())) issues.push({ path: 'gstin', message: 'GSTIN has 15 letters and digits' });
  if (v.mobile && !/^[0-9+\-\s]*$/.test(v.mobile)) issues.push({ path: 'mobile', message: 'Mobile can only have digits, spaces, + and -' });
  if (v.leadTimeDays !== null && v.leadTimeDays !== '' && v.leadTimeDays !== undefined && !(Number.isInteger(Number(v.leadTimeDays)) && Number(v.leadTimeDays) >= 0)) {
    issues.push({ path: 'leadTimeDays', message: 'Lead time is a whole number of days' });
  }
  if (issues.length) fail(400, 'Some fields are not valid.', { issues });
  const same = list.find((x) => x._id !== id && x.name.trim().toLowerCase() === v.name.trim().toLowerCase());
  if (same) fail(409, `A vendor called “${same.name}” already exists (${same.code}).`, { existingId: same._id });
  if (v.code && list.some((x) => x._id !== id && x.code === v.code)) fail(409, `Vendor code ${v.code} is already used.`);
}

const tidyVendor = (v) => ({
  ...v,
  ...(() => { const r = resolveState(v); return { state: r.state, stateCode: r.stateCode }; })(),
  name: String(v.name || '').trim(),
  gstin: String(v.gstin || '').trim().toUpperCase(),
  leadTimeDays: v.leadTimeDays === '' || v.leadTimeDays === null || v.leadTimeDays === undefined ? null : Number(v.leadTimeDays)
});

export const demoVendorsApi = {
  async list({ q, status } = {}) {
    await tick();
    const needle = (q || '').trim().toLowerCase();
    const items = readVendors()
      .filter((v) => !status || v.status === status)
      .filter((v) => !needle || [v.name, v.code, v.contactPerson, v.gstin, v.materialsSupplied].some((x) => String(x || '').toLowerCase().includes(needle)))
      .sort((a, b) => a.name.localeCompare(b.name));
    return { items: clone(items) };
  },
  async nextCode() {
    return { code: nextVendorCode(readVendors()) };
  },
  async get(id) {
    await tick();
    const v = readVendors().find((x) => x._id === id);
    if (!v) fail(404, 'Vendor not found.');
    return clone(v);
  },
  async create(payload) {
    await tick();
    const list = readVendors();
    const v = tidyVendor(payload);
    checkVendor(v, list, undefined);
    const doc = { ...v, code: v.code || nextVendorCode(list), _id: `vendor-${uid()}`, createdAt: now(), updatedAt: now() };
    writeVendors([...list, doc]);
    return clone(doc);
  },
  async update(id, payload) {
    await tick();
    const list = readVendors();
    const old = list.find((x) => x._id === id);
    if (!old) fail(404, 'Vendor not found.');
    const v = tidyVendor(payload);
    checkVendor(v, list, id);
    const doc = { ...old, ...v, code: v.code || old.code, updatedAt: now() };
    writeVendors(list.map((x) => (x._id === id ? doc : x)));
    return clone(doc);
  },
  async remove(id) {
    await tick();
    const v = readVendors().find((x) => x._id === id);
    if (!v) fail(404, 'Vendor not found.');
    const used = readPos().filter((p) => p.vendorId === id).length;
    if (used) fail(409, `${v.name} is on ${used} purchase order(s), so it cannot be deleted. Set its status to Inactive instead.`);
    writeVendors(readVendors().filter((x) => x._id !== id));
    writeMaterials(readMaterials().filter((m) => m.vendorId !== id));
    return null;
  },
  async purchases(id) {
    await tick();
    if (!readVendors().some((x) => x._id === id)) fail(404, 'Vendor not found.');
    return clone(vendorPurchaseSummary(readPos().filter((p) => p.vendorId === id)));
  },
  reset() {
    writeVendors(seedVendors());
  }
};

// ---------- Vendor materials and price history (demo) ----------
const MAT_KEY = 'laxmi-vendor-materials-demo-v1';
let matMemory = null;

function seedMaterials() {
  // Vishwakarma's list comes from PO 0085: material, unit and the price paid on 24-04-26.
  // Status, MOQ, lead time and so on are not in the documents, so they stay blank.
  const fromPo = (n, material, unit, rate, qty) => ({
    _id: `vm-85-${n}`, vendorId: 'vendor-v0001', material, specification: '', unit, rate: null, gstPct: 18, moq: null, leadTimeDays: null, // GST 18% as on PO 0085
    preferred: '', status: '', remarks: '',
    history: [{ at: '2026-04-24', rate, source: 'po', poId: 'po-0085', poNo: '0085', qty, note: '', recordedAt: '2026-04-24T10:00:00.000Z' }],
    createdAt: '2026-04-24T10:00:00.000Z', updatedAt: '2026-04-24T10:00:00.000Z'
  });
  return [
    fromPo(1, 'SPROKET 17 T X 24 HOLE X 1/4 KEYWAY', 'NOS', 575, 2),
    fromPo(2, 'SPROKET 17T X 24 HOLE', 'NOS', 550, 2),
    fromPo(3, 'GREEN STRIP 1250 X 25 X 12MM 3MM SLOT', 'NOS', 425, 3),
    fromPo(4, 'BELT SS 304 3.5', 'FT', 415, 16),
    fromPo(5, 'RETURN ROLLER', 'NOS', 100, 4),
    fromPo(6, 'KNOB', 'NOS', 108, 25),
    {
      _id: 'vm-gr-1', vendorId: 'vendor-v0002', material: '3/4" leveling bolt', specification: '', unit: '', rate: null, gstPct: null, moq: null,
      leadTimeDays: null, preferred: '', status: '', remarks: 'From the LBSL 80 BOM', history: [],
      createdAt: '2026-04-24T10:00:00.000Z', updatedAt: '2026-04-24T10:00:00.000Z'
    }
  ];
}

function readMaterials() {
  if (matMemory) return matMemory;
  try {
    const raw = localStorage.getItem(MAT_KEY);
    matMemory = raw ? JSON.parse(raw) : seedMaterials();
  } catch {
    matMemory = seedMaterials();
  }
  return matMemory;
}

function writeMaterials(list) {
  matMemory = list;
  try {
    localStorage.setItem(MAT_KEY, JSON.stringify(list));
  } catch {
    /* keep in memory */
  }
}

function syncDemoPriceHistory(po) {
  const entriesFor = (mid) =>
    (po.lines || []).filter((l) => l.vendorMaterialId === mid)
      .map((l) => ({ at: po.date, rate: Number(l.rate), source: 'po', poId: po._id, poNo: po.poNo, qty: Number(l.qty), note: '', recordedAt: now() }));
  writeMaterials(readMaterials().map((m) => {
    const kept = m.history.filter((h) => h.poId !== po._id);
    const added = m.vendorId === po.vendorId ? entriesFor(m._id) : [];
    return kept.length === m.history.length && !added.length ? m : { ...m, history: [...kept, ...added] };
  }));
}

const withCurrent = (m) => ({ ...m, current: latestEntry(m.history) });
const todayIso = () => new Date().toISOString().slice(0, 10);

function checkMaterial(v, list, vendorId, id) {
  const issues = [];
  if (!String(v.material || '').trim()) issues.push({ path: 'material', message: 'Material name is required' });
  if (v.status !== 'active' && v.status !== 'inactive') issues.push({ path: 'status', message: 'Choose a status: Active or Inactive' });
  if (v.gstPct !== null && v.gstPct !== '' && v.gstPct !== undefined && Number(v.gstPct) > 100) issues.push({ path: 'gstPct', message: 'GST % must be 100 or less' });
  for (const [k, label] of [['rate', 'Rate'], ['gstPct', 'GST %'], ['moq', 'MOQ'], ['leadTimeDays', 'Lead time']]) {
    if (v[k] !== null && v[k] !== '' && v[k] !== undefined && !(Number(v[k]) >= 0)) issues.push({ path: k, message: `${label} must be a number, 0 or more` });
  }
  if (issues.length) fail(400, 'Some fields are not valid.', { issues });
  const clash = list.find((m) => m._id !== id && m.vendorId === vendorId
    && m.material.trim().toLowerCase() === v.material.trim().toLowerCase() && (m.specification || '') === (v.specification || ''));
  if (clash) fail(409, `${clash.material}${clash.specification ? ` (${clash.specification})` : ''} is already in this vendor's list.`);
}

const numOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v));
const tidyMaterial = (v) => ({
  material: String(v.material || '').trim(), specification: String(v.specification || '').trim(), unit: String(v.unit || '').trim(),
  rate: numOrNull(v.rate), gstPct: numOrNull(v.gstPct), moq: numOrNull(v.moq), leadTimeDays: numOrNull(v.leadTimeDays), preferred: v.preferred || '', status: v.status || '',
  remarks: String(v.remarks || '')
});

export const demoVendorMaterialsApi = {
  async list(vendorId) {
    await tick();
    return { items: clone(readMaterials().filter((m) => m.vendorId === vendorId).sort((a, b) => a.material.localeCompare(b.material)).map(withCurrent)) };
  },
  async create(vendorId, payload) {
    await tick();
    const list = readMaterials();
    const v = tidyMaterial(payload);
    checkMaterial(v, list, vendorId, undefined);
    const history = v.rate === null ? [] : [{ at: payload.rateDate || todayIso(), rate: v.rate, source: 'manual', note: 'First rate entered', recordedAt: now() }];
    const doc = { ...v, _id: `vm-${uid()}`, vendorId, history, createdAt: now(), updatedAt: now() };
    writeMaterials([...list, doc]);
    return clone(withCurrent(doc));
  },
  async update(mid, payload) {
    await tick();
    const list = readMaterials();
    const old = list.find((m) => m._id === mid);
    if (!old) fail(404, 'Material not found.');
    const v = tidyMaterial(payload);
    checkMaterial(v, list, old.vendorId, mid);
    const history = v.rate !== null && v.rate !== old.rate
      ? [...old.history, { at: payload.rateDate || todayIso(), rate: v.rate, source: 'manual', note: old.history.length ? 'Rate updated' : 'First rate entered', recordedAt: now() }]
      : old.history;
    const doc = { ...old, ...v, history, updatedAt: now() };
    writeMaterials(list.map((m) => (m._id === mid ? doc : m)));
    return clone(withCurrent(doc));
  },
  async remove(mid) {
    await tick();
    const m = readMaterials().find((x) => x._id === mid);
    if (!m) fail(404, 'Material not found.');
    const poCount = new Set(m.history.filter((h) => h.source === 'po').map((h) => h.poId)).size;
    if (poCount) fail(409, `${m.material} is on ${poCount} purchase order(s), so its price history is kept. Set it to Inactive instead.`);
    writeMaterials(readMaterials().filter((x) => x._id !== mid));
    return null;
  },
  async history(mid) {
    await tick();
    const all = readMaterials();
    const m = all.find((x) => x._id === mid);
    if (!m) fail(404, 'Material not found.');
    const vendors = readVendors();
    const others = all.filter((x) => x._id !== mid && x.material.trim().toLowerCase() === m.material.trim().toLowerCase());
    return clone({
      material: withCurrent(m),
      stats: priceStats(m.history),
      otherVendors: others.map((o) => {
        const v = vendors.find((x) => x._id === o.vendorId);
        return { _id: o._id, vendorId: o.vendorId, vendorName: v?.name || '', vendorCode: v?.code || '', specification: o.specification, unit: o.unit, status: o.status, current: latestEntry(o.history) };
      })
    });
  },
  reset() {
    writeMaterials(seedMaterials());
  }
};

// ---------- Smart Reorder: orders and reorder drafts (demo) ----------
const RD_KEY = 'laxmi-reorders-demo-v1';
const ORD_KEY = 'laxmi-orders-demo-v1';
const mem = { rd: null, ord: null };
const readList = (key, slot) => {
  if (mem[slot]) return mem[slot];
  try {
    const raw = localStorage.getItem(key);
    mem[slot] = raw ? JSON.parse(raw) : [];
  } catch {
    mem[slot] = [];
  }
  return mem[slot];
};
const writeList = (key, slot, list) => {
  mem[slot] = list;
  try {
    localStorage.setItem(key, JSON.stringify(list));
  } catch {
    /* keep in memory */
  }
};
const readDrafts = () => readList(RD_KEY, 'rd');
const writeDrafts = (l) => writeList(RD_KEY, 'rd', l);
const readOrders = () => readList(ORD_KEY, 'ord');
const writeOrders = (l) => writeList(ORD_KEY, 'ord', l);
const localToday = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const nextCode = (list, field, prefix) => `${prefix}${nextPoNumber(list.map((x) => String(x[field]).replace(prefix, '')))}`;
const auditEntry = (event, detail = {}) => ({ at: now(), event, detail });

export const demoReordersApi = {
  /** Prepares a draft. Creates NO purchase order. */
  async create({ orderId, poIds, productMasterId, include, copyMachine } = {}) {
    await tick();
    if (productMasterId) {
      // Reorder a whole machine from its Product master: one prepared PO per supplier.
      const pm = read().find((d) => d._id === productMasterId);
      if (!pm) fail(404, 'Product master not found.');
      const ids = [pm._id, pm.reorderOf?.productMasterId].filter(Boolean);
      const models = [pm.modelNo, pm.reorderOf?.modelNo].filter(Boolean);
      const pastPos = readPos().filter((p) => ids.includes(p.productMaster) || models.includes(p.modelNo));
      const draft = buildReorderDraftFromBom({ productMaster: pm, vendors: readVendors(), materials: readMaterials(), pastPos, include, uid, copyMachine: copyMachine !== false });
      if (!draft.pos.length) fail(400, 'Nothing to order with these choices. Include more kinds of rows, or complete the BOM first.');
      const list = readDrafts();
      const doc = {
        ...clone(draft), _id: `rd-${uid()}`, draftNo: nextCode(list, 'draftNo', 'RD-'), version: 1, generationKey: uid(),
        audit: [auditEntry('created', { from: `Product master ${pm.modelNo} R${pm.revision ?? 0}`, rows: draft.source.rowCount })],
        createdAt: now(), updatedAt: now()
      };
      writeDrafts([...list, doc]);
      return clone(doc);
    }
    let order = null;
    let sourcePos;
    if (orderId) {
      order = readOrders().find((o) => o._id === orderId);
      if (!order) fail(404, 'Order not found.');
      sourcePos = readPos().filter((p) => order.poIds.includes(p._id));
    } else if (poIds?.length) {
      sourcePos = readPos().filter((p) => poIds.includes(p._id));
    } else {
      fail(400, 'Choose an order or at least one purchase order to reorder.');
    }
    if (!sourcePos.length) fail(404, 'The purchase orders to reorder were not found.');
    sourcePos = [...sourcePos].sort((a, b) => a.poNo.localeCompare(b.poNo));
    const draft = buildReorderDraft({ sourcePos, sourceOrder: order, vendors: readVendors(), materials: readMaterials(), uid });
    const list = readDrafts();
    const doc = {
      ...clone(draft), _id: `rd-${uid()}`, draftNo: nextCode(list, 'draftNo', 'RD-'), version: 1, generationKey: uid(),
      audit: [auditEntry('created', { from: order ? `Order ${order.orderNo}` : `PO ${draft.source.poNos.join(', ')}` })],
      createdAt: now(), updatedAt: now()
    };
    writeDrafts([...list, doc]);
    return clone(doc);
  },
  async list({ status } = {}) {
    await tick();
    const items = readDrafts().filter((d) => !status || d.status === status).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(({ pos, audit, ...rest }) => ({ ...rest, poCount: pos.filter((p) => !p.excluded).length, rowCount: pos.reduce((a, p) => a + p.lines.length, 0) }));
    return { items: clone(items) };
  },
  async get(id) {
    await tick();
    const d = readDrafts().find((x) => x._id === id);
    if (!d) fail(404, 'Reorder draft not found.');
    return clone(d);
  },
  async update(id, { version, poDate = '', projectId = '', customerRef = '', pos, change, machine, purchase, poMeta, saveAsNew } = {}) {
    const list = readDrafts();
    const d = list.find((x) => x._id === id);
    if (!d) fail(404, 'Reorder draft not found.');
    if (d.status !== 'draft') fail(409, `This draft is ${d.status} and can no longer be changed.`, { code: 'NOT_DRAFT' });
    if (d.version !== version) fail(409, 'Someone else changed this draft. Reload to see the latest version.', { code: 'STALE' });
    const machineFields = machine ? { machine: clone(machine), purchase: clone(purchase || {}), poMeta: clone(poMeta || {}), saveAsNew: clone(saveAsNew || { enabled: false, modelNo: '' }) } : {};
    const next = { ...d, poDate, projectId, customerRef, pos: clone(pos), ...machineFields, version: d.version + 1, updatedAt: now(),
      audit: change ? [...d.audit, auditEntry('edited', { change: String(change).slice(0, 300) })] : d.audit };
    writeDrafts(list.map((x) => (x._id === id ? next : x)));
    return clone(next);
  },
  async discard(id) {
    await tick();
    const list = readDrafts();
    const d = list.find((x) => x._id === id);
    if (!d || d.status !== 'draft') fail(409, 'Only an open draft can be discarded.');
    const next = { ...d, status: 'discarded', updatedAt: now(), audit: [...d.audit, auditEntry('discarded')] };
    writeDrafts(list.map((x) => (x._id === id ? next : x)));
    return clone(next);
  },
  /** The only place a reorder creates purchase orders. Runs once per draft. */
  async generate(id, { generationKey } = {}) {
    await tick();
    const list = readDrafts();
    const d = list.find((x) => x._id === id);
    if (!d) fail(404, 'Reorder draft not found.');
    if (generationKey !== d.generationKey) fail(400, 'This confirmation does not belong to this draft. Reload and try again.');
    if (d.status === 'generated') return { alreadyGenerated: true, draft: clone(d) };
    if (d.status !== 'draft') fail(409, `This draft is ${d.status}.`);
    const vendors = readVendors();
    // Machine reorder: the machine copy is the source of truth, so the POs are worked out from it again.
    if (d.machine) d.pos = derivePosFromMachine(d, vendors);
    const check = checkReorderDraft(d, { vendors, materials: readMaterials(), today: localToday() });
    const newModelNo = d.machine && d.saveAsNew?.enabled ? String(d.saveAsNew.modelNo || '').trim() : '';
    if (d.machine && d.saveAsNew?.enabled) {
      if (!newModelNo) check.blocks.push({ message: 'Enter the model no for the new Product master, or untick “Save as a new Product master”.' });
      else if (read().some((x) => x.modelNo === newModelNo)) check.blocks.push({ message: `Model no ${newModelNo} already exists. Choose another model no for the new Product master.` });
      check.ok = check.blocks.length === 0;
    }
    if (!check.ok) {
      writeDrafts(list.map((x) => (x._id === id ? { ...x, audit: [...x.audit, auditEntry('generation-stopped', { blocks: check.blocks.map((b) => b.message) })] } : x)));
      fail(409, 'Nothing was generated: please fix these first.', { code: 'CHECK_FAILED', issues: check.blocks });
    }
    let newPm = null;
    if (newModelNo) {
      // Save the machine copy as a new Product master (draft, revision 0).
      newPm = { _id: `pm-${uid()}`, machineName: d.machine.machineName, modelNo: newModelNo, projectId: null, revision: 0, status: 'draft',
        previousRevision: null, finalizedAt: null, nodes: clone(d.machine.nodes).map((n) => ({ ...n, kind: 'item' })), createdAt: now(), updatedAt: now() };
      newPm.totals = bomTotals(newPm.nodes);
      write([...read(), newPm]);
    }
    const orders = readOrders();
    const order = {
      _id: `ord-${uid()}`, orderNo: nextCode(orders, 'orderNo', 'ORD-'), date: d.poDate, modelNo: newPm ? newPm.modelNo : d.modelNo, productMaster: newPm ? newPm._id : d.productMaster,
      projectId: d.projectId, customerRef: d.customerRef, remarks: '', poIds: [], poNos: [],
      machine: d.machine ? { ...clone(d.machine), modelNo: newPm ? newPm.modelNo : d.machine.modelNo } : null,
      reorderedFrom: { orderId: d.source.orderId, orderNo: d.source.orderNo, poNos: d.source.poNos, draftId: d._id, draftNo: d.draftNo, modelNo: d.source.kind === 'bom' ? d.source.modelNo : '', reorderOfModelNo: d.source.reorderOfModelNo || '' },
      createdAt: now(), updatedAt: now()
    };
    let pos = readPos();
    for (const p of posFromDraft(d, { vendors }).map((x) => (newPm ? { ...x, productMaster: newPm._id, modelNo: newPm.modelNo } : x))) {
      const po = withPoTotals({ ...clone(p), poNo: nextPoNumber(pos.map((x) => x.poNo)), _id: `po-${uid()}`, orderId: order._id,
        reorder: { ...p.reorder, draftId: d._id, draftNo: d.draftNo }, createdAt: now(), updatedAt: now() });
      pos = [...pos, po];
      writePos(pos);
      syncDemoPriceHistory(po);
      order.poIds.push(po._id);
      order.poNos.push(po.poNo);
    }
    writeOrders([...orders, order]);
    const done = { ...d, status: 'generated', version: d.version + 1, updatedAt: now(),
      generated: { at: now(), orderId: order._id, orderNo: order.orderNo, poIds: order.poIds, poNos: order.poNos, productMasterId: newPm?._id || null, productMasterModelNo: newPm?.modelNo || '' },
      audit: [...d.audit, auditEntry('generated', { orderNo: order.orderNo, poNos: order.poNos })] };
    writeDrafts(readDrafts().map((x) => (x._id === id ? done : x)));
    return { draft: clone(done), order: clone(order) };
  },
  reset() {
    writeDrafts([]);
    writeOrders([]);
  }
};

export const demoOrdersApi = {
  async list() {
    await tick();
    const pos = readPos();
    return { items: clone(readOrders().map((o) => ({ ...o, total: o.poIds.reduce((a, id) => a + (pos.find((p) => p._id === id)?.totals?.grandTotal || 0), 0) }))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))) };
  },
  async get(id) {
    await tick();
    const o = readOrders().find((x) => x._id === id);
    if (!o) fail(404, 'Order not found.');
    return clone({ ...o, pos: readPos().filter((p) => o.poIds.includes(p._id)) });
  }
};
