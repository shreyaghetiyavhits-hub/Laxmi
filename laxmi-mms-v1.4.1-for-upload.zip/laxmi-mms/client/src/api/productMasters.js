import { http } from './http.js';
import { demoProductMastersApi, demoLookupsApi, demoPurchaseOrdersApi, demoVendorsApi, demoVendorMaterialsApi, demoReordersApi, demoOrdersApi } from './demoApi.js';

// `npm run build:demo` sets VITE_DEMO=true: the app then runs fully in the
// browser with sample data. Normal builds talk to the Node.js API.
export const IS_DEMO = import.meta.env.VITE_DEMO === 'true';

const serverProductMastersApi = {
  list: ({ q, status } = {}) => {
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (status) params.set('status', status);
    const qs = params.toString();
    return http(`/product-masters${qs ? `?${qs}` : ''}`);
  },
  get: (id) => http(`/product-masters/${id}`),
  create: (payload) => http('/product-masters', { method: 'POST', body: payload }),
  update: (id, payload) => http(`/product-masters/${id}`, { method: 'PUT', body: payload }),
  remove: (id) => http(`/product-masters/${id}`, { method: 'DELETE' }),
  createRevision: (id) => http(`/product-masters/${id}/revisions`, { method: 'POST' }),
  reorder: (id) => http(`/product-masters/${id}/reorder`, { method: 'POST' })
};

const serverLookupsApi = { get: () => http('/lookups') };

export const productMastersApi = IS_DEMO ? demoProductMastersApi : serverProductMastersApi;
export const lookupsApi = IS_DEMO ? demoLookupsApi : serverLookupsApi;

const serverPurchaseOrdersApi = {
  list: ({ q } = {}) => http(`/purchase-orders${q ? `?q=${encodeURIComponent(q)}` : ''}`),
  get: (id) => http(`/purchase-orders/${id}`),
  nextNumber: () => http('/purchase-orders/next-number'),
  create: (payload) => http('/purchase-orders', { method: 'POST', body: payload }),
  update: (id, payload) => http(`/purchase-orders/${id}`, { method: 'PUT', body: payload }),
  remove: (id) => http(`/purchase-orders/${id}`, { method: 'DELETE' })
};

export const purchaseOrdersApi = IS_DEMO ? demoPurchaseOrdersApi : serverPurchaseOrdersApi;

const serverVendorsApi = {
  list: ({ q, status } = {}) => {
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (status) params.set('status', status);
    const qs = params.toString();
    return http(`/vendors${qs ? `?${qs}` : ''}`);
  },
  nextCode: () => http('/vendors/next-code'),
  get: (id) => http(`/vendors/${id}`),
  create: (payload) => http('/vendors', { method: 'POST', body: payload }),
  update: (id, payload) => http(`/vendors/${id}`, { method: 'PUT', body: payload }),
  remove: (id) => http(`/vendors/${id}`, { method: 'DELETE' }),
  purchases: (id) => http(`/vendors/${id}/purchases`)
};

const serverVendorMaterialsApi = {
  list: (vendorId) => http(`/vendors/${vendorId}/materials`),
  create: (vendorId, payload) => http(`/vendors/${vendorId}/materials`, { method: 'POST', body: payload }),
  update: (mid, payload) => http(`/vendor-materials/${mid}`, { method: 'PUT', body: payload }),
  remove: (mid) => http(`/vendor-materials/${mid}`, { method: 'DELETE' }),
  history: (mid) => http(`/vendor-materials/${mid}/history`)
};

export const vendorMaterialsApi = IS_DEMO ? demoVendorMaterialsApi : serverVendorMaterialsApi;

export const vendorsApi = IS_DEMO ? demoVendorsApi : serverVendorsApi;

// Smart Reorder (v1.1). Build with VITE_SMART_REORDER=false to hide it and behave like v1.0.
export const SMART_REORDER = import.meta.env.VITE_SMART_REORDER !== 'false';

const serverReordersApi = {
  create: (body) => http('/reorders', { method: 'POST', body }),
  list: ({ status } = {}) => http(`/reorders${status ? `?status=${status}` : ''}`),
  get: (id) => http(`/reorders/${id}`),
  update: (id, body) => http(`/reorders/${id}`, { method: 'PUT', body }),
  discard: (id) => http(`/reorders/${id}/discard`, { method: 'POST' }),
  generate: (id, body) => http(`/reorders/${id}/generate`, { method: 'POST', body })
};
const serverOrdersApi = { list: () => http('/orders'), get: (id) => http(`/orders/${id}`) };

export const reordersApi = IS_DEMO ? demoReordersApi : serverReordersApi;
export const ordersApi = IS_DEMO ? demoOrdersApi : serverOrdersApi;
