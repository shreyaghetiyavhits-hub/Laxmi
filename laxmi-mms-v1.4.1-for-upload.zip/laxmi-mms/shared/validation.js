// Rules a BOM must pass before it can be saved as FINAL.
// Drafts skip these, so people can save half-finished work.
// Nothing is ever filled in for the user: blank stays blank until they choose.

import { isBoughtOut, toNumber } from './cost.js';

const blank = (v) => v === null || v === undefined || String(v).trim() === '';

/**
 * @returns {{ nodeUid?: string, subUid?: string, message: string }[]}
 */
export function finalIssues(bom) {
  const issues = [];
  if (blank(bom.modelNo)) issues.push({ message: 'Model no is required.' });
  if (!bom.nodes || bom.nodes.length === 0) {
    issues.push({ message: 'Add at least one item.' });
    return issues;
  }

  const checkLines = (lines, where, nodeUid, subUid) => {
    (lines || []).forEach((line, j) => {
      const at = `${where}, material ${j + 1}`;
      const add = (message) => issues.push({ nodeUid, subUid, message: `${at}: ${message}` });
      if (blank(line.material)) add('enter the material.');
      if (blank(line.source)) add('choose the source (In-house, Bought-out or Outsource).');
      if (blank(line.qty) || toNumber(line.qty) <= 0) add('enter a quantity more than 0.');
      if (blank(line.uom)) add('choose the unit.');
    });
  };

  bom.nodes.forEach((node, i) => {
    const tag = `Item ${i + 1}`;
    const where = `${tag}${node.name ? ` (${node.name})` : ''}`;
    const add = (message, subUid) => issues.push({ nodeUid: node.uid, subUid, message });
    if (blank(node.name)) add(`${tag} needs a name.`);
    if (blank(node.mode)) add(`${where}: choose Made in-house or Bought-out.`);
    if (blank(node.qty) || toNumber(node.qty) <= 0) add(`${where}: enter a quantity more than 0.`);
    if (blank(node.uom)) add(`${where}: choose the unit.`);
    if (isBoughtOut(node) || blank(node.mode)) return;

    checkLines(node.lines, where, node.uid, undefined);
    (node.subAssemblies || []).forEach((sub, k) => {
      const swhere = `${where}, sub-item ${k + 1}${sub.name ? ` (${sub.name})` : ''}`;
      if (blank(sub.name)) add(`${swhere}: enter a name.`, sub.uid);
      if (blank(sub.qty) || toNumber(sub.qty) <= 0) add(`${swhere}: enter a quantity more than 0.`, sub.uid);
      if (blank(sub.uom)) add(`${swhere}: choose the unit.`, sub.uid);
      checkLines(sub.lines, swhere, node.uid, sub.uid);
    });
  });
  return issues;
}
