// Values shared by the API and the React client, so both sides agree.

/** Units allowed on a material line. */
export const LINE_UOMS = ['Nos', 'Set', 'Pair', 'mm', 'm', 'kg', 'Sheet'];

/** Units allowed on an item or sub-item header. */
export const NODE_UOMS = ['Set', 'Nos', 'Pair'];

/** How a material line is procured. */
export const SOURCES = [
  { value: 'IH', label: 'In-house' },
  { value: 'BOC', label: 'Bought-out' },
  { value: 'OUT', label: 'Outsource' }
];
export const SOURCE_VALUES = SOURCES.map((s) => s.value);

/**
 * Every BOM entry is simply an "item" (no assembly / component split).
 * fabricated = made in-house from materials; bought_out = bought ready-made.
 */
export const NODE_KINDS = ['item'];
export const ITEM_MODES = ['fabricated', 'bought_out'];
export const COMPONENT_MODES = ITEM_MODES; // old name, kept for compatibility

/** draft = still being filled in; final = locked, edit by creating a new revision. */
export const STATUSES = ['draft', 'final'];

export const PROJECT_ID_PATTERN = /^PRJ-\d{4}$/;
