import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolveState, stateByName, stateFromGstin } from './gstStates.js';
import { computePo } from './po.js';

test('state name gives the code: Gujarat is 24', () => {
  assert.equal(stateByName('Gujarat').code, '24');
  assert.equal(stateByName(' GUJARAT ').code, '24');
  assert.equal(stateByName('Jammu & Kashmir').code, '01');
  assert.deepEqual(resolveState({ state: 'gujarat' }), { state: 'GUJARAT', stateCode: '24', gstinMismatch: null });
});

test('GSTIN gives the state when the state is not chosen', () => {
  assert.equal(stateFromGstin('27ABCDE1234F1Z5').name, 'MAHARASHTRA');
  assert.deepEqual(resolveState({ gstin: '24AABFL4153E1ZS' }), { state: 'GUJARAT', stateCode: '24', gstinMismatch: null });
});

test('GSTIN from another state is reported', () => {
  assert.equal(resolveState({ state: 'GUJARAT', gstin: '27ABCDE1234F1Z5' }).gstinMismatch.name, 'MAHARASHTRA');
});

test('unknown state stays as typed, with no invented code', () => {
  assert.deepEqual(resolveState({ state: 'Somewhere' }), { state: 'Somewhere', stateCode: '', gstinMismatch: null });
});

test('Gujarat vendor is charged CGST + SGST, Maharashtra vendor IGST', () => {
  const lines = [{ qty: 1, rate: 100, gstPct: 18 }];
  const guj = computePo({ vendor: resolveState({ state: 'Gujarat' }), lines });
  const mah = computePo({ vendor: resolveState({ state: 'Maharashtra' }), lines });
  assert.equal(guj.cgst, 9); assert.equal(guj.sgst, 9); assert.equal(guj.igst, 0);
  assert.equal(mah.igst, 18); assert.equal(mah.cgst, 0);
});
