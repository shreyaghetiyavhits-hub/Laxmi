// Purchase order maths, shared by the API and the client.
// Matches PO 0085: amount = qty × rate − discount; GST split into CGST + SGST
// for a vendor in the same state (code 24), otherwise IGST; grand total
// rounded to the nearest rupee with a "Round off" line.

import { toNumber } from './cost.js';
import { COMPANY } from './company.js';

export const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

/** Blank state code is treated as the company's own state. */
export function isIntraState(vendorStateCode, companyStateCode = COMPANY.stateCode) {
  const code = String(vendorStateCode ?? '').trim();
  return code === '' || code === String(companyStateCode);
}

export function computePo(po) {
  const intra = isIntraState(po.vendor?.stateCode);
  const lines = (po.lines || []).map((l) => {
    const gross = toNumber(l.qty) * toNumber(l.rate);
    const amount = round2(gross - (gross * toNumber(l.discPct)) / 100);
    const gst = toNumber(l.gstPct);
    const cgstPct = intra ? gst / 2 : 0;
    const igstPct = intra ? 0 : gst;
    return {
      ...l,
      amount,
      cgstPct,
      sgstPct: cgstPct,
      igstPct,
      cgst: round2((amount * cgstPct) / 100),
      sgst: round2((amount * cgstPct) / 100),
      igst: round2((amount * igstPct) / 100)
    };
  });

  const sum = (key) => round2(lines.reduce((a, l) => a + l[key], 0));
  const taxable = sum('amount');
  const cgst = sum('cgst');
  const sgst = sum('sgst');
  const igst = sum('igst');
  const totalQty = round2(lines.reduce((a, l) => a + toNumber(l.qty), 0));
  const exact = round2(taxable + cgst + sgst + igst);
  const grandTotal = Math.round(exact);
  const roundOff = round2(grandTotal - exact);

  // Tax summary per GST rate, like the "18% GST" row on PO 0085.
  const rates = new Map();
  for (const l of lines) {
    const key = toNumber(l.gstPct);
    const r = rates.get(key) || { gstPct: key, taxable: 0, cgst: 0, sgst: 0, igst: 0 };
    r.taxable = round2(r.taxable + l.amount);
    r.cgst = round2(r.cgst + l.cgst);
    r.sgst = round2(r.sgst + l.sgst);
    r.igst = round2(r.igst + l.igst);
    rates.set(key, r);
  }

  return {
    intra, lines, totalQty, taxable, cgst, sgst, igst, roundOff, grandTotal,
    byRate: [...rates.values()].sort((a, b) => b.gstPct - a.gstPct),
    words: amountInWords(grandTotal)
  };
}

const ONES = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE',
  'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
const TENS = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];

function twoDigits(n) {
  if (n < 20) return ONES[n];
  return [TENS[Math.floor(n / 10)], ONES[n % 10]].filter(Boolean).join(' ');
}

function threeDigits(n) {
  const h = Math.floor(n / 100);
  const rest = n % 100;
  return [h ? `${ONES[h]} HUNDRED` : '', rest ? twoDigits(rest) : ''].filter(Boolean).join(' ');
}

/** Indian system (crore, lakh, thousand), as printed on PO 0085: "FIFTEEN THOUSAND SIX HUNDRED FIFTY THREE ONLY". */
export function amountInWords(amount) {
  const rupees = Math.floor(Math.abs(toNumber(amount)));
  const paise = Math.round((Math.abs(toNumber(amount)) - rupees) * 100);
  if (rupees === 0 && paise === 0) return 'ZERO ONLY';
  const parts = [];
  let n = rupees;
  const crore = Math.floor(n / 10000000); n %= 10000000;
  const lakh = Math.floor(n / 100000); n %= 100000;
  const thousand = Math.floor(n / 1000); n %= 1000;
  if (crore) parts.push(`${threeDigits(crore)} CRORE`);
  if (lakh) parts.push(`${twoDigits(lakh)} LAKH`);
  if (thousand) parts.push(`${twoDigits(thousand)} THOUSAND`);
  if (n) parts.push(threeDigits(n));
  let words = parts.join(' ');
  if (paise) words += `${words ? ' AND ' : ''}${twoDigits(paise)} PAISE`;
  return `${words} ONLY`;
}

/** "0085" → "0086"; keeps the zero padding. */
export function nextPoNumber(existing = []) {
  let max = 0;
  let width = 4;
  for (const no of existing) {
    const m = String(no).match(/(\d+)\s*$/);
    if (m) {
      max = Math.max(max, parseInt(m[1], 10));
      width = Math.max(width, m[1].length);
    }
  }
  return String(max + 1).padStart(width, '0');
}
