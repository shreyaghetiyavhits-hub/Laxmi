// Cost and count rules for a BOM. Used by the API (to store totals)
// and by the client (to show live totals while editing).
//
// Every entry is an "item". A made-in-house item has material lines and may
// hold sub-items (stored in `subAssemblies`). A bought-out item has its own rate.

export function toNumber(value) {
  const n = typeof value === 'number' ? value : parseFloat(value);
  return Number.isFinite(n) ? n : 0;
}

/** A rate counts as pending when nobody has entered it yet. */
export function isPendingRate(rate) {
  return rate === null || rate === undefined || rate === '';
}

export function lineTotal(line) {
  return toNumber(line.qty) * toNumber(line.rate);
}

export function linesTotal(lines = []) {
  return lines.reduce((sum, line) => sum + lineTotal(line), 0);
}

export function isBoughtOut(node) {
  return node.mode === 'bought_out';
}

export function subAssemblyUnitCost(sub) {
  return linesTotal(sub.lines);
}

export function subAssemblyCost(sub) {
  return subAssemblyUnitCost(sub) * toNumber(sub.qty);
}

/** Cost of ONE unit of the item (before multiplying by the item qty). */
export function nodeUnitCost(node) {
  if (isBoughtOut(node)) return toNumber(node.rate);
  let total = linesTotal(node.lines);
  for (const sub of node.subAssemblies || []) total += subAssemblyCost(sub);
  return total;
}

export function nodeCost(node) {
  return nodeUnitCost(node) * toNumber(node.qty);
}

/** Every material line inside an item, including its sub-items. */
export function nodeLines(node) {
  if (isBoughtOut(node)) return [];
  return (node.lines || []).concat(...(node.subAssemblies || []).map((s) => s.lines || []));
}

export function nodePendingRates(node) {
  if (isBoughtOut(node)) return isPendingRate(node.rate) ? 1 : 0;
  return nodeLines(node).filter((l) => isPendingRate(l.rate)).length;
}

export function bomTotals(nodes = []) {
  let items = 0;
  let boughtOut = 0;
  let lineCount = 0;
  let pendingRates = 0;
  let cost = 0;
  for (const node of nodes) {
    items += 1;
    if (isBoughtOut(node)) boughtOut += 1;
    lineCount += nodeLines(node).length;
    pendingRates += nodePendingRates(node);
    cost += nodeCost(node);
  }
  return { items, boughtOut, madeInHouse: items - boughtOut, lineCount, pendingRates, cost: Math.round(cost * 100) / 100 };
}
