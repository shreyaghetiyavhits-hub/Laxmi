// Price history and vendor purchase summaries, shared by the API and the client.

import { toNumber } from './cost.js';
import { computePo, round2 } from './po.js';

/** Oldest first; same day keeps the order it was recorded in. */
export function sortHistory(history = []) {
  return history
    .map((h, i) => ({ ...h, _i: i }))
    .sort((a, b) => String(a.at).localeCompare(String(b.at)) || String(a.recordedAt || '').localeCompare(String(b.recordedAt || '')) || a._i - b._i)
    .map(({ _i, ...h }) => h);
}

/** The most recent price, or null if there is none. */
export function latestEntry(history = []) {
  const sorted = sortHistory(history);
  return sorted.length ? sorted[sorted.length - 1] : null;
}

/**
 * Current, first, lowest, highest, average and change since first.
 * Each entry also gets `change` / `changePct` against the entry before it.
 */
export function priceStats(history = []) {
  const entries = sortHistory(history).map((h, i, arr) => {
    const prev = i > 0 ? toNumber(arr[i - 1].rate) : null;
    const rate = toNumber(h.rate);
    return {
      ...h,
      rate,
      change: prev === null ? null : round2(rate - prev),
      changePct: prev === null || prev === 0 ? null : round2(((rate - prev) / prev) * 100)
    };
  });
  if (!entries.length) return { count: 0, entries: [] };
  const rates = entries.map((e) => e.rate);
  const first = entries[0];
  const last = entries[entries.length - 1];
  return {
    count: entries.length,
    entries,
    current: last.rate,
    currentAt: last.at,
    first: first.rate,
    firstAt: first.at,
    lowest: Math.min(...rates),
    highest: Math.max(...rates),
    average: round2(rates.reduce((a, r) => a + r, 0) / rates.length),
    changeSinceFirst: round2(last.rate - first.rate),
    changeSinceFirstPct: first.rate ? round2(((last.rate - first.rate) / first.rate) * 100) : null
  };
}

/** Totals for one vendor's purchase orders, plus what was bought and at what price. */
export function vendorPurchaseSummary(pos = []) {
  const orders = pos
    .map((po) => {
      const t = computePo(po);
      return {
        _id: po._id, poNo: po.poNo, date: po.date, modelNo: po.modelNo || '', rows: (po.lines || []).length,
        taxable: t.taxable, grandTotal: t.grandTotal
      };
    })
    .sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.poNo).localeCompare(String(a.poNo)));

  const items = new Map();
  for (const po of [...pos].sort((a, b) => String(a.date).localeCompare(String(b.date)))) {
    for (const l of po.lines || []) {
      const key = String(l.description || '').trim().toLowerCase();
      if (!key) continue;
      const it = items.get(key) || { description: String(l.description).trim(), uom: l.uom || '', totalQty: 0, orders: 0, totalValue: 0, lastRate: null, lastPoNo: '', lastDate: '' };
      const qty = toNumber(l.qty);
      const gross = qty * toNumber(l.rate);
      it.totalQty = round2(it.totalQty + qty);
      it.totalValue = round2(it.totalValue + gross - (gross * toNumber(l.discPct)) / 100);
      it.orders += 1;
      it.lastRate = toNumber(l.rate);
      it.lastPoNo = po.poNo;
      it.lastDate = po.date;
      if (l.uom) it.uom = l.uom;
      items.set(key, it);
    }
  }

  const totalValue = round2(orders.reduce((a, o) => a + o.grandTotal, 0));
  return {
    stats: {
      poCount: orders.length,
      totalValue,
      averageValue: orders.length ? round2(totalValue / orders.length) : 0,
      lastPoDate: orders[0]?.date || '',
      lastPoNo: orders[0]?.poNo || ''
    },
    orders,
    items: [...items.values()].sort((a, b) => b.totalValue - a.totalValue)
  };
}
