import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildReorderDraft, checkReorderDraft, posFromDraft, draftTotals } from './reorder.js';

let n = 0;
const uid = () => `u${++n}`;
const vendors = [
  { _id: 'v1', name: 'VISHWAKARMA', status: 'active', state: 'GUJARAT', stateCode: '24', contactPerson: 'Mr Shah', paymentTerms: '30' },
  { _id: 'v2', name: 'Gracefull', status: 'inactive', state: '', stateCode: '' }
];
const materials = [
  { _id: 'm1', vendorId: 'v1', material: 'KNOB', status: 'active', gstPct: 18, moq: 50, history: [{ at: '2026-04-24', rate: 108 }, { at: '2026-10-23', rate: 112 }] },
  { _id: 'm2', vendorId: 'v1', material: 'BELT', status: 'inactive', history: [{ at: '2026-04-24', rate: 415 }] }
];
const po85 = {
  _id: 'p85', poNo: '0085', vendorId: 'v1', vendor: { name: 'VISHWAKARMA' }, kindAttn: '', paymentTerms: '', remark: 'urgent',
  lines: [
    { description: 'KNOB', qty: 25, uom: 'NOS', rate: 108, gstPct: 18, vendorMaterialId: 'm1' },
    { description: 'BELT SS 304 3.5', qty: 16, uom: 'FT', rate: 415, gstPct: 18, vendorMaterialId: 'm2' },
    { description: 'RETURN ROLLER', qty: 4, uom: 'NOS', rate: 100, gstPct: 18 }
  ]
};

test('draft copies quantities and uses the supplier current rate, keeping the source rate', () => {
  const d = buildReorderDraft({ sourcePos: [po85], vendors, materials, uid });
  assert.equal(d.status, 'draft');
  assert.equal(d.pos.length, 1);
  const [knob, belt, roller] = d.pos[0].lines;
  assert.equal(knob.qty, 25);
  assert.equal(knob.rate, 112);
  assert.equal(knob.rateFrom, 'current');
  assert.equal(knob.from.rate, 108);
  assert.equal(belt.rate, 415); // inactive material: rate not refreshed
  assert.equal(roller.rate, 100); // not linked: source rate
  assert.equal(d.pos[0].kindAttn, 'Mr Shah'); // refreshed from Vendor master
  assert.deepEqual(d.source.poNos, ['0085']);
});

test('checks block inactive data and missing date, warn on MOQ, never generate', () => {
  const d = buildReorderDraft({ sourcePos: [po85], vendors, materials, uid });
  const c = checkReorderDraft(d, { vendors, materials, today: '2026-10-23' });
  assert.equal(c.ok, false);
  assert.ok(c.blocks.some((b) => /PO date/.test(b.message)));
  assert.ok(c.blocks.some((b) => /BELT.*inactive/.test(b.message)));
  assert.ok(c.warnings.some((w) => /minimum order of 50/.test(w.message)));
  assert.deepEqual(c.rows[d.pos[0].lines[0].uid].infos, ['Was ₹108 on PO 0085']);
});

test('fixed draft passes and becomes PO payloads with source references', () => {
  const d = buildReorderDraft({ sourcePos: [po85], vendors, materials, uid });
  d.poDate = '2026-10-23';
  d.pos[0].lines.splice(1, 1); // remove the inactive belt
  const c = checkReorderDraft(d, { vendors, materials, today: '2026-10-23' });
  assert.equal(c.ok, true, JSON.stringify(c.blocks));
  const pos = posFromDraft(d, { vendors });
  assert.equal(pos.length, 1);
  assert.equal(pos[0].vendor.stateCode, '24');
  assert.equal(pos[0].reorder.sourcePoNo, '0085');
  assert.equal(pos[0].lines[0].rate, 112);
  assert.equal(draftTotals(d, vendors).value, Math.round((25 * 112 + 4 * 100) * 1.18));
});

test('backdated PO date and inactive supplier are blocked', () => {
  const d = buildReorderDraft({ sourcePos: [{ ...po85, vendorId: 'v2' }], vendors, materials, uid });
  d.poDate = '2026-10-01';
  const c = checkReorderDraft(d, { vendors, materials, today: '2026-10-23' });
  assert.ok(c.blocks.some((b) => /earlier than today/.test(b.message)));
  assert.ok(c.blocks.some((b) => /Gracefull is inactive/.test(b.message)));
});

import { buildReorderDraftFromBom, bomPurchaseRows, derivePosFromMachine, supplierContext, purchaseForVendor, vendorOffers, nextReorderModelNo } from './reorder.js';

const bom = {
  _id: 'pm1', modelNo: 'LBSL 80', machineName: 'Bottle sticker labelling machine', revision: 0,
  nodes: [
    { uid: 'n1', mode: 'fabricated', name: '5 feet conveyor', qty: 1, uom: 'Set', lines: [
      { uid: 'k1', material: 'Knob', qty: 25, uom: 'Nos', source: '' },
      { uid: 'c1', material: 'Conveyor belt', qty: 1, uom: 'Nos', source: 'IH' }], subAssemblies: [] },
    { uid: 'n2', mode: 'bought_out', name: 'Gear box & motor', qty: 1, uom: 'Set', vendor: 'Gracefull', rate: 8200, lines: [], subAssemblies: [] },
    { uid: 'n3', mode: 'bought_out', name: 'Sensors', qty: 1, uom: 'Set', lines: [], subAssemblies: [] },
    { uid: 'n4', mode: '', name: 'Comb', lines: [], subAssemblies: [] }
  ]
};
const vendors2 = [
  { _id: 'v1', name: 'VISHWAKARMA', status: 'active', state: 'GUJARAT', stateCode: '24' },
  { _id: 'v2', name: 'Gracefull', status: 'active', state: 'GUJARAT', stateCode: '24' },
  { _id: 'v3', name: 'Cheap Knobs', status: 'active', state: 'GUJARAT', stateCode: '24' }
];
const mats2 = [
  { _id: 'mk1', vendorId: 'v1', material: 'KNOB', status: 'active', gstPct: 18, history: [{ at: '2026-10-23', rate: 112 }] },
  { _id: 'mk3', vendorId: 'v3', material: 'Knob', status: 'active', history: [{ at: '2026-10-01', rate: 95 }] }
];

test('BOM rows: bought-out items and material lines; items without a type are skipped', () => {
  const { rows, skipped } = bomPurchaseRows(bom.nodes);
  assert.deepEqual(rows.map((r) => r.material), ['Knob', 'Conveyor belt', 'Gear box & motor', 'Sensors']);
  assert.equal(skipped, 1);
});

test('machine reorder copies the whole machine and prepares one PO per supplier', () => {
  const pastPos = [{ _id: 'p86', poNo: '0086', date: '2026-10-23', vendorId: 'v1', lines: [{ description: 'KNOB', qty: 25, rate: 112, gstPct: 18, vendorMaterialId: 'mk1', source: { lineUid: 'k1' } }] }];
  const d = buildReorderDraftFromBom({ productMaster: bom, vendors: vendors2, materials: mats2, pastPos, uid });
  assert.equal(d.machine.nodes.length, 4); // full copy, including the item with no type
  assert.notEqual(d.machine.nodes, bom.nodes); // a copy, not the original
  assert.equal(d.purchase['l:c1'].order, false); // in-house row: copied, not ordered by default
  assert.deepEqual(d.pos.map((c) => c.vendorName), ['Gracefull', 'VISHWAKARMA', 'Rows without a supplier']);
  const knob = d.pos[1].lines[0];
  assert.equal(knob.rate, 112);
  assert.equal(knob.supplierFrom, 'Supplier from last PO 0086');
  assert.equal(d.pos[0].lines[0].rate, 8200);
  assert.equal(d.pos[2].lines[0].material, 'Sensors');
});

test('editing the machine copy changes the prepared POs, never the original', () => {
  const d = buildReorderDraftFromBom({ productMaster: bom, vendors: vendors2, materials: mats2, pastPos: [], uid });
  d.machine.nodes[0].lines[0].qty = 50; // knobs for this customer
  d.machine.nodes[0].qty = 2; // two conveyors
  const ctx = supplierContext({ vendors: vendors2, materials: mats2 });
  const row = bomPurchaseRows(d.machine.nodes).rows.find((r) => r.key === 'l:k1');
  d.purchase['l:k1'] = purchaseForVendor(row, d.purchase['l:k1'], vendors2[0], ctx); // change vendor to VISHWAKARMA
  d.purchase['l:c1'].order = true; // also order the belt
  const pos = derivePosFromMachine(d, vendors2);
  const knob = pos.flatMap((c) => c.lines).find((l) => l.uid === 'l:k1');
  assert.equal(knob.qty, 100);
  assert.equal(knob.rate, 112);
  assert.equal(pos.find((c) => c.lines.includes(knob)).vendorName, 'VISHWAKARMA');
  assert.ok(pos.flatMap((c) => c.lines).some((l) => l.uid === 'l:c1'));
  assert.equal(bom.nodes[0].lines[0].qty, 25); // original untouched
});

test('without past POs the cheaper supplier list wins', () => {
  const d = buildReorderDraftFromBom({ productMaster: bom, vendors: vendors2, materials: mats2, pastPos: [], uid });
  const knobCard = d.pos.find((c) => c.lines.some((l) => l.material === 'Knob'));
  assert.equal(knobCard.vendorName, 'Cheap Knobs');
  assert.match(knobCard.lines[0].supplierFrom, /lowest of 2/);
  const offers = vendorOffers('Knob', supplierContext({ vendors: vendors2, materials: mats2 }));
  assert.deepEqual(offers.map((o) => [o.vendor.name, o.rate]), [['Cheap Knobs', 95], ['VISHWAKARMA', 112]]);
  const check = checkReorderDraft({ ...d, poDate: '2026-10-23' }, { vendors: vendors2, materials: mats2, today: '2026-10-23' });
  assert.ok(check.blocks.some((b) => /no supplier/.test(b.message)));
});

test('reorder copies get the next free model no', () => {
  assert.equal(nextReorderModelNo('LBSL 80', ['LBSL 80']), 'LBSL 80-RO1');
  assert.equal(nextReorderModelNo('LBSL 80', ['LBSL 80', 'LBSL 80-RO1', 'lbsl 80-ro2']), 'LBSL 80-RO3');
  assert.equal(nextReorderModelNo('LBSL 80-RO1', ['LBSL 80-RO1']), 'LBSL 80-RO2');
});

test('POs for a reorder copy: plain prepared POs, labelled with the original machine', () => {
  const copy = { ...bom, _id: 'pm2', modelNo: 'LBSL 80-RO1', reorderOf: { productMasterId: 'pm1', modelNo: 'LBSL 80', revision: 0 } };
  const d = buildReorderDraftFromBom({ productMaster: copy, vendors: vendors2, materials: mats2, pastPos: [], uid, copyMachine: false });
  assert.equal(d.machine, undefined);
  assert.equal(d.source.reorderOfModelNo, 'LBSL 80');
  assert.equal(d.productMaster, 'pm2');
  assert.ok(d.pos.length >= 2);
});

test('a vendor written on the material in the Product master wins over the last PO', () => {
  const pastPos = [{ _id: 'p86', poNo: '0086', date: '2026-10-23', vendorId: 'v1', lines: [{ description: 'KNOB', qty: 25, rate: 112, gstPct: 18, source: { lineUid: 'k1' } }] }];
  const copy = JSON.parse(JSON.stringify(bom));
  copy.nodes[0].lines[0].vendor = 'Cheap Knobs';
  const d = buildReorderDraftFromBom({ productMaster: copy, vendors: vendors2, materials: mats2, pastPos, uid, copyMachine: false });
  const card = d.pos.find((c) => c.lines.some((l) => l.material === 'Knob'));
  assert.equal(card.vendorName, 'Cheap Knobs');
  assert.equal(card.lines.find((l) => l.material === 'Knob').rate, 95); // that vendor's list rate
  assert.equal(card.lines.find((l) => l.material === 'Knob').supplierFrom, 'Vendor chosen in the Product master');
});
