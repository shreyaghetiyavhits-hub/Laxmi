import { test } from 'node:test';
import assert from 'node:assert/strict';
import { priceStats, latestEntry, vendorPurchaseSummary } from './priceHistory.js';

const history = [
  { at: '2026-06-01', rate: 120, source: 'po', poNo: '0090' },
  { at: '2026-04-24', rate: 108, source: 'po', poNo: '0085' },
  { at: '2026-05-10', rate: 110, source: 'manual' }
];

test('history is read oldest first and the latest price wins', () => {
  assert.equal(latestEntry(history).rate, 120);
  const s = priceStats(history);
  assert.deepEqual(s.entries.map((e) => e.rate), [108, 110, 120]);
  assert.equal(s.current, 120);
  assert.equal(s.lowest, 108);
  assert.equal(s.highest, 120);
  assert.equal(s.average, 112.67);
  assert.equal(s.changeSinceFirst, 12);
  assert.equal(s.changeSinceFirstPct, 11.11);
  assert.equal(s.entries[1].change, 2);
  assert.equal(s.entries[1].changePct, 1.85);
});

test('empty history has no invented price', () => {
  assert.equal(latestEntry([]), null);
  assert.deepEqual(priceStats([]), { count: 0, entries: [] });
});

test('vendor purchase summary totals POs and items', () => {
  const pos = [
    { _id: 'a', poNo: '0085', date: '2026-04-24', vendor: { stateCode: '24' }, lines: [{ description: 'KNOB', qty: 25, uom: 'NOS', rate: 108, gstPct: 18 }] },
    { _id: 'b', poNo: '0090', date: '2026-06-01', vendor: { stateCode: '24' }, lines: [{ description: 'Knob', qty: 10, uom: 'NOS', rate: 120, gstPct: 18 }] }
  ];
  const s = vendorPurchaseSummary(pos);
  assert.equal(s.stats.poCount, 2);
  assert.equal(s.stats.lastPoNo, '0090');
  assert.equal(s.stats.totalValue, 3186 + 1416);
  assert.equal(s.items.length, 1);
  assert.equal(s.items[0].totalQty, 35);
  assert.equal(s.items[0].lastRate, 120);
  assert.equal(s.items[0].orders, 2);
});
