// Indian GST state codes. The state code is never typed in: it comes from the
// state chosen (Gujarat → 24) or from the first 2 digits of the GSTIN.

export const GST_STATES = [
  ['01', 'JAMMU AND KASHMIR'], ['02', 'HIMACHAL PRADESH'], ['03', 'PUNJAB'], ['04', 'CHANDIGARH'], ['05', 'UTTARAKHAND'],
  ['06', 'HARYANA'], ['07', 'DELHI'], ['08', 'RAJASTHAN'], ['09', 'UTTAR PRADESH'], ['10', 'BIHAR'], ['11', 'SIKKIM'],
  ['12', 'ARUNACHAL PRADESH'], ['13', 'NAGALAND'], ['14', 'MANIPUR'], ['15', 'MIZORAM'], ['16', 'TRIPURA'], ['17', 'MEGHALAYA'],
  ['18', 'ASSAM'], ['19', 'WEST BENGAL'], ['20', 'JHARKHAND'], ['21', 'ODISHA'], ['22', 'CHHATTISGARH'], ['23', 'MADHYA PRADESH'],
  ['24', 'GUJARAT'], ['26', 'DADRA AND NAGAR HAVELI AND DAMAN AND DIU'], ['27', 'MAHARASHTRA'], ['29', 'KARNATAKA'], ['30', 'GOA'],
  ['31', 'LAKSHADWEEP'], ['32', 'KERALA'], ['33', 'TAMIL NADU'], ['34', 'PUDUCHERRY'], ['35', 'ANDAMAN AND NICOBAR ISLANDS'],
  ['36', 'TELANGANA'], ['37', 'ANDHRA PRADESH'], ['38', 'LADAKH']
].map(([code, name]) => ({ code, name }));

const byName = new Map(GST_STATES.map((s) => [s.name, s]));
const byCode = new Map(GST_STATES.map((s) => [s.code, s]));
const clean = (v) => String(v ?? '').trim().toUpperCase().replace(/&/g, 'AND').replace(/\s+/g, ' ');

/** "Gujarat" / "GUJARAT" → { code: '24', name: 'GUJARAT' }, or null. */
export const stateByName = (name) => byName.get(clean(name)) || null;
export const stateByCode = (code) => byCode.get(String(code ?? '').trim().padStart(2, '0')) || null;

/** The state a GSTIN belongs to: its first 2 digits are the state code. */
export const stateFromGstin = (gstin) => (/^\d{2}/.test(String(gstin ?? '').trim()) ? stateByCode(String(gstin).trim().slice(0, 2)) : null);

/**
 * Works out state name and code from whatever is known: the state name first,
 * then the code, then the GSTIN. Also reports a GSTIN that belongs to another state.
 */
export function resolveState({ state, stateCode, gstin } = {}) {
  const fromName = stateByName(state);
  const fromCode = stateByCode(stateCode);
  const fromGstin = stateFromGstin(gstin);
  const s = fromName || fromCode || fromGstin;
  return {
    state: s ? s.name : String(state ?? '').trim(),
    stateCode: s ? s.code : '',
    gstinMismatch: Boolean(s && fromGstin && fromGstin.code !== s.code) ? fromGstin : null
  };
}
