// The LBSL 80 BOM from "BOM for bottle sticker labelling machine".
// Used by the server seed script and by the browser demo build.
// Rates are null because the source PDF has none.

export const SAMPLE_MACHINE = { machineName: 'Bottle sticker labelling machine', modelNo: 'LBSL 80' };

export function buildLbsl80Nodes(uid) {
  // Only what the PDF states. Anything the PDF leaves out stays blank ('' or null):
  // no assumed source, quantity, unit or item type.
  const line = (material, o = {}) => ({ uid: uid(), material, spec: '', cutSize: '', process: '', vendor: '', qty: null, uom: '', source: '', rate: null, ...o });
  const sub = (name, lines = [], o = {}) => ({ uid: uid(), code: '', name, qty: null, uom: '', lines, ...o });
  const item = (name, mode, lines = [], o = {}) =>
    ({ uid: uid(), kind: 'item', mode, code: '', name, qty: null, uom: '', spec: '', vendor: '', rate: null, lines, subAssemblies: [], ...o });
  const made = (name, lines = [], o = {}) => item(name, 'fabricated', lines, o); // PDF: "Raw material" or listed materials
  const bought = (name, o = {}) => item(name, 'bought_out', [], o); // PDF: "Bought out"
  const unknown = (name) => item(name, ''); // PDF gives no details
  const SET = { qty: 1, uom: 'Set' }; // PDF: "1 set"
  const NOS = (n) => ({ qty: n, uom: 'Nos' }); // PDF: "n Nos"
  const LASER = 'Laser cutting';

  // Same order as the PDF, so the printout reads like the original sheet.
  return [
    made('Machine body frame',
      [
        line('Top plate', { spec: '8 LH 1', process: 'Laser cutting, with material' }),
        line('3/4" leveling bolt', { source: 'BOC', vendor: 'Gracefull', qty: 4 })
      ],
      {
        ...SET,
        subAssemblies: [
          sub('Machine body', [
            line('SS 304 mirror finish square pipe 40 × 40 × 1.5 mm', { cutSize: 'Total length 5400 mm', qty: 5400, uom: 'mm' }),
            line('SS 304 mirror finish square pipe 20 × 20 × 1.5 mm', { cutSize: 'Total length 9700 mm', qty: 9700, uom: 'mm' })
          ], { code: 'RG 3' })
        ]
      }),
    made('Top cover', [line('', { process: LASER })]),
    made('Applicator dolphin plate', [line('Aluminium HE36')]),
    made('Applicator bottom plate', [line('Aluminium HE36')]),
    made('Applicator roller set', [
      line('SS 304 seamless pipe OD 25.4 × ID 18 mm', { cutSize: 'L 140 mm' }),
      line('SS 304 round bar Ø 19 mm', { cutSize: 'L 165 mm' })
    ]),
    made('Label mounting sheet top & bottom', [line('', { process: LASER })], SET),
    bought('Applicator pipe degree assembly', SET),
    made('Screw for applicator pipe degree assembly', [line('SS 304 round bar Ø 16 mm', { cutSize: 'L 170 mm' })], NOS(1)),
    bought('Rubber assembly', SET),
    bought('Knurling aluminium roller assembly'),
    bought('Blank roll winding assembly'),
    unknown('Clock assembly'),
    unknown('Comb'),
    unknown('Ring'),
    bought('Timing pulley set for applicator', SET),
    bought('Idler roller assembly for applicator', SET),
    bought('Aluminium block for applicator label roll mounting', SET),
    unknown('Applicator other small items'),
    made('5 feet conveyor',
      [
        line('Conveyor channel RH', { process: LASER, ...NOS(1) }),
        line('Conveyor channel LH', { process: LASER, ...NOS(1) }),
        line('Conveyor driver shaft', NOS(1)),
        line('Conveyor driver sprocket', NOS(1)),
        line('Conveyor idler shaft', NOS(1)),
        line('Conveyor idler sprocket', NOS(1)),
        line('Conveyor fitting distance piece', NOS(7)),
        line('Conveyor fitting distance piece roller', NOS(5)),
        line('Conveyor belt', NOS(1)),
        line('Square piece', NOS(10)),
        line('Round piece', NOS(10)),
        line('Vertical stud', NOS(10)),
        line('Knob', NOS(25))
      ],
      { ...SET, subAssemblies: [sub('Conveyor dag', [], NOS(2))] }),
    made('Degree distance piece', [line('')]),
    bought('Wrapping roller & shaft', SET),
    bought('Wrapping idler', SET),
    made('Wrapping distance pieces', [line('')], SET),
    made('Wrapping pressing & belt plate', [line('')], SET),
    made('Bottle separator with small housing', [line('SS 304 investment casting', { process: 'Investment casting, with raw material' })], SET),
    bought('Timing pulley T5 set', SET),
    bought('Gear box & motor', { ...SET, spec: 'Box 30, ratio 30, with flange and 0.25 HP motor (alternate: ratio 20)' }),
    made('Switch box & all doors', [line('')]),
    bought('Handle & block'),
    bought('Wiring & automation', SET),
    bought('All sensors', SET),
    bought('Wrapping belt', SET),
    bought('White timing belt', SET),
    bought('190 XL timing belt', SET),
    bought('O-ring set', SET),
    bought('Fasteners', SET)
  ];
}

/** Starter suggestions for type-or-pick fields. */
export const DEFAULT_LOOKUPS = {
  materials: [
    'SS 304 sheet',
    'SS 304 mirror finish square pipe 40 × 40 × 1.5 mm',
    'SS 304 mirror finish square pipe 20 × 20 × 1.5 mm',
    'SS 304 seamless pipe OD 25.4 × ID 18 mm',
    'SS 304 round bar Ø 19 mm',
    'SS 304 round bar Ø 16 mm',
    'SS 304 investment casting',
    'Aluminium HE36'
  ],
  parts: [
    'Machine body frame', 'Machine body', 'Top plate', 'Top cover', 'Applicator dolphin plate', 'Applicator bottom plate',
    'Applicator roller set', 'Label mounting sheet', '5 feet conveyor', 'Conveyor dag',
    'Bottle separator with small housing', 'Gear box & motor', 'All sensors', 'Fasteners'
  ],
  vendors: [], // vendor suggestions come from the Vendor master
  processes: ['Laser cutting', 'Laser cutting, with material', 'Investment casting', 'Machining', 'Welding']
};
