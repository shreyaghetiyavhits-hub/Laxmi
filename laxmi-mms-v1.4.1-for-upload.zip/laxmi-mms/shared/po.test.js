import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computePo, amountInWords, nextPoNumber } from './po.js';

// PO 0085 to Vishwakarma Dies & Tools Industries (Gujarat, code 24)
const po85 = {
  vendor: { stateCode: '24' },
  lines: [
    { qty: 2, rate: 575, gstPct: 18 },
    { qty: 2, rate: 550, gstPct: 18 },
    { qty: 3, rate: 425, gstPct: 18 },
    { qty: 16, rate: 415, gstPct: 18 },
    { qty: 4, rate: 100, gstPct: 18 },
    { qty: 25, rate: 108, gstPct: 18 }
  ]
};

test('reproduces every total on PO 0085', () => {
  const t = computePo(po85);
  assert.equal(t.totalQty, 52);
  assert.equal(t.taxable, 13265);
  assert.equal(t.cgst, 1193.85);
  assert.equal(t.sgst, 1193.85);
  assert.equal(t.igst, 0);
  assert.equal(t.roundOff, 0.3);
  assert.equal(t.grandTotal, 15653);
  assert.equal(t.words, 'FIFTEEN THOUSAND SIX HUNDRED FIFTY THREE ONLY');
  assert.deepEqual(t.lines.map((l) => l.amount), [1150, 1100, 1275, 6640, 400, 2700]);
});

test('other state uses IGST', () => {
  const t = computePo({ ...po85, vendor: { stateCode: '27' } });
  assert.equal(t.cgst, 0);
  assert.equal(t.igst, 2387.7);
  assert.equal(t.grandTotal, 15653);
});

test('discount reduces the line amount', () => {
  const t = computePo({ lines: [{ qty: 10, rate: 100, discPct: 5, gstPct: 18 }] });
  assert.equal(t.lines[0].amount, 950);
  assert.equal(t.cgst, 85.5);
});

test('amount in words, Indian system', () => {
  assert.equal(amountInWords(1250000), 'TWELVE LAKH FIFTY THOUSAND ONLY');
  assert.equal(amountInWords(10000001), 'ONE CRORE ONE ONLY');
  assert.equal(amountInWords(105), 'ONE HUNDRED FIVE ONLY');
});

test('next PO number keeps padding', () => {
  assert.equal(nextPoNumber(['0085', '0084']), '0086');
  assert.equal(nextPoNumber([]), '0001');
  assert.equal(nextPoNumber(['0999']), '1000');
});
