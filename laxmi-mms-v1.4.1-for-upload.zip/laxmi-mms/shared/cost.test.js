import { test } from 'node:test';
import assert from 'node:assert/strict';
import { bomTotals, nodeUnitCost, nodePendingRates } from './cost.js';
import { finalIssues } from './validation.js';

const frame = {
  uid: 'a1', kind: 'item', mode: 'fabricated', name: 'Machine body frame', qty: 2,
  lines: [
    { uid: 'l1', material: 'Top plate', qty: 1, rate: 1500 },
    { uid: 'l2', material: '3/4" leveling bolt', qty: 4, rate: 50 }
  ],
  subAssemblies: [
    { uid: 's1', name: 'Machine body', qty: 1, lines: [{ uid: 'l3', material: 'SS 304 pipe', qty: 5.4, rate: 600 }] }
  ]
};
const gearbox = { uid: 'c1', kind: 'item', mode: 'bought_out', name: 'Gear box & motor', qty: 1, rate: null, lines: [] };

test('made item unit cost includes materials and sub-items', () => {
  assert.equal(nodeUnitCost(frame), 4940); // 1500 + 200 + 5.4 × 600
});

test('a made item without an assembly label can still hold sub-items', () => {
  const plain = { ...frame, kind: undefined };
  assert.equal(nodeUnitCost(plain), 4940);
});

test('bought-out item uses its own rate and counts as pending when empty', () => {
  assert.equal(nodeUnitCost(gearbox), 0);
  assert.equal(nodePendingRates(gearbox), 1);
});

test('bomTotals multiplies by item qty and counts items', () => {
  const t = bomTotals([frame, gearbox]);
  assert.equal(t.cost, 9880);
  assert.equal(t.items, 2);
  assert.equal(t.boughtOut, 1);
  assert.equal(t.madeInHouse, 1);
  assert.equal(t.lineCount, 3);
  assert.equal(t.pendingRates, 1);
});

test('finalIssues never assumes values: blank source, qty, unit and type are reported', () => {
  const issues = finalIssues({
    modelNo: 'LBSL 80',
    nodes: [
      { uid: 'x', kind: 'item', mode: 'fabricated', name: '', qty: 1, uom: 'Set', lines: [{ uid: 'y', material: 'Plate', source: '', qty: null, uom: '' }] },
      { uid: 'z', kind: 'item', mode: '', name: 'Comb', qty: null, uom: '' }
    ]
  }).map((i) => i.message);
  assert.deepEqual(issues, [
    'Item 1 needs a name.',
    'Item 1, material 1: choose the source (In-house, Bought-out or Outsource).',
    'Item 1, material 1: enter a quantity more than 0.',
    'Item 1, material 1: choose the unit.',
    'Item 2 (Comb): choose Made in-house or Bought-out.',
    'Item 2 (Comb): enter a quantity more than 0.',
    'Item 2 (Comb): choose the unit.'
  ]);
});

test('finalIssues passes a complete BOM', () => {
  const full = (n) => ({ ...n, uom: 'Set', lines: (n.lines || []).map((l) => ({ ...l, source: 'IH', uom: 'Nos' })),
    subAssemblies: (n.subAssemblies || []).map((s) => ({ ...s, uom: 'Set', lines: s.lines.map((l) => ({ ...l, source: 'BOC', uom: 'm' })) })) });
  assert.deepEqual(finalIssues({ modelNo: 'LBSL 80', nodes: [full(frame), full({ ...gearbox, rate: 0 })] }), []);
});

test('sample BOM has no invented sources, quantities or units', async () => {
  const { buildLbsl80Nodes } = await import('./sampleBom.js');
  const nodes = buildLbsl80Nodes(() => 'u');
  const lines = nodes.flatMap((n) => [...n.lines, ...n.subAssemblies.flatMap((s) => s.lines)]);
  assert.equal(lines.filter((l) => l.source === 'IH').length, 0);
  assert.equal(nodes.find((n) => n.name === 'Top cover').qty, null);
  assert.equal(nodes.find((n) => n.name === 'Comb').mode, '');
  assert.equal(lines.find((l) => l.material === 'Knob').qty, 25);
});
