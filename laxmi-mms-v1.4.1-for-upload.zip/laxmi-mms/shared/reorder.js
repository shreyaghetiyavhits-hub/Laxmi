// Smart Reorder: prepare a draft from previous POs, check it, and turn it into
// new purchase orders. Shared by the API and the browser demo, so both follow
// exactly the same rules.
//
// Rules used (recommended answers from the specification):
// - Quantities, units, descriptions, HSN, discount and GST rate are copied from the source PO.
// - Rate: the supplier's CURRENT rate from its material list when there is one,
//   otherwise the source PO's rate. The source rate is kept so it can be restored.
// - Supplier details (address, state, GSTIN) are taken fresh from the Vendor master at generation.
// - PO numbers are given only at generation; the PO date may not be earlier than today.
// - One prepared PO per source PO (two source POs to one supplier stay two POs).

import { toNumber } from './cost.js';
import { computePo, round2 } from './po.js';
import { latestEntry } from './priceHistory.js';
import { resolveState } from './gstStates.js';
import { isBoughtOut } from './cost.js';
import { STANDARD_GST_PCT } from './company.js';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const blank = (v) => v === null || v === undefined || String(v).trim() === '';
const sameNum = (a, b) => !blank(a) && !blank(b) && round2(toNumber(a)) === round2(toNumber(b));

/** Build a reorder draft (not a purchase order) from one or more source POs. */
export function buildReorderDraft({ sourcePos, sourceOrder = null, vendors = [], materials = [], uid }) {
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  const matById = new Map(materials.map((m) => [String(m._id), m]));
  const pos = sourcePos.map((po) => {
    const vendor = po.vendorId ? vendorById.get(String(po.vendorId)) : null;
    return {
      uid: uid(),
      sourcePoId: po._id,
      sourcePoNo: po.poNo,
      vendorId: vendor ? vendor._id : null,
      vendorName: vendor ? vendor.name : po.vendor?.name || '',
      excluded: false,
      kindAttn: vendor?.contactPerson || po.kindAttn || '',
      paymentTerms: vendor?.paymentTerms || po.paymentTerms || '',
      refNo: '',
      refDate: '',
      remark: po.remark || '',
      terms: po.terms || '',
      lines: (po.lines || []).map((l) => {
        const m = l.vendorMaterialId ? matById.get(String(l.vendorMaterialId)) : null;
        const current = m ? latestEntry(m.history) : null;
        const useCurrent = current && m.status !== 'inactive';
        return {
          uid: uid(),
          description: l.description || '',
          hsn: l.hsn || '',
          qty: l.qty,
          uom: l.uom || '',
          rate: useCurrent ? current.rate : l.rate,
          rateFrom: useCurrent && !sameNum(current.rate, l.rate) ? 'current' : 'source',
          discPct: l.discPct ?? null,
          gstPct: l.gstPct,
          vendorMaterialId: l.vendorMaterialId || null,
          bomSource: l.source || {},
          material: l.description || '',
          from: { label: `PO ${po.poNo}`, poNo: po.poNo, description: l.description || '', qty: l.qty, uom: l.uom || '', rate: l.rate, discPct: l.discPct ?? null, gstPct: l.gstPct }
        };
      })
    };
  });
  return {
    status: 'draft',
    source: {
      kind: sourceOrder ? 'order' : 'pos',
      orderId: sourceOrder?._id || null,
      orderNo: sourceOrder?.orderNo || '',
      poIds: sourcePos.map((p) => p._id),
      poNos: sourcePos.map((p) => p.poNo)
    },
    poDate: '',
    projectId: sourceOrder?.projectId || '',
    customerRef: sourceOrder?.customerRef || '',
    modelNo: sourceOrder?.modelNo || sourcePos.find((p) => p.modelNo)?.modelNo || '',
    productMaster: sourceOrder?.productMaster || sourcePos.find((p) => p.productMaster)?.productMaster || null,
    pos
  };
}

/** Prepared PO as a PO-shaped object, for totals and the preview. */
export function preparedPoAsPo(card, vendor, draft) {
  const st = resolveState(vendor || {});
  return {
    poNo: '',
    date: draft.poDate || '',
    refNo: card.refNo,
    refDate: card.refDate,
    kindAttn: card.kindAttn,
    vendorId: card.vendorId,
    vendor: vendor
      ? { name: vendor.name, address: vendor.address || '', gstin: vendor.gstin || '', state: st.state, stateCode: st.stateCode }
      : { name: card.vendorName || '', address: '', gstin: '', state: '', stateCode: '' },
    lines: card.lines.map((l) => ({ ...l, qty: toNumber(l.qty), rate: toNumber(l.rate), discPct: blank(l.discPct) ? null : toNumber(l.discPct), gstPct: toNumber(l.gstPct) })),
    paymentTerms: card.paymentTerms,
    remark: card.remark,
    terms: card.terms
  };
}

/**
 * Checks a draft against today's masters.
 * blocks = must be fixed before generation; warnings = shown for review; infos = context only.
 */
export function checkReorderDraft(draft, { vendors = [], materials = [], today }) {
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  const matById = new Map(materials.map((m) => [String(m._id), m]));
  const blocks = [];
  const warnings = [];
  const rows = {};
  const cards = {};
  const note = (bucket, list, item) => { bucket.push(item); list.push(item); };

  if (blank(draft.poDate)) blocks.push({ message: 'Choose the PO date.' });
  else if (today && draft.poDate < today) blocks.push({ message: 'The PO date cannot be earlier than today.' });

  const included = draft.pos.filter((c) => !c.excluded);
  if (!included.length) blocks.push({ message: 'Include at least one purchase order.' });

  draft.pos.forEach((card, ci) => {
    const c = (cards[card.uid] = { blocks: [], warnings: [], infos: [] });
    if (card.excluded) return;
    const vendor = card.vendorId ? vendorById.get(String(card.vendorId)) : null;
    const name = vendor?.name || card.vendorName || `PO ${ci + 1}`;
    const cardItem = (message) => ({ cardUid: card.uid, message });
    if (!card.vendorId) {
      note(c.blocks, blocks, cardItem(card.unassigned
        ? `${plural(card.lines.length, 'row has', 'rows have')} no supplier: choose a supplier for this card, or move each row to a supplier.`
        : `${name}: choose this supplier from the Vendor master.`));
    }
    else if (!vendor) note(c.blocks, blocks, cardItem(`${name}: this supplier no longer exists. Choose another supplier.`));
    else {
      if (vendor.status === 'inactive') note(c.blocks, blocks, cardItem(`${vendor.name} is inactive. Choose another supplier or exclude this PO.`));
      if (!resolveState(vendor).stateCode) note(c.blocks, blocks, cardItem(`${vendor.name}: state is missing in the Vendor master.`));
    }
    if (!card.lines.length) note(c.blocks, blocks, cardItem(`${name}: this PO has no rows. Add a row or exclude it.`));

    card.lines.forEach((l, li) => {
      const r = (rows[l.uid] = { blocks: [], warnings: [], infos: [] });
      const at = `${name}, row ${li + 1}${l.description ? ` (${l.description})` : ''}`;
      const item = (message) => ({ cardUid: card.uid, rowUid: l.uid, message });
      if (blank(l.description)) note(r.blocks, blocks, item(`${at}: enter a description.`));
      if (blank(l.qty) || toNumber(l.qty) <= 0) note(r.blocks, blocks, item(`${at}: enter a quantity more than 0.`));
      if (blank(l.rate)) note(r.blocks, blocks, item(`${at}: enter the rate.`));
      if (blank(l.gstPct)) note(r.blocks, blocks, item(`${at}: choose the GST rate.`));

      const m = l.vendorMaterialId ? matById.get(String(l.vendorMaterialId)) : null;
      if (l.vendorMaterialId && !m) note(r.warnings, warnings, item(`${at}: no longer in the supplier's material list.`));
      if (m && String(m.vendorId) !== String(card.vendorId)) note(r.warnings, warnings, item(`${at}: linked to another supplier's material list.`));
      if (m && m.status === 'inactive') note(r.blocks, blocks, item(`${at}: this material is inactive in the supplier's list.`));
      if (m) {
        const current = latestEntry(m.history);
        if (current && !blank(l.rate) && !sameNum(current.rate, l.rate)) {
          note(r.warnings, warnings, item(`${at}: supplier's current rate is ₹${current.rate}, this PO uses ₹${l.rate}.`));
        }
        if (!blank(m.gstPct) && !blank(l.gstPct) && toNumber(m.gstPct) !== toNumber(l.gstPct)) {
          note(r.warnings, warnings, item(`${at}: supplier's list gives GST ${m.gstPct}%, this PO uses ${l.gstPct}%.`));
        }
        if (!blank(m.moq) && toNumber(l.qty) > 0 && toNumber(l.qty) < toNumber(m.moq)) {
          note(r.warnings, warnings, item(`${at}: below the supplier's minimum order of ${m.moq}.`));
        }
      }
      const fromLabel = l.from ? l.from.label || `PO ${l.from.poNo}` : '';
      if (l.from && !blank(l.from.rate) && !blank(l.rate) && !sameNum(l.from.rate, l.rate)) {
        r.infos.push(`Was ₹${l.from.rate} on ${fromLabel}`);
      }
      if (l.from && !blank(l.from.qty) && !blank(l.qty) && !sameNum(l.from.qty, l.qty)) {
        r.infos.push(`Was ${l.from.qty} on ${fromLabel}`);
      }
      if (l.supplierFrom) r.infos.push(l.supplierFrom);
    });
  });
  return { blocks, warnings, rows, cards, ok: blocks.length === 0 };
}

/** Turn the included prepared POs into new PO payloads (without numbers). */
export function posFromDraft(draft, { vendors = [] }) {
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  return draft.pos.filter((c) => !c.excluded).map((card) => {
    const vendor = vendorById.get(String(card.vendorId));
    const po = preparedPoAsPo(card, vendor, draft);
    return {
      ...po,
      productMaster: draft.productMaster || null,
      modelNo: draft.modelNo || '',
      machines: null,
      lines: card.lines.map((l) => ({
        uid: l.uid, description: String(l.description).trim(), hsn: l.hsn || '', qty: toNumber(l.qty), uom: l.uom || '',
        rate: toNumber(l.rate), discPct: blank(l.discPct) ? null : toNumber(l.discPct), gstPct: toNumber(l.gstPct),
        vendorMaterialId: l.vendorMaterialId || null, source: l.bomSource || {}
      })),
      reorder: { sourcePoId: card.sourcePoId || null, sourcePoNo: card.sourcePoNo || '', sourceOrderId: draft.source?.orderId || null, sourceOrderNo: draft.source?.orderNo || '' }
    };
  });
}

/** Totals for the summary strip. */
export function draftTotals(draft, vendors = []) {
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  let rows = 0;
  let value = 0;
  let count = 0;
  for (const card of draft.pos) {
    if (card.excluded) continue;
    count += 1;
    rows += card.lines.length;
    value += computePo(preparedPoAsPo(card, vendorById.get(String(card.vendorId)), draft)).grandTotal;
  }
  return { pos: count, rows, value: round2(value) };
}

// ---------- Reorder a machine straight from its Product master (BOM) ----------

const lc = (v) => String(v ?? '').trim().toLowerCase();
const words = (...parts) => parts.map((p) => String(p ?? '').trim()).filter(Boolean).join(' ');
const chainQty = (...qs) => (qs.some(blank) ? null : round2(qs.reduce((a, q) => a * toNumber(q), 1)));

/** Every purchasable row of a BOM: bought-out items and material lines (sub-items included). */
export function bomPurchaseRows(nodes = []) {
  const rows = [];
  let skipped = 0;
  nodes.forEach((n, i) => {
    const label = `Item ${i + 1}. ${n.name || 'Untitled'}`;
    if (!n.mode) { skipped += 1; return; } // made or bought not chosen: nothing to order
    if (isBoughtOut(n)) {
      rows.push({ key: `i:${n.uid}`, itemUid: n.uid, lineUid: '', label, material: n.name || '', description: words(n.name, n.spec) || 'Untitled',
        qty: chainQty(n.qty), uom: String(n.uom || '').toUpperCase(), rate: n.rate, vendor: n.vendor || '', source: 'BOC' });
      return;
    }
    const add = (l, qtys, where) => {
      if (blank(l.material)) return;
      rows.push({ key: `l:${l.uid}`, itemUid: n.uid, lineUid: l.uid, label: where, material: l.material, description: words(l.material, l.spec, l.cutSize),
        qty: chainQty(...qtys), uom: String(l.uom || '').toUpperCase(), rate: l.rate, vendor: l.vendor || '', source: l.source || '' });
    };
    (n.lines || []).forEach((l) => add(l, [l.qty, n.qty], label));
    (n.subAssemblies || []).forEach((sb) => (sb.lines || []).forEach((l) => add(l, [l.qty, sb.qty, n.qty], `${label} › ${sb.name || 'sub-item'}`)));
  });
  return { rows, skipped };
}

/** Which rows a reorder includes: by how the BOM says each row is obtained. */
export const BOM_REORDER_SOURCES = [
  { key: 'BOC', label: 'Bought-out' },
  { key: 'OUT', label: 'Outsource (job work)' },
  { key: 'IH', label: 'In-house (raw material to buy)' },
  { key: '', label: 'Source not set in the BOM' }
];

/**
 * Pick the supplier, material link, rate and GST for one BOM row.
 * Supplier: vendor named on the material in the BOM → last PO for this BOM row → a supplier whose material list has it
 * (preferred first, then lowest current rate). Rate: supplier's current rate → last PO (same supplier) → BOM rate.
 * GST: supplier's list → last PO → standard rate.
 */
function resolveRow(r, ctx) {
  const { activeVendors, vendorById, matsByVendor, findInList, lastByKey } = ctx;
  const last = lastByKey.get(r.key);
  let vendor = null;
  let supplierFrom = '';
  // 1. The vendor written on the material in the Product master (the Admin's choice) wins.
  if (r.vendor) {
    vendor = activeVendors.find((v) => lc(v.name) === lc(r.vendor)) || null;
    if (vendor) supplierFrom = 'Vendor chosen in the Product master';
  }
  // 2. Otherwise the supplier of the last PO for this item.
  const lastVendor = last?.po.vendorId ? vendorById.get(String(last.po.vendorId)) : null;
  if (!vendor && lastVendor && lastVendor.status !== 'inactive') {
    vendor = lastVendor;
    supplierFrom = `Supplier from last PO ${last.po.poNo}`;
  }
  if (!vendor) {
    const offers = vendorOffers(r.material, ctx);
    if (offers.length) {
      vendor = offers[0].vendor;
      supplierFrom = offers[0].material.preferred === 'yes' ? "Supplier's list (preferred supplier)" : offers.length > 1 ? `Supplier's list (lowest of ${offers.length} suppliers)` : "Supplier's list";
    }
  }
  const vm = vendor
    ? (last?.line.vendorMaterialId && (matsByVendor.get(String(vendor._id)) || []).find((m) => String(m._id) === String(last.line.vendorMaterialId) && m.status !== 'inactive')) || findInList(vendor._id, r.material)
    : null;
  const current = vm ? latestEntry(vm.history) : null;
  const lastSame = last && vendor && String(last.po.vendorId) === String(vendor._id) ? last : null;
  const rate = current ? current.rate : lastSame ? lastSame.line.rate : blank(r.rate) ? '' : r.rate;
  return {
    vendorId: vendor ? vendor._id : null,
    vendorName: vendor ? vendor.name : '',
    supplierFrom,
    vendorMaterialId: vm ? vm._id : null,
    rate,
    rateFrom: current ? 'current' : lastSame ? 'source' : blank(rate) ? '' : 'bom',
    gstPct: vm && !blank(vm.gstPct) ? vm.gstPct : lastSame && !blank(lastSame.line.gstPct) ? lastSame.line.gstPct : STANDARD_GST_PCT,
    discPct: null,
    hsn: lastSame?.line.hsn || '',
    from: last
      ? { label: `PO ${last.po.poNo}`, poNo: last.po.poNo, description: last.line.description, qty: last.line.qty, uom: last.line.uom, rate: last.line.rate, discPct: last.line.discPct ?? null, gstPct: last.line.gstPct }
      : { label: 'BOM', poNo: '', description: r.description, qty: r.qty ?? '', uom: r.uom, rate: blank(r.rate) ? '' : r.rate, discPct: null, gstPct: '' }
  };
}

/** Every active supplier that lists this material, best first (preferred, then lowest current rate). */
export function vendorOffers(material, { activeVendors, findInList }) {
  return activeVendors
    .map((vendor) => ({ vendor, material: findInList(vendor._id, material) }))
    .filter((o) => o.material)
    .map((o) => ({ ...o, rate: latestEntry(o.material.history)?.rate ?? null }))
    .sort((a, b) => (a.material.preferred === 'yes' ? 0 : 1) - (b.material.preferred === 'yes' ? 0 : 1) || toNumber(a.rate ?? Infinity) - toNumber(b.rate ?? Infinity));
}

/** Lookups shared by the machine reorder functions. */
export function supplierContext({ vendors = [], materials = [], pastPos = [] }) {
  const activeVendors = vendors.filter((v) => v.status !== 'inactive');
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  const matsByVendor = new Map();
  for (const m of materials) {
    const k = String(m.vendorId);
    if (!matsByVendor.has(k)) matsByVendor.set(k, []);
    matsByVendor.get(k).push(m);
  }
  const findInList = (vendorId, name) => (matsByVendor.get(String(vendorId)) || []).find((m) => m.status !== 'inactive' && lc(m.material) === lc(name)) || null;
  const lastByKey = new Map();
  [...pastPos].sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.poNo).localeCompare(String(a.poNo))).forEach((po) => {
    (po.lines || []).forEach((l) => {
      const k = l.source?.lineUid ? `l:${l.source.lineUid}` : l.source?.itemUid ? `i:${l.source.itemUid}` : '';
      if (k && !lastByKey.has(k)) lastByKey.set(k, { po, line: l });
    });
  });
  return { activeVendors, vendorById, matsByVendor, findInList, lastByKey };
}

/** Purchase settings for a row whose vendor the user picked: link to that vendor's material, rate and GST. */
export function purchaseForVendor(row, prev, vendor, ctx) {
  if (!vendor) return { ...prev, vendorId: null, vendorName: '', vendorMaterialId: null, supplierFrom: '' };
  const vm = ctx.findInList(vendor._id, row.material);
  const current = vm ? latestEntry(vm.history) : null;
  return {
    ...prev,
    vendorId: vendor._id,
    vendorName: vendor.name,
    supplierFrom: 'Supplier chosen in this reorder',
    vendorMaterialId: vm ? vm._id : null,
    ...(current && prev.rateFrom !== 'typed' ? { rate: current.rate, rateFrom: 'current' } : {}),
    ...(vm && !blank(vm.gstPct) ? { gstPct: vm.gstPct } : {})
  };
}

const deepCopy = (v) => JSON.parse(JSON.stringify(v));

/**
 * Reorder a machine from its Product master. The draft holds:
 * - machine: a full, editable COPY of the BOM (items, sub-items, materials, quantities);
 * - purchase: per BOM row, whether to order it and from which supplier, at what rate and GST;
 * - poMeta: per supplier, PO details (Kind Attn., payment terms, reference, remark, excluded);
 * - pos: the prepared POs, always worked out from the three above (derivePosFromMachine).
 * Nothing is generated. The original Product master never changes.
 */
export function buildReorderDraftFromBom({ productMaster, vendors = [], materials = [], pastPos = [], include = { BOC: true, OUT: true, IH: false, '': true }, uid, copyMachine = true }) {
  const ctx = supplierContext({ vendors, materials, pastPos });
  const machine = {
    machineName: productMaster.machineName || '',
    modelNo: productMaster.modelNo || '',
    revision: productMaster.revision ?? 0,
    nodes: deepCopy(productMaster.nodes || [])
  };
  const { rows, skipped } = bomPurchaseRows(machine.nodes);
  const purchase = {};
  const poMeta = {};
  let ordered = 0;
  for (const r of rows) {
    const order = include[r.source || ''] !== false && !!include[r.source || ''];
    if (order) ordered += 1;
    purchase[r.key] = { order, ...resolveRow(r, ctx) };
    const vid = purchase[r.key].vendorId;
    if (vid && !poMeta[vid]) {
      const v = ctx.vendorById.get(String(vid));
      poMeta[vid] = { kindAttn: v?.contactPerson || '', paymentTerms: v?.paymentTerms || '', refNo: '', refDate: '', remark: '', terms: '', excluded: false };
    }
  }
  const draft = {
    status: 'draft',
    source: {
      kind: 'bom', orderId: null, orderNo: '', poIds: [], poNos: [],
      productMasterId: productMaster._id, modelNo: productMaster.modelNo || '', machineName: productMaster.machineName || '', revision: productMaster.revision ?? 0,
      included: Object.keys(include).filter((k) => include[k]), rowCount: ordered, skippedItems: skipped, notIncluded: rows.length - ordered
    },
    poDate: '',
    projectId: '',
    customerRef: '',
    modelNo: productMaster.modelNo || '',
    productMaster: productMaster._id,
    machine,
    purchase,
    poMeta,
    saveAsNew: { enabled: false, modelNo: '' }
  };
  draft.pos = derivePosFromMachine(draft, vendors);
  if (productMaster.reorderOf?.modelNo) draft.source.reorderOfModelNo = productMaster.reorderOf.modelNo;
  if (!copyMachine) {
    // Plain prepared POs: edited directly on the purchase-order cards (the machine copy is a Product master).
    delete draft.machine;
    delete draft.purchase;
    delete draft.poMeta;
    delete draft.saveAsNew;
  }
  return draft;
}

/** Model no for a reorder copy: "LBSL 80-RO1", "LBSL 80-RO2", … (first one not used yet). */
export function nextReorderModelNo(modelNo, existingModelNos = []) {
  const base = String(modelNo || 'Machine').replace(/-RO\d+$/, '');
  const used = new Set(existingModelNos.map((m) => String(m).toLowerCase()));
  let n = 1;
  while (used.has(`${base}-RO${n}`.toLowerCase())) n += 1;
  return `${base}-RO${n}`;
}

/** The prepared POs of a machine draft: every BOM row marked "order", grouped by supplier. */
export function derivePosFromMachine(draft, vendors = []) {
  const vendorById = new Map(vendors.map((v) => [String(v._id), v]));
  const { rows } = bomPurchaseRows(draft.machine?.nodes || []);
  const cards = new Map();
  for (const r of rows) {
    const p = draft.purchase?.[r.key];
    if (!p || !p.order) continue;
    const vid = p.vendorId ? String(p.vendorId) : '';
    if (!cards.has(vid)) {
      const v = vid ? vendorById.get(vid) : null;
      const meta = (vid && draft.poMeta?.[vid]) || {};
      cards.set(vid, {
        uid: vid ? `v:${vid}` : 'unassigned', sourcePoId: null, sourcePoNo: '', unassigned: !vid,
        vendorId: vid || null, vendorName: vid ? v?.name || p.vendorName || 'Supplier' : 'Rows without a supplier',
        excluded: !!meta.excluded, kindAttn: meta.kindAttn || '', paymentTerms: meta.paymentTerms || '', refNo: meta.refNo || '', refDate: meta.refDate || '',
        remark: meta.remark || '', terms: meta.terms || '', lines: []
      });
    }
    cards.get(vid).lines.push({
      uid: r.key, material: r.material, description: r.description, hsn: p.hsn || '', qty: r.qty ?? '', uom: r.uom,
      rate: p.rate, rateFrom: p.rateFrom, discPct: p.discPct ?? null, gstPct: p.gstPct, vendorMaterialId: p.vendorMaterialId || null,
      bomSource: { itemUid: r.itemUid, lineUid: r.lineUid, label: r.label }, supplierFrom: p.supplierFrom || '', from: p.from || null
    });
  }
  return [...cards.values()].sort((a, b) => (a.unassigned ? 1 : 0) - (b.unassigned ? 1 : 0) || a.vendorName.localeCompare(b.vendorName));
}
