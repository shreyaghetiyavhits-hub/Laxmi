// Company details printed on purchase orders (taken from PO 0085).
// Change them here; both the API and the client read this file.
export const COMPANY = {
  name: 'LAXMI ENGINEERING EQUIPMENT',
  addressLines: [
    '5/34, PHASE 1, OPP. MARUTI INDUSTRIAL ESTATE',
    'BOMBAY CONDUTOR ROAD, GIDC, VATVA',
    'AHMEDABAD - 382445, GUJARAT, INDIA'
  ],
  phone: '9227755102',
  url: 'www.laxmipharma.net',
  email: 'laxmiengineering1@yahoo.com',
  gstin: '24AABFL4153E1ZS',
  state: 'GUJARAT',
  stateCode: '24'
};

/**
 * GST rate used on a PO row when the vendor's material list gives no rate for that material.
 * Taken from PO 0085 (CGST 9% + SGST 9% = 18%). The rate can still be changed on any row.
 * The vendor's state decides only the split: same state = CGST + SGST, other state = IGST.
 */
export const STANDARD_GST_PCT = 18;
export const GST_RATES = [0, 5, 12, 18, 28];

/** Standard wording on the PO, as on PO 0085. Editable per PO. */
export const PO_TEXT = {
  greeting: 'Dear Sir;',
  intro: 'We thank you very much for your inquiry as noted and are pleased to submit out most competitive offer for the same as under :',
  closing: 'We hope you will find our quotation in line and be pleased to receive your valuable order. Thanking You, and assuring you of our best service at all times.'
};

