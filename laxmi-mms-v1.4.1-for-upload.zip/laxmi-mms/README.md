# Laxmi MMS – Product Master (BOM) module, simplified "items" version

This is a variant of Version 2 with **no Assembly / Component split**. Every BOM entry is an *item*,
numbered 1, 2, 3 like the Sr No on the original BOM sheet:

- **Made in-house** items (`mode: "fabricated"`) list their materials and may hold **sub-items**
  (stored in `subAssemblies`, the field name is unchanged so data stays compatible).
- **Bought-out** items (`mode: "bought_out"`) carry spec, vendor and rate directly.
- `kind` is always `"item"`. The API also accepts old values (`"assembly"`, `"component"`) and stores them as `"item"`,
  so BOMs saved by the original Version 2 still load.
- Stored totals are `items`, `boughtOut`, `madeInHouse`, `lineCount`, `pendingRates`, `cost`.
- The LBSL 80 sample follows the PDF's order.

## No assumed values

Nothing is filled in on the user's behalf. New items, sub-items, material lines, PO rows and vendors start blank:
no default source (In-house), quantity, unit, item type, PO date or vendor status.
Drop-downs show "Select…". Blanks are stored as `''` (text) or `null` (numbers).

- *Save as draft* accepts blanks.
- *Save product master* (final) lists every missing item type, quantity, unit, source and material (`shared/validation.js`).
- A PO cannot be saved without date, vendor state (it decides CGST + SGST vs IGST), and qty and rate on every row (GST rate is filled in, see below).
- The LBSL 80 sample only holds what the PDF states (`shared/sampleBom.js`); everything else is blank.

## Vendor master

Fields from the developer document (section 21) plus State, State code and GSTIN for purchase orders:
code (automatic V0001, V0002… when left blank), name*, status* (Active/Inactive, must be chosen), contact person, mobile,
email, address, state, state code, GSTIN, category, preferred (Yes/No), materials supplied, lead time (days),
payment terms, remarks. "Documents" (file uploads) is not built yet.

- Picking a vendor on a PO fills address, state, state code, GSTIN, Kind Attn. (contact person) and payment terms.
  The PO keeps a copy (`vendor`) plus a link (`vendorId`), so old POs still print the details used at the time.
- A name that is not in the master can be added from the PO window ("Add it to Vendor master").
- Inactive vendors are not offered on new POs. Vendors used on a PO cannot be deleted; set them to Inactive.
- BOM vendor suggestions come from the Vendor master.

| Method | Path | What it does |
|---|---|---|
| GET | `/api/vendors?q=&status=` | List, A–Z |
| GET | `/api/vendors/next-code` | Next free vendor code |
| GET | `/api/vendors/:id` | One vendor |
| POST | `/api/vendors` | Create (blank code = next code; duplicate names refused) |
| PUT | `/api/vendors/:id` | Update |
| DELETE | `/api/vendors/:id` | Delete (refused if used on a PO) |

## GST: state and rate

- **State code is never typed.** State is a drop-down of Indian states (`shared/gstStates.js`); the GST state code
  follows it (Gujarat → 24). If no state is chosen, a GSTIN fills it in (its first 2 digits are the state code), and a
  GSTIN from a different state is flagged. The API works the code out the same way, so saved data is always consistent.
- **The state decides only the split:** vendor in Gujarat (the company's state) → CGST + SGST; any other state → IGST.
- **The GST rate is filled in on PO rows:** from the GST rate of the vendor's material (Vendor page → Materials & rates),
  otherwise the company's standard rate `STANDARD_GST_PCT` = 18% in `shared/company.js` (taken from PO 0085,
  CGST 9% + SGST 9%). Each row shows where its rate came from and can be changed with the GST drop-down
  (0, 5, 12, 18, 28%). A rate chosen on a row is kept when the row is linked to the vendor's list.
- The PO no longer asks "For how many machines?": quantities come straight from the BOM.

## Vendor page: materials, price history and purchase orders

Open a vendor (Vendor master → name) to get three tabs and a summary (number of POs, total purchased incl. GST,
average PO value, materials with a price).

**Materials & rates** (Vendor Material Mapping, developer document section 21). Materials are added one at a time
(*Save & add another* for several in a row): material*, status* (Active/Inactive), specification, unit, rate,
"rate applies from" date (required when the rate changes), preferred, MOQ, lead time, remarks. Nothing has a default.
- Every rate typed in adds a *manual* entry to the material's price history; earlier prices are kept.
- Every PO row linked to the material adds a *po* entry (PO date, rate, qty, PO no). Saving a PO again replaces its
  entries; deleting a PO removes them (`server/src/services/priceHistory.js`).
- *Price history* shows current, lowest, highest, average, change since the first price, then every entry (List, newest
  first, shown by default) or a chart (Graph) when there are 2 or more prices; each entry has
  its change and source, and **other vendors** that list the same material (same name), with their current rates.
- A material used on a PO cannot be removed (its history is kept); set it to Inactive.

**Purchase orders.** Every PO to this vendor (View / print), the total, and *Items purchased*: per item the total
quantity, number of orders, last rate, last PO and value. **New PO to this vendor** opens the PO window with the
vendor already filled in.

**On the PO.** Each row can be linked to the vendor's material list. Picking a material fills description, unit and
rate only where they are blank. Rows taken from the BOM link automatically when the material name matches, and show
where the rate came from ("from vendor list" / "from BOM"). Choosing a different vendor removes the links.

| Method | Path | What it does |
|---|---|---|
| GET | `/api/vendors/:id/materials` | The vendor's materials, each with its current price |
| POST | `/api/vendors/:id/materials` | Add a material |
| PUT | `/api/vendor-materials/:mid` | Update; a changed rate is added to the history |
| DELETE | `/api/vendor-materials/:mid` | Remove (refused if used on a PO) |
| GET | `/api/vendor-materials/:mid/history` | Price stats, all entries, other vendors' rates |
| GET | `/api/vendors/:id/purchases` | The vendor's POs, totals and items purchased |

Shared maths: `shared/priceHistory.js` (tested in `shared/priceHistory.test.js`).

Not built yet: delivery dates, partial deliveries and pending quantities need the GRN module; vendor documents (file uploads).

## Smart Reorder (v1.1)

Reorder repeats earlier purchasing without re-typing it. **Reorder never creates a PO by itself**: it prepares a
*reorder draft*, and purchase orders are made only after **Review and confirm → tick → Generate**.

- **Start:** Purchase orders → *Reorder* on a PO, tick several POs → *Reorder selected*, or Orders tab → *Reorder*.
- **Draft (RD-0001…):** one prepared PO per source PO (same supplier, same rows), saved automatically. Labelled
  "DRAFT, not a PO"; preview shows a NOT SAVED watermark. The source order and POs are never changed.
- **What is copied / refreshed** (`shared/reorder.js`): description, HSN, qty, unit, discount, GST rate are copied.
  Rate = the supplier's **current** rate from its material list when it has one (the old rate is shown,
  "Was ₹108 on PO 0085", with Revert and "Use current"). Supplier address, state, GSTIN, contact and payment terms
  come fresh from the Vendor master. PO date: today or later, chosen by the user. PO numbers: only at generation.
- **Edit:** every row field, add rows (blank or from the supplier's list), remove, move a row to another supplier
  (or a new PO for a supplier), exclude a whole PO from this run, add a PO for another supplier, PO details.
- **Checks** (`checkReorderDraft`): blocks = no PO date or backdated, supplier missing/inactive/without state,
  material inactive in the supplier's list, missing qty/rate/GST/description, PO with no rows. Warnings = rate or
  GST different from the supplier's list, below MOQ, material no longer in the list. "Was …" notes show edits.
- **Generate:** confirmation lists each PO, totals and warnings; needs the "I have reviewed" tick. The server
  checks again against today's masters (anything inactive → nothing generated, back to review), creates an
  **Order (ORD-0001…)** and the new POs (next numbers, linked: `orderId`, `reorder.sourcePoNo`, `reorder.draftNo`),
  adds the rates to price history, and locks the draft as Generated. Each draft has a one-time generation key:
  double clicks, refreshes or a second tab return the same POs, never duplicates.
- **Records:** POs show "Reorder of PO 0085"; Orders tab lists orders with their POs; Reorder drafts tab lists
  open, generated and discarded drafts. Every step is kept in the draft's `audit` log.
- **On/off:** `SMART_REORDER_ENABLED=false` (API) and `VITE_SMART_REORDER=false` (client build) switch the
  feature off; the app then behaves exactly like v1.0. All v1.1 data is additive (new collections `orders`,
  `reorderdrafts`; new optional PO fields), so v1.0 runs on the same database. See `RESTORE.md`.

| Method | Path | What it does |
|---|---|---|
| POST | `/api/reorders` `{ orderId }` or `{ poIds }` | Prepare a draft (creates no PO) |
| GET | `/api/reorders?status=` | Drafts |
| GET / PUT | `/api/reorders/:id` | Open / save a draft (`version` for safe concurrent edits) |
| POST | `/api/reorders/:id/discard` | Discard (no PO created or changed) |
| POST | `/api/reorders/:id/generate` `{ generationKey }` | The only call that creates POs; runs once |
| GET | `/api/orders`, `/api/orders/:id` | Orders and their POs |

### Reorder machine (v1.2): all POs for a machine from its Product master

For a new customer order of the same or a similar machine: Product master → **Reorder machine** (list row or BOM
editor; the BOM must be saved). A small window chooses which BOM rows to order by their source (Bought-out,
Outsource, In-house raw material, source not set; In-house is off by default) and then prepares a reorder draft
with **one prepared PO per supplier** (`buildReorderDraftFromBom` in `shared/reorder.js`). Nothing is generated.

- Supplier per row: the supplier on the **last PO for that BOM row of this machine** (PO lines keep
  `source.lineUid` / `source.itemUid`), else the **vendor named in the BOM** (matched in the Vendor master), else a
  supplier whose **material list** has this material (preferred first, then lowest current rate). Each row says
  where its supplier came from. Rows with no supplier are grouped in a "Rows without a supplier" card: choose a
  supplier for the whole card, or Move… each row.
- Rate: supplier's current rate → last PO rate (same supplier) → BOM rate. GST: supplier's list → last PO →
  `STANDARD_GST_PCT`. Quantity: from the BOM (item qty × line qty × sub-item qty). Items whose type is not chosen
  are skipped and counted.
- Changing a card's supplier or moving a row re-links rows to the new supplier's own material (same name) with
  its rate and GST.
- Review, edit, PO date, confirm and generate work exactly as for Reorder from POs. Generated POs keep
  `productMaster` / `modelNo` and their BOM row links, so the next Reorder machine remembers suppliers and rates.
- API: `POST /api/reorders { productMasterId, include: { BOC, OUT, IH, '' } }`.

### Reorder machine copies the machine (v1.3)

Reorder machine now starts from an **editable copy of the whole machine**, not only POs. The draft holds
`machine` (copy of the BOM: items, sub-items, materials, quantities), `purchase` (per BOM row: order yes/no,
vendor, rate, GST, link to the vendor's material) and `poMeta` (per vendor: Kind Attn., payment terms, reference,
remark, excluded). The prepared POs (`pos`) are always worked out from these (`derivePosFromMachine`), on the
client after every edit and again on the server at generation.

- **Tab 1, Machine & materials:** every item and material of the copy, editable (name, type, qty, unit, material,
  details, source), add/remove items, materials and sub-items. Per row: *Order* tick, **Vendor** (drop-down lists
  vendors that have this material first, with their current price, preferred ★ and lowest marked, then other
  vendors), rate and GST. Filters: All / To order / Without vendor, search, and "Set vendor for all rows without one".
- **Tab 2, Purchase orders:** one prepared PO per vendor with totals, preview, Exclude, PO details; *Edit* jumps to
  the row in tab 1.
- **Optional:** "Also save this machine as a new Product master" with a new model no (checked unique before
  anything is created). Generated POs and the Order then point to the new Product master.
- The original Product master never changes. Each generated Order keeps `machine`, the copy as ordered.

### Simple Reorder (v1.4): copy the machine, then prepare its POs

The simple path for a repeat or similar machine order (the two-tab "machine copy" screen of v1.3 is no longer
offered; its drafts still open):

1. Product master → **Reorder** (list row or Product master screen). After one confirmation,
   `POST /api/product-masters/:id/reorder` makes a full copy as a **new Product master** (draft, revision 0,
   model no `<model>-RO1`, `-RO2`, … from `nextReorderModelNo`) with `reorderOf: { productMasterId, modelNo,
   revision, at }`. The original is not changed. The copy opens in the normal Product master screen with a
   "Reorder of <model>" banner; everything is editable (items, materials, quantities, vendor per material).
2. **Prepare purchase orders** (banner button) saves the copy and creates a reorder draft from it
   (`POST /api/reorders { productMasterId, include, copyMachine: false }`): plain prepared POs, one per supplier,
   edited on the familiar PO cards. Supplier per row: **vendor written on the material in the Product master**,
   else the last PO for that item (of the copy or of the original machine), else the vendor material lists.
   If a draft is already open for the copy, the user can continue it or prepare again from the current copy.
3. **Review and confirm → Generate** as for any reorder. POs, the Order and the drafts list say
   "Reorder of <original> (<copy>)".

## Purchase orders

- **Create PO** on a BOM opens a 3-step window: (1) pick the vendor and tick what to order, with quantities
  taken from the BOM; (2) PO details, vendor address/state/GSTIN, editable rows (HSN, qty, unit, rate,
  disc %, GST %) and live totals; (3) preview in the PO 0085 layout, then Save, Print or Download.
- **Purchase orders** page (cart icon): list, search, view/print, edit, delete, and *New PO* for rows typed by hand.
- PO numbers are automatic (next after the highest, keeping zero padding: 0085 → 0086) or typed.
- Vendor details come from the Vendor master (see above).
- GST: vendor state code equal to the company's (24, Gujarat) or blank → CGST + SGST (half each); otherwise IGST.
  Grand total is rounded to the rupee with a Round off line; amount in words uses lakh/crore.
- Company details and standard PO wording: `shared/company.js`. PO maths: `shared/po.js` (tested against PO 0085 in
  `shared/po.test.js`). PO layout: `client/src/lib/poDocument.js`. The logo is drawn with CSS; replace it with the real
  logo image (as a data: URL) in that file.

| Method | Path | What it does |
|---|---|---|
| GET | `/api/purchase-orders?q=` | List, newest first |
| GET | `/api/purchase-orders/next-number` | Next free PO number |
| GET | `/api/purchase-orders/:id` | One PO |
| POST | `/api/purchase-orders` | Create (blank `poNo` = next number) |
| PUT | `/api/purchase-orders/:id` | Update |
| DELETE | `/api/purchase-orders/:id` | Delete |

The rest of this README applies unchanged; where it says assemblies/components, read items.

Step 1 (shared foundation) and Version 2 (tree and editor) of the Product Master screen.

| Part | Tech |
|---|---|
| Client | React 18 + Vite 5, React Router 6, Zustand |
| API | Node.js 20+, Express 4, Zod |
| Database | MongoDB (Mongoose 8) |
| Shared rules | `shared/` – cost totals and final-save checks, used by both client and API |

## Folder layout

```
laxmi-bom/
├─ shared/                 Rules used by BOTH apps
│  ├─ constants.js         Units, sources (IH / BOC / OUT), statuses
│  ├─ cost.js              Line, sub-assembly, node and BOM totals
│  ├─ validation.js        What must be filled in before "Save as final"
│  ├─ sampleBom.js         LBSL 80 sample data + starter suggestions
│  └─ cost.test.js         Unit tests (npm test)
├─ server/
│  └─ src/
│     ├─ models/ProductMaster.js     Mongoose schema (one document per model + revision)
│     ├─ validation/productMaster.js Zod request validation
│     ├─ controllers/                List, get, create, update, delete, revisions, lookups
│     ├─ routes/                     /api/product-masters, /api/lookups
│     ├─ middleware/                 Error handling
│     └─ seed/seed.js                Loads the LBSL 80 BOM from the client's PDF
└─ client/
   └─ src/
      ├─ api/                        fetch wrapper + endpoints
      ├─ store/editorStore.js        All editor state and actions (Zustand)
      ├─ lib/bom.js                  Builders, API ↔ editor conversion, A1/C1 tags
      ├─ features/product-master/    List page, editor page, tree, editor, line items
      └─ styles.css                  Version 2 design
```

## Put it online for testing

See **DEPLOY.md**: step by step, no coding needed (MongoDB Atlas + GitHub + Render, about 45 minutes).

## Run it locally

You need **Node.js 20+** and **MongoDB** running locally (or a MongoDB Atlas connection string).

```bash
# 1. Install both apps
npm run install:all

# 2. Configure the API
cp server/.env.example server/.env      # edit MONGODB_URI if needed

# 3. (Optional) load the LBSL 80 sample BOM
npm run seed                            # npm run seed -- --reset to reload it

# 4. Start both, in two terminals
npm run dev:server                      # http://localhost:5000
npm run dev:client                      # http://localhost:5173
```

Vite forwards every `/api` request to port 5000, so no CORS setup is needed in development.

## How it works

**Data model.** Each product master is one MongoDB document. The BOM tree is stored inside it:
`nodes[]` (assemblies and components) → `subAssemblies[]` (assemblies only) → `lines[]` (materials).
Every node, sub-assembly and line has a `uid` created in the browser, so items keep their identity before the first save.

**Bought-out components** (`kind: "component", mode: "bought_out"`) have no material lines. They carry `spec`, `vendor` and `rate` directly.

**Rates are optional.** A blank rate is stored as `null` and counted as "pending". Totals treat it as 0.

**Draft vs final.**
- *Save as draft* accepts half-finished work. Only the model no is required.
- *Save product master* saves as **final**. Every assembly, component and sub-assembly needs a name and every line needs a material. The client checks first and lists problems with "Go to item" buttons. The API checks again.
- A final revision is locked. *Create revision R1* copies it into a new draft. Earlier revisions are never changed.
- Only one draft revision per model at a time. Final revisions cannot be deleted.

**Two views of the same BOM.**
- *Edit one item*: the tree on the left, the selected item on the right. Arrows in the tree (and Expand all) show each item's materials and sub-assemblies without opening it.
- *Full BOM view*: every assembly and component with its materials on one page, with Edit buttons.
Expanded/collapsed state is shared by both views and is not saved with the BOM.

**Printing.** "Print BOM" (page header and Full BOM view) opens a preview laid out like the client's original BOM sheet:
Sr No, item code / special details, part name, raw material / cutting size, finish goods / bought out, vendor, unit price, qty, total
(A4 landscape, headings repeat on every page, sign-off lines at the end). *Print* prints it; *Download* saves the same page as an
HTML file that can be printed or saved as PDF from any browser. The layout lives in `client/src/lib/printDocument.js`.
The expand button in the tree header opens the Full BOM view with every item expanded.

**Confirmations** use the in-app box in `components/ConfirmProvider.jsx` (`const confirm = useConfirm()`), never `window.confirm`, because embedded pages can block browser pop-ups silently.

**Totals** (`totals.cost`, `pendingRates`, and so on) are recalculated by the model on every save, so list pages and reports can read them without re-adding the BOM.

## API

All responses are JSON. Errors return `{ message, issues? }`.

| Method | Path | What it does |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/product-masters?q=&status=` | List (summary fields only), newest first |
| GET | `/api/product-masters/:id` | Full document |
| POST | `/api/product-masters` | Create. `409` if the model no already exists |
| PUT | `/api/product-masters/:id` | Update a draft. `409` with `code: FINAL_LOCKED` for final revisions |
| DELETE | `/api/product-masters/:id` | Delete a draft |
| POST | `/api/product-masters/:id/revisions` | Copy into a new draft revision (R+1) |
| GET | `/api/lookups` | Suggestions for materials, parts, vendors, processes |

Status codes: `400` invalid fields, `404` not found, `409` conflict, `422` not ready to be final.

### Request body (POST / PUT)

```json
{
  "machineName": "Bottle sticker labelling machine",
  "modelNo": "LBSL 80",
  "projectId": null,
  "status": "draft",
  "nodes": [
    {
      "uid": "…", "kind": "assembly", "name": "Machine body frame", "qty": 1, "uom": "Set",
      "lines": [{ "uid": "…", "material": "Top plate", "spec": "8 LH 1", "source": "IH", "qty": 1, "uom": "Nos", "rate": null }],
      "subAssemblies": [{ "uid": "…", "code": "RG 3", "name": "Machine body", "qty": 1, "uom": "Set", "lines": [] }]
    },
    { "uid": "…", "kind": "component", "mode": "bought_out", "name": "Gear box & motor", "qty": 1, "uom": "Set", "spec": "Box 30, ratio 30", "vendor": "", "rate": null }
  ]
}
```

`source` is `IH` (in-house), `BOC` (bought-out) or `OUT` (outsource). `projectId` must look like `PRJ-0000` or be `null`.

## Browser demo (no server needed)

```bash
cd client
npm run build:demo     # → client/dist-demo/index.html
```

This builds the same React app as one self-contained HTML file. Instead of calling the API it uses
`client/src/api/demoApi.js`, which follows the same rules (drafts, final checks, locking, revisions),
starts with the LBSL 80 sample, and saves changes in the viewer's browser only. Good for showing the
screens to people without installing anything. Normal builds (`npm run build`) are not affected.

## Tests

```bash
npm test     # cost and final-save rules in shared/
```

## Not included yet

- **Login and roles.** No auth middleware yet. Add it in `server/src/app.js` before the routes when the user module exists.
- **Real masters.** `/api/lookups` suggests values from a starter list plus what is already saved. Point it at the Item, Material and Vendor masters when they are built.
- **Version 3 (grid view).** Next step. It reuses this API, store and `shared/` rules, and adds a second view of the same BOM.
